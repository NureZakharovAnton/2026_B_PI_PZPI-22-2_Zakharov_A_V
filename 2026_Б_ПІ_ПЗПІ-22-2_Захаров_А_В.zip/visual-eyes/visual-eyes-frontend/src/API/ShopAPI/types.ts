export type Shop = {
  id: string;
  title: string;
  description?: string;
  imageURL?: string;
  siteURL: string;
};
