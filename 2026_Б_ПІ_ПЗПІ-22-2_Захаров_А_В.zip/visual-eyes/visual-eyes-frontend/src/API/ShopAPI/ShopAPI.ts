import API from "../API";
import { Shop } from "./types";

class ShopAPI extends API {
  static async getAll() {
    const response = await this.get("/shops");

    const shops: Shop[] = response.data;
    return shops;
  }
}

export default ShopAPI;
