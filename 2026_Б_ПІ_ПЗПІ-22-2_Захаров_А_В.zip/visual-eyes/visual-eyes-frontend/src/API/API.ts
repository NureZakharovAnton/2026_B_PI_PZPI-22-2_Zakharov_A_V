import axios from "axios";

const axiosInstance = axios.create({
  baseURL: "http://localhost:5002/api/v1",
  withCredentials: true,
  headers: {
    "Content-Type": "application/json",
  },
});

class API {
  static async get(url: string) {
    return await axiosInstance.get(url);
  }

  static async post(url: string, data: any) {
    return await axiosInstance.post(url, data);
  }

  static async put(url: string, data: any) {
    return await axiosInstance.put(url, data);
  }

  static async delete(url: string) {
    return await axiosInstance.delete(url);
  }
}

export default API;
