import API from "../API";
import { LoginRequest, RegistrationRequest } from "./types";

class AuthAPI extends API {
  static async login(req: LoginRequest) {
    return await this.post("/auth/login", req);
  }

  static async register(req: RegistrationRequest) {
    return await this.post("/auth/register", req);
  }
}

export default AuthAPI;
