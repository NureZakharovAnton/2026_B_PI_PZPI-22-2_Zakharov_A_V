export enum ERROR_TYPES {
  INTERNAL_SERVER = "INTERNAL_SERVER",
  UNKNOWN = "UNKNOWN",
}

export type ErrorType = `${ERROR_TYPES}`;

export type BaseError = {
  type: ErrorType;
};
