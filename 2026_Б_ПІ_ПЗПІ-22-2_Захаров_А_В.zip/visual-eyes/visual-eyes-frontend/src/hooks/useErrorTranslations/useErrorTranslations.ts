import { useIntl } from "react-intl";
import { ERROR_TYPES, ErrorType } from "./types";
import messages from "./messages";
import checkIsTrustedError from "./checkIsTrustedError";

const useErrorTranslations = () => {
  const intl = useIntl();

  const errorTranslations = {
    [ERROR_TYPES.UNKNOWN]: intl.formatMessage(messages.unknown),
    [ERROR_TYPES.INTERNAL_SERVER]: intl.formatMessage(messages.internalServer),
  };

  const translateErrorMessage = (error: any) => {
    let errorType: ErrorType = ERROR_TYPES.UNKNOWN;

    if (checkIsTrustedError(error)) {
      errorType = error.type;
    }

    const errorMessage = `${errorTranslations[errorType]} 💥`;
    return errorMessage;
  };

  return { translateErrorMessage };
};

export default useErrorTranslations;
