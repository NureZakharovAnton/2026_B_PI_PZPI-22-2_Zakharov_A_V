import { defineMessages } from "react-intl";

const messages = defineMessages({
  unknown: {
    id: "hooks.useErrorTranslations.unknown",
    defaultMessage: "Something went wrong",
  },
  internalServer: {
    id: "hooks.useErrorTranslations.internalServer",
    defaultMessage: "Something went wrong on the server",
  },
});

export default messages;
