import { BaseError } from "./types";

const checkIsTrustedError = (error: any): error is BaseError => {
  return !!error.type;
};

export default checkIsTrustedError;
