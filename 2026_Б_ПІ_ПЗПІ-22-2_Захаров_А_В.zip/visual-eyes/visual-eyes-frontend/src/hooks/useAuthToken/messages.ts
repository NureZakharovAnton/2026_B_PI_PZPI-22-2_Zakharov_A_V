import { defineMessages } from "react-intl";

export default defineMessages({
  sessionEnded: {
    id: "hooks.useAuthToken.sessionEnded",
    defaultMessage: "Session has ended. Please login again",
  },
});
