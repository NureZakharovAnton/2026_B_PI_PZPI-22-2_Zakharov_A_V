import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    sessionEnded: intl.formatMessage(messages.sessionEnded),
  };

  return translations;
};

export default useTranslations;
