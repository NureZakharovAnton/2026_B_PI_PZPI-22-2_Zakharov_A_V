import Cookies from "js-cookie";
import { useAlert, useAuth } from "../../redux/hooks";
import useTranslations from "./useTranslations";

const useAuthToken = () => {
  const { logout } = useAuth();
  const { showErrorAlert } = useAlert();
  const { sessionEnded } = useTranslations();

  // TODO: add handle of expired token to both frontend and backend

  const logoutExpired = () => {
    const token = Cookies.get("token");

    if (!token) {
      logout();
      showErrorAlert(`${sessionEnded} 🕑`);
    }
  };

  return {
    logoutExpired,
  };
};

export default useAuthToken;
