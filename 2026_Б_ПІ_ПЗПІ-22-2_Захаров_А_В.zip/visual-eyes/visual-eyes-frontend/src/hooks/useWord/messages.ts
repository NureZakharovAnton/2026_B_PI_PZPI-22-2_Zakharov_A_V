import { defineMessages } from "react-intl";

const messages = defineMessages({
  pageDescription: {
    id: "Product.ProductWordReportButton.pageDescription",
    defaultMessage: "Products report for",
  },
  title: {
    id: "Product.ProductWordReportButton.title",
    defaultMessage: "title",
  },
  description: {
    id: "Product.ProductWordReportButton.description",
    defaultMessage: "description",
  },
  price: {
    id: "Product.ProductWordReportButton.price",
    defaultMessage: "price",
  },
  imageURL: {
    id: "Product.ProductWordReportButton.imageURL",
    defaultMessage: "image URL",
  },
  pageCaption: {
    id: "Product.ProductWordReportButton.pageCaption",
    defaultMessage: "Generated on",
  },
});

export default messages;
