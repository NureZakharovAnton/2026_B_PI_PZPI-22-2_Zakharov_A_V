import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    pageDescription: intl.formatMessage(messages.pageDescription),
    title: intl.formatMessage(messages.title),
    description: intl.formatMessage(messages.description),
    price: intl.formatMessage(messages.price),
    imageURL: intl.formatMessage(messages.imageURL),
    pageCaption: intl.formatMessage(messages.pageCaption),
  };

  return translations;
};

export default useTranslations;
