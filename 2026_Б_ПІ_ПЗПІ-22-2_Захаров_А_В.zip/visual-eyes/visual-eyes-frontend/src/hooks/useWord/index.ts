export { default as useWord } from "./useWord";
