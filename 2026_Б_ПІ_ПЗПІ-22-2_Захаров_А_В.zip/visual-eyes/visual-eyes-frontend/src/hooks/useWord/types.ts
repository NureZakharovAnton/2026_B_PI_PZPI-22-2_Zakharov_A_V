import { Product } from "../../redux/API";
import { productPropsForDocxSave } from "./constants";

export type DocxReportStyles = {
  primaryColor: string;
  secondaryColor: string;
  contrastColor: string;
  bodyColor: string;
};

export type DocxReportTranslations = {
  pageDescription: string;
  title: string;
  description: string;
  price: string;
  imageURL: string;
  pageCaption: string;
};

export type DocxReportColorMapper = {
  [key in (typeof productPropsForDocxSave)[number]]?: string;
};

export type DocxReportTranslationMapper = {
  [key in (typeof productPropsForDocxSave)[number]]: string;
};

export type SaveProductsToDocxArgs = {
  products: Product[];
};
