import { useTheme } from "..";
import { SaveProductsToDocxArgs } from "./types";
import useTranslations from "./useTranslations";
import ProductWordFile from "./ProductWordFile";

const useWord = () => {
  const theme = useTheme();
  const translations = useTranslations();

  const saveProductsToDocx = async ({ products }: SaveProductsToDocxArgs) => {
    const wordFile = new ProductWordFile(theme, translations);

    wordFile.addTitle();
    wordFile.addEmptyLine();
    wordFile.addEmptyLine();
    wordFile.addProducts(products);
    wordFile.addCaption();

    await wordFile.saveDocument();
  };

  return { saveProductsToDocx };
};

export default useWord;
