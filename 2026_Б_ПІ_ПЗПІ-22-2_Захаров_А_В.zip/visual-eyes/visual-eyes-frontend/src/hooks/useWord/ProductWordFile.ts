import { format } from "date-fns";
import { Paragraph, TextRun, HeadingLevel, Packer, Document } from "docx";
import { Theme } from "@mui/material";
import saveAs from "file-saver";
import { Product } from "../../redux/API";
import { APP_TITLE, APP_URL } from "../../common/constants";
import {
  WORD_REPORT_FONT,
  WORD_REPORT_TITLE_SIZE,
  productPropsForDocxSave,
  WORD_REPORT_BODY_SIZE,
} from "./constants";
import {
  DocxReportStyles,
  DocxReportTranslations,
  DocxReportTranslationMapper,
  DocxReportColorMapper,
} from "./types";

export default class ProductWordFile {
  private paragraphs: Paragraph[];
  private fileName: string;
  private styles: DocxReportStyles;
  private translations: DocxReportTranslations;
  private keysTranslations: DocxReportTranslationMapper;
  private keysColors: DocxReportColorMapper;

  constructor(theme: Theme, translations: DocxReportTranslations) {
    this.paragraphs = [];
    this.translations = translations;

    const formattedDate = this.formatCurrentDate();
    this.fileName = `products-report-${formattedDate}.docx`;

    this.styles = {
      primaryColor: theme.palette.primary.main,
      secondaryColor: theme.palette.grey[500],
      contrastColor: theme.palette.common.white,
      bodyColor: theme.palette.common.black,
    };

    this.keysTranslations = {
      title: translations.title,
      imageURL: translations.imageURL,
      price: translations.price,
      description: translations.description,
    };

    this.keysColors = {
      price: this.styles.secondaryColor,
      title: this.styles.primaryColor,
    };
  }

  formatCurrentDate() {
    const currentDate = new Date();
    return format(currentDate, "dd-MM-yyyy");
  }

  addTitle() {
    const titleParagraph = this.createTitleParagraph();
    this.paragraphs.push(titleParagraph);
  }

  createTitleParagraph() {
    const formattedDate = this.formatCurrentDate();

    const titleParagraph = new Paragraph({
      children: [
        new TextRun({
          text: APP_TITLE,
          font: WORD_REPORT_FONT,
          size: WORD_REPORT_TITLE_SIZE,
          color: this.styles.contrastColor,
        }),
        new TextRun({
          break: 1,
        }),
        new TextRun({
          text: `${this.translations.pageDescription} ${formattedDate}`,
          font: WORD_REPORT_FONT,
          size: WORD_REPORT_TITLE_SIZE,
          color: this.styles.contrastColor,
        }),
      ],
      heading: HeadingLevel.TITLE,
      spacing: {
        before: 240,
        after: 240,
      },
      shading: {
        fill: this.styles.primaryColor,
      },
    });

    return titleParagraph;
  }

  addEmptyLine() {
    this.paragraphs.push(new Paragraph(""));
  }

  addProducts(products: Product[]) {
    products.forEach((product) => {
      productPropsForDocxSave.forEach((key) => {
        const shouldSkipProp = !product[key];
        if (shouldSkipProp) return;

        const productLabel = this.keysTranslations[key];
        const productValue = product[key];

        const specialColor = this.keysColors[key];

        const textRun = new TextRun({
          text: `${productLabel}: ${productValue}`,
          font: WORD_REPORT_FONT,
          size: WORD_REPORT_BODY_SIZE,
          color: specialColor || this.styles.bodyColor,
        });

        this.paragraphs.push(new Paragraph({ children: [textRun] }));
      });
      this.paragraphs.push(new Paragraph(""));
    });
  }

  addCaption() {
    const captionParagraph = this.createCaptureParagraph();
    this.paragraphs.push(captionParagraph);
  }

  createCaptureParagraph() {
    const captionTextRun = new TextRun({
      text: `${this.translations.pageCaption} ${APP_URL}`,
      font: WORD_REPORT_FONT,
      size: WORD_REPORT_BODY_SIZE,
      color: this.styles.primaryColor,
    });

    const captionParagraph = new Paragraph({ children: [captionTextRun] });
    return captionParagraph;
  }

  async saveDocument() {
    const doc = this.createDocument();
    const blob = await Packer.toBlob(doc);

    saveAs(blob, this.fileName);
  }

  createDocument() {
    const doc = new Document({
      sections: [
        {
          children: this.paragraphs,
        },
      ],
    });

    return doc;
  }
}
