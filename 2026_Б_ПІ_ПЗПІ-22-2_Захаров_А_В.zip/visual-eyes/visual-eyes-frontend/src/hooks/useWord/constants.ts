export const productPropsForDocxSave = [
  "title",
  "imageURL",
  "price",
  "description",
] as const;

export const WORD_REPORT_FONT = "HoloLens MDL2 Assets";
export const WORD_REPORT_TITLE_SIZE = 56;
export const WORD_REPORT_BODY_SIZE = 28;
