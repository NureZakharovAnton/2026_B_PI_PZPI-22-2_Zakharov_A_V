import { SxProps } from "@mui/system";

export default SxProps;
