import SxProps from "./SxProps";

interface SxConfig {
  [key: string]: SxProps;
}

export default SxConfig;
