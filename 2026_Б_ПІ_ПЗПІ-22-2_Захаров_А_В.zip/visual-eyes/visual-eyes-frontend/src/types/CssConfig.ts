import { CSSProperties } from "react";

type CssConfig = {
  [key: string]: CSSProperties;
};

export default CssConfig;
