import createTheme from "@mui/material/styles/createTheme";
import { SPACING, borderRadius, palette, shadows, typography } from "./config";

const theme = createTheme({
  spacing: SPACING,
  palette,
  typography,
  shadows,
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: borderRadius.medium,
        },
      },
    },
  },
});

export default theme;
