export type BorderRadius = {
  medium: number;
};
