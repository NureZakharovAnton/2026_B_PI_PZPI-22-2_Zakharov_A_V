import { Shadows } from "@mui/material";
import { BorderRadius } from "./types";
import { multipleSpacing } from "./utils";

export const SPACING = 8;

export const palette = {
  primary: {
    main: "#437EF7",
    light: "#F3F9FE",
    dark: "#135DCB",
  },
  grey: {
    "200": "#EAEBF0",
    "300": "#5F6D7E",
    "400": "#585858",
  },
  success: {
    main: "#00C48C",
    dark: "#308408",
    light: "#C4FFAF",
  },
  error: {
    main: "#F44336",
    dark: "#840F08",
    light: "#FFCCAF",
  },
  common: {
    black: "#272D37",
    white: "#ffffff",
  },
};

export const typography = {
  fontFamily: "Inter",
  h1: {
    fontSize: 28,
    fontWeight: 600,
    lineHeight: 1.5,
    color: palette.common.black,
  },
  h2: {
    fontSize: 20,
    fontStyle: "normal",
    fontWeight: 600,
    lineHeight: 1.5,
    letterSpacing: -0.1,
  },
  p: {
    fontWeight: 400,
    fontSize: 16,
    lineHeight: 1.5,
    color: palette.grey[300],
  },
  normalMediumBlack: {
    fontSize: 16,
    fontStyle: "normal",
    fontWeight: 500,
    lineHeight: 1.5,
    color: palette.common.black,
    letterSpacing: -0.1,
  },
  chartViewMore: {
    fontSize: 14,
    fontStyle: "normal",
    fontWeight: 600,
    lineHeight: 1.4,
    letterSpacing: -0.1,
    color: palette.grey[300],
  },
  chartLinkText: {
    fontSize: 14,
    fontStyle: "normal",
    fontWeight: 600,
    lineHeight: 1.4,
    letterSpacing: -0.1,
    color: palette.primary.main,
  },
  title: {
    fontSize: 40,
    fontWeight: 700,
    lineHeight: "normal",
    color: palette.common.black,
    textTransform: "uppercase",
  },
  secondaryTitle: {
    fontSize: 20,
    fontWeight: 400,
    lineHeight: 1.5,
    color: palette.common.black,
  },
  priceText: {
    fontSize: 24,
    fontWeight: 400,
    lineHeight: 1.5,
    color: palette.grey[300],
  },
  submitButton: {
    fontSize: 18,
  },
  link: {
    color: palette.primary.main,
  },
  infoLabel: {
    fontSize: 28,
    color: palette.common.black,
  },
  infoValue: {
    fontSize: 28,
    color: palette.grey[300],
  },
};

export const borderRadius: BorderRadius = {
  medium: multipleSpacing(2),
};

export const shadows: Shadows = [
  "none",
  "0px 0px 3px rgba(16, 24, 40, 0.4)",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
  "none",
];
