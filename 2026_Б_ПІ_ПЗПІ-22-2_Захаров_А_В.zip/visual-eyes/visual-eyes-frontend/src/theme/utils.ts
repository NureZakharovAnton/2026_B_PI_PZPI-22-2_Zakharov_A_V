import { SPACING } from "./config";

export const multipleSpacing = (value: number) => value * SPACING;
