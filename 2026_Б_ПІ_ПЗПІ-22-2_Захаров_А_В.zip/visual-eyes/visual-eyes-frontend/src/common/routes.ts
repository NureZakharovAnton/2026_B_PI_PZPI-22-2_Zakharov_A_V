enum ROUTES {
  ROOT = "/",
  DASHBOARD = "/dashboard",
  NOTIFICATIONS = "/notifications",
  SHOPS = "/shops",
  PRODUCTS = "/products",
  PRODUCT_DETAILS = "/products/:slug",
  LOGIN = "/login",
  REGISTRATION = "/registration",
}

export default ROUTES;
