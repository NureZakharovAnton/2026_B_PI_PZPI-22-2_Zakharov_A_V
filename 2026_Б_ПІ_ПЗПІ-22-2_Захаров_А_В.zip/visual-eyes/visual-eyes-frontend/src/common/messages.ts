import { defineMessages } from "react-intl";

const messages = defineMessages({
  invalidEmail: {
    id: "Registration.RegistrationScreen.invalidEmail",
    defaultMessage: "Invalid email",
  },
  emailRequired: {
    id: "Registration.RegistrationScreen.emailRequired",
    defaultMessage: "Email is required",
  },
  maxEmailLength: {
    id: "Registration.RegistrationScreen.maxEmailLength",
    defaultMessage: "Email is too long",
  },
  emailPlaceholder: {
    id: "Registration.RegistrationScreen.emailInputPlaceholder",
    defaultMessage: "Email",
  },
  passwordPlaceholder: {
    id: "Registration.RegistrationScreen.passwordInputPlaceholder",
    defaultMessage: "Password",
  },
  minPasswordLength: {
    id: "Registration.RegistrationScreen.minPasswordLength",
    defaultMessage: "Password is too short",
  },
  maxPasswordLength: {
    id: "Registration.RegistrationScreen.maxPasswordLength",
    defaultMessage: "Password is too long",
  },
  passwordRequired: {
    id: "Registration.RegistrationScreen.passwordRequired",
    defaultMessage: "Password is required",
  },
  nicknamePlaceholder: {
    id: "Registration.RegistrationScreen.nicknamePlaceholder",
    defaultMessage: "nickname",
  },
  nicknameRequired: {
    id: "Registration.RegistrationScreen.nicknameRequired",
    defaultMessage: "nickname is required",
  },
  minNicknameLength: {
    id: "Registration.RegistrationScreen.minNicknameLength",
    defaultMessage: "nickname is too short",
  },
  maxNicknameLength: {
    id: "Registration.RegistrationScreen.maxNicknameLength",
    defaultMessage: "nickname is too long",
  },
  invalidNickname: {
    id: "Registration.RegistrationScreen.invalidNickname",
    defaultMessage: "Invalid nickname",
  },
});

export default messages;
