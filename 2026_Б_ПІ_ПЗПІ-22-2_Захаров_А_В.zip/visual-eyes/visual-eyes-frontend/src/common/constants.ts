export const MIN_PASSWORD_LENGTH = 6;
export const MIN_NICKNAME_LENGTH = 3;
export const MAX_NICKNAME_LENGTH = 50;
export const MAX_PASSWORD_LENGTH = 100;
export const MAX_EMAIL_LENGTH = 100;

export const DEFAULT_USER_NICKNAME = "User";

export const PLACEHOLDER_IMAGE_SRC = "/images/placeholder.jpg";

export const APP_TITLE = "Visual Eyes";
export const APP_URL = "visual-eyes.com";
