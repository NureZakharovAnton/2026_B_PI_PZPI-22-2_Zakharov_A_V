export type AlertType = "error" | "success" | "warning";

export type AlertState = {
  message: string;
  type?: AlertType;
  isOpen?: boolean;
  timeout?: number;
};

export type AlertSliceState = AlertState;
export type AlertOptions = Omit<AlertState, "message">;
