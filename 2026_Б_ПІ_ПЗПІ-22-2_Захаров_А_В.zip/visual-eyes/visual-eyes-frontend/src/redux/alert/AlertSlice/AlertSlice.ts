import { createSlice } from "@reduxjs/toolkit";
import { AlertSliceState } from "./types";

const initialState: AlertSliceState = {
  message: "",
  type: "success",
  isOpen: false,
  timeout: 3000,
};

export const AlertSlice = createSlice({
  name: "alert",
  initialState,
  reducers: {
    createAlert: (_state, action) => ({
      ...initialState,
      ...action.payload,
      isOpen: true,
    }),
    removeAlert: (state) => ({ ...state, isOpen: false }),
  },
});

export default AlertSlice;
export const alertReducer = AlertSlice.reducer;
export const alertActions = AlertSlice.actions;
