import { configureStore } from "@reduxjs/toolkit";
import { setupListeners } from "@reduxjs/toolkit/query/react";
import { authReducer } from "../auth";
import { alertReducer } from "../alert";
import { CategoryAPI, ProductAPI, ShopAPI } from "../API";

const store = configureStore({
  reducer: {
    auth: authReducer,
    alert: alertReducer,
    [ProductAPI.reducerPath]: ProductAPI.reducer,
    [ShopAPI.reducerPath]: ShopAPI.reducer,
    [CategoryAPI.reducerPath]: CategoryAPI.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware()
      .concat(ProductAPI.middleware)
      .concat(ShopAPI.middleware)
      .concat(CategoryAPI.middleware),
});

setupListeners(store.dispatch);

export default store;
