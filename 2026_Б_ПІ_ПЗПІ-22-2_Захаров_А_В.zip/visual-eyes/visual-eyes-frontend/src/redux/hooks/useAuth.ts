import { useSelector } from "react-redux";
import Cookies from "js-cookie";
import { LoginRequest, RegistrationRequest } from "../../API";
import { RootState } from "../store";
import { AuthSliceState, loginUser, registerUser, logoutUser } from "../auth";
import useAppDispatch from "./useAppDispatch";

const useAuth = () => {
  const { user, isLoading } = useSelector<RootState, AuthSliceState>(
    (state) => state.auth
  );

  const token = Cookies.get("token");
  const isLoggedIn = !!user && !!token;

  const dispatch = useAppDispatch();

  const login = async (req: LoginRequest) => {
    const res = await dispatch(loginUser(req)).unwrap();
    return res;
  };

  const register = async (req: RegistrationRequest) => {
    const res = await dispatch(registerUser(req)).unwrap();
    return res;
  };

  const logout = () => {
    return dispatch(logoutUser());
  };

  return {
    user,
    isLoggedIn,
    isLoading,
    login,
    register,
    logout,
  };
};

export default useAuth;
