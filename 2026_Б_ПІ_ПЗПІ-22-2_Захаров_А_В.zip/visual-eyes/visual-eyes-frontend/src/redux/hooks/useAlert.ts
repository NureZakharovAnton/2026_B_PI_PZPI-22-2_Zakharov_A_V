import { useSelector } from "react-redux";
import { useErrorTranslations } from "../../hooks";
import {
  AlertOptions,
  AlertSliceState,
  AlertState,
  alertActions,
} from "../alert";

import { RootState } from "../store";
import useAppDispatch from "./useAppDispatch";

const useAlert = () => {
  const alert = useSelector<RootState, AlertSliceState>((state) => state.alert);
  const dispatch = useAppDispatch();

  const { translateErrorMessage } = useErrorTranslations();

  const showAlert = (state: AlertState) => {
    dispatch(alertActions.createAlert(state));
  };

  const hideAlert = () => {
    dispatch(alertActions.removeAlert());
  };

  const showErrorAlert = (message: string, options?: AlertOptions) => {
    showAlert({ message, type: "error", ...options });
  };

  const showSuccessAlert = (message: string, options?: AlertOptions) => {
    showAlert({ message, type: "success", ...options });
  };

  const showWarningAlert = (message: string, options?: AlertOptions) => {
    showAlert({ message, type: "warning", ...options });
  };

  const showTranslatedErrorAlert = (error: unknown) => {
    const errorMessage = translateErrorMessage(error);
    showErrorAlert(errorMessage);
  };

  return {
    alert,
    hideAlert,
    showSuccessAlert,
    showErrorAlert,
    showWarningAlert,
    showTranslatedErrorAlert,
  };
};

export default useAlert;
