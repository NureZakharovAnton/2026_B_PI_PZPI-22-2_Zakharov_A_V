import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import TAGS from "../tags";
import { Product, ProductFilterParams } from "./types";
import getFilteredProductsURL from "./getFilteredProductsURL";

export const ProductAPI = createApi({
  reducerPath: "ProductAPI",
  baseQuery: fetchBaseQuery({
    baseUrl: "http://localhost:5002/api/v1",
    credentials: "include",
  }),
  tagTypes: [TAGS.PRODUCTS],
  endpoints: (builder) => ({
    getProducts: builder.query<Product[], ProductFilterParams>({
      query: (filterParams) => getFilteredProductsURL(filterParams),
      providesTags: [TAGS.PRODUCTS],
    }),
    getProductBySlug: builder.query<Product, string>({
      query: (slug) => `products/${slug}`,
      providesTags: [TAGS.PRODUCTS],
    }),
    createProduct: builder.mutation<Product, Product>({
      query: (product) => ({
        url: "products",
        method: "POST",
        body: product,
      }),
      invalidatesTags: [TAGS.PRODUCTS],
    }),
    updateProductById: builder.mutation<Product, Product>({
      query: (product) => ({
        url: `products/${product.id}`,
        method: "PUT",
        body: product,
      }),
      invalidatesTags: [TAGS.PRODUCTS],
    }),
    deleteProductById: builder.mutation<void, string>({
      query: (id) => ({
        url: `products/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: [TAGS.PRODUCTS],
    }),
  }),
});

export const {
  useGetProductsQuery,
  useGetProductBySlugQuery,
  useCreateProductMutation,
  useUpdateProductByIdMutation,
  useDeleteProductByIdMutation,
} = ProductAPI;
