import { Currency, Id, SortBy } from "../types";

export type Product = {
  id: string;
  title: string;
  price: number;
  currency: Currency;
  imageURL: string;
  siteURL: string;
  slug: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
};

export type ProductFilterParams = {
  searchValue?: string;
  sortBy?: SortBy;
  priceFrom?: number;
  priceTo?: number;
  shops?: Id[];
  categories?: Id[];
};
