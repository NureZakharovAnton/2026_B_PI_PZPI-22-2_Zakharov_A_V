import { ProductFilterParams } from "./types";

const getFilteredProductsURL = (filterParams: ProductFilterParams) => {
  const { searchValue, sortBy, priceFrom, priceTo, shops, categories } =
    filterParams;
  let url = "products?";

  if (searchValue) {
    url += `searchValue=${searchValue}`;
  }

  if (sortBy) {
    url += `&sortBy=${sortBy}`;
  }

  if (priceFrom) {
    url += `&priceFrom=${priceFrom}`;
  }

  if (priceTo) {
    url += `&priceTo=${priceTo}`;
  }

  if (shops) {
    url += `&shops=${encodeURIComponent(JSON.stringify(shops))}`;
  }

  if (categories) {
    url += `&categories=${encodeURIComponent(JSON.stringify(categories))}`;
  }

  return url;
};

export default getFilteredProductsURL;
