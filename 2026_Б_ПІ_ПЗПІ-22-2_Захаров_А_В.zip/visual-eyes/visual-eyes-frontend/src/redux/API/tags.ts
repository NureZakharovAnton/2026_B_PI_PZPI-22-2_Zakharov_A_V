enum TAGS {
  PRODUCTS = "products",
  SHOPS = "shops",
  CATEGORIES = "categories",
}

export default TAGS;
