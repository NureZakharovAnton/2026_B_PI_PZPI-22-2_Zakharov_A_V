import { SortBy } from "../types";

export type Shop = {
  id: string;
  title: string;
  description?: string;
  imageURL?: string;
  siteURL: string;
  createdAt: string;
  updatedAt: string;
};

export type ShopFilterParams = {
  searchValue?: string;
  sortBy?: SortBy;
};
