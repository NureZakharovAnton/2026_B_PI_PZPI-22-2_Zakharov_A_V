import { ShopFilterParams } from "./types";

const getFilteredShopsURL = (filterParams: ShopFilterParams) => {
  const { searchValue, sortBy } = filterParams;
  let url = "shops?";

  if (searchValue) {
    url += `searchValue=${searchValue}`;
  }

  if (sortBy) {
    url += `&sortBy=${sortBy}`;
  }

  return url;
};

export default getFilteredShopsURL;
