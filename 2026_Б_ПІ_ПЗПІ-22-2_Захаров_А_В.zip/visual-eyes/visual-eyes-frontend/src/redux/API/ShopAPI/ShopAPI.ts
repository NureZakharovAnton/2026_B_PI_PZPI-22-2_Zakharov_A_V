import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import TAGS from "../tags";
import { Shop, ShopFilterParams } from "./types";
import getFilteredShopsURL from "./getFilteredShopsURL";

export const ShopAPI = createApi({
  reducerPath: "ShopAPI",
  baseQuery: fetchBaseQuery({
    baseUrl: "http://localhost:5002/api/v1",
    credentials: "include",
  }),
  tagTypes: [TAGS.SHOPS],
  endpoints: (builder) => ({
    getShops: builder.query<Shop[], ShopFilterParams>({
      query: (params) => getFilteredShopsURL(params),
      providesTags: [TAGS.SHOPS],
    }),
    updateShopById: builder.mutation<Shop, Shop>({
      query: (shop) => ({
        url: `shops/${shop.id}`,
        method: "PUT",
        body: shop,
      }),
      invalidatesTags: [TAGS.SHOPS],
    }),
    deleteShopById: builder.mutation<void, string>({
      query: (id) => ({
        url: `shops/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: [TAGS.SHOPS],
    }),
  }),
});

export const {
  useGetShopsQuery,
  useUpdateShopByIdMutation,
  useDeleteShopByIdMutation,
} = ShopAPI;
