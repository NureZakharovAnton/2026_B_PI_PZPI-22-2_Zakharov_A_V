export type SortBy = "asc" | "desc" | "";
export type Currency = "$" | "₴";
export type Id = { id: string };
