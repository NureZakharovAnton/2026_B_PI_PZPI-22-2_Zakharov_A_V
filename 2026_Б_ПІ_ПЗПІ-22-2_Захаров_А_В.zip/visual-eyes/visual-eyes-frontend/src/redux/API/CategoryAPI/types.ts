import { SortBy } from "../types";

export type Category = {
  id: string;
  title: string;
  imageURL: string;
  description: string;
  createdAt: string;
  updatedAt: string;
};

export type CategoryFilterParams = {
  searchValue?: string;
  sortBy?: SortBy;
};
