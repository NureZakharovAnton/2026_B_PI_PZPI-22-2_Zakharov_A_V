import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import TAGS from "../tags";
import { Category, CategoryFilterParams } from "./types";
import getFilteredCategoriesURL from "./getFilteredCategoriesURL";

export const CategoryAPI = createApi({
  reducerPath: "CategoryAPI",
  baseQuery: fetchBaseQuery({
    baseUrl: "http://localhost:5002/api/v1", // TODO: add env variable
    credentials: "include",
  }),
  tagTypes: [TAGS.CATEGORIES],
  endpoints: (builder) => ({
    getCategories: builder.query<Category[], CategoryFilterParams>({
      query: (filterParams) => getFilteredCategoriesURL(filterParams),
      providesTags: [TAGS.CATEGORIES],
    }),

    createCategory: builder.mutation<Category, Category>({
      query: (category) => ({
        url: "categories",
        method: "POST",
        body: category,
      }),
      invalidatesTags: [TAGS.CATEGORIES],
    }),
    updateCategoryById: builder.mutation<Category, Category>({
      query: (category) => ({
        url: `categories/${category.id}`,
        method: "PUT",
        body: category,
      }),
      invalidatesTags: [TAGS.CATEGORIES],
    }),
    deleteCategoryById: builder.mutation<void, string>({
      query: (id) => ({
        url: `categories/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: [TAGS.CATEGORIES],
    }),
  }),
});

export const {
  useGetCategoriesQuery,
  useCreateCategoryMutation,
  useUpdateCategoryByIdMutation,
  useDeleteCategoryByIdMutation,
} = CategoryAPI;
