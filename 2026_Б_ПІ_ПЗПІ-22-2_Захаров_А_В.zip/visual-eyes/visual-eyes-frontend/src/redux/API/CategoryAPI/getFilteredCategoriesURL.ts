import { CategoryFilterParams } from "./types";

const getFilteredCategoriesURL = (filterParams: CategoryFilterParams) => {
  const { searchValue, sortBy } = filterParams;
  let url = "categories?";

  if (searchValue) {
    url += `searchValue=${searchValue}`;
  }

  if (sortBy) {
    url += `&sortBy=${sortBy}`;
  }

  return url;
};

export default getFilteredCategoriesURL;
