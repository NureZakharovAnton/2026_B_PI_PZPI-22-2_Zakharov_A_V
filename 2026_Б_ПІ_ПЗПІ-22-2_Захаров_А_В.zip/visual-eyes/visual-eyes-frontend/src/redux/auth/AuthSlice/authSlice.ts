import { createSlice } from "@reduxjs/toolkit";
import { loginUser, registerUser } from "../AuthActions/authActions";
import { AuthSliceState } from "./types";

const userStorageItem = localStorage.getItem("user");
const user = userStorageItem ? JSON.parse(userStorageItem) : null;

const initialState: AuthSliceState = {
  isLoading: false,
  user,
};

const AuthSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logoutUser: (state) => {
      localStorage.removeItem("user");
      state.isLoading = false;
      state.user = null;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(registerUser.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(registerUser.fulfilled, (state, { payload }) => {
      state.isLoading = false;
      state.user = payload.user;
    });
    builder.addCase(registerUser.rejected, (state, { payload }) => {
      state.isLoading = false;
    });

    builder.addCase(loginUser.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(loginUser.fulfilled, (state, { payload }) => {
      state.isLoading = false;
      state.user = payload.user;
    });
    builder.addCase(loginUser.rejected, (state, { payload }) => {
      state.isLoading = false;
    });
  },
});

export default AuthSlice;
export const { logoutUser } = AuthSlice.actions;
export const authReducer = AuthSlice.reducer;
