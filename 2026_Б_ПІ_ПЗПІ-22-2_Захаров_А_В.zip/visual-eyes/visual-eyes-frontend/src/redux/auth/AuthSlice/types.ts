import { User } from "../../../types";

export interface AuthSliceState {
  isLoading: boolean;
  user: User | null;
}
