import { createAsyncThunk } from "@reduxjs/toolkit";
import Cookies from "js-cookie";
import { AuthAPI, LoginRequest, RegistrationRequest } from "../../../API";
import { User } from "../../../types";
import { BaseError } from "../../../hooks/useErrorTranslations";

interface AuthorizationResponse {
  user: User;
  token: string;
}

const tokenExpiresDays = 30;

export const registerUser = createAsyncThunk<
  AuthorizationResponse,
  RegistrationRequest,
  { rejectValue: BaseError }
>("auth/register", async (req: RegistrationRequest, { rejectWithValue }) => {
  try {
    const { data } = await AuthAPI.register(req);
    localStorage.setItem("user", JSON.stringify(data.user));

    Cookies.set("token", data.token, {
      expires: tokenExpiresDays,
    });

    return data;
  } catch (error) {
    const handledError: BaseError = { type: "UNKNOWN" };
    return rejectWithValue(handledError);
  }
});

export const loginUser = createAsyncThunk<
  AuthorizationResponse,
  LoginRequest,
  { rejectValue: BaseError }
>("auth/login", async (req: LoginRequest, { rejectWithValue }) => {
  try {
    const { data } = await AuthAPI.login(req);
    localStorage.setItem("user", JSON.stringify(data.user));

    Cookies.set("token", data.token, {
      expires: tokenExpiresDays,
    });

    return data;
  } catch (error) {
    const handledError: BaseError = { type: "UNKNOWN" };
    return rejectWithValue(handledError);
  }
});
