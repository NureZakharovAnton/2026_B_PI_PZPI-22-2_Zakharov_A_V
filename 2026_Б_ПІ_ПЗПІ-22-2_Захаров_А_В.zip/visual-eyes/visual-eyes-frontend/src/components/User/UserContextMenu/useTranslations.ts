import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    logoutOption: intl.formatMessage(messages.logoutOption),
  };

  return translations;
};

export default useTranslations;
