import {
  bindMenu,
  bindTrigger,
  usePopupState,
} from "material-ui-popup-state/hooks";
import { useAuth } from "../../../redux/hooks";
import useTranslations from "./useTranslations";

const useUserContextMenu = () => {
  const { logout } = useAuth();
  const translations = useTranslations();

  const popoverState = usePopupState({
    variant: "popover",
    popupId: "UserContentMenu",
  });

  const handleLogout = () => {
    popoverState.close();
    logout();
  };

  const logoutOption = {
    onClick: handleLogout,
    text: translations.logoutOption,
  };

  const options = [logoutOption];

  const boundTriggerProps = bindTrigger(popoverState);
  const anchorElementProps = boundTriggerProps;

  const boundMenuProps = bindMenu(popoverState);
  const menuProps = {
    boundMenuProps,
    options,
  };

  return { menuProps, anchorElementProps };
};

export default useUserContextMenu;
