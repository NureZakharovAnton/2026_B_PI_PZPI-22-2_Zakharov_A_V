import { bindTrigger } from "material-ui-popup-state";
import { bindMenu } from "material-ui-popup-state/hooks";

export type UserContextMenuOption = {
  onClick: (e: React.MouseEvent) => void;
  text: string;
};

export type BoundTriggerProps = ReturnType<typeof bindTrigger>;
export type AnchorElementProps = BoundTriggerProps;

export type BoundMenuProps = ReturnType<typeof bindMenu>;
export type UserContextMenuProps = {
  boundMenuProps: BoundMenuProps;
  options: UserContextMenuOption[];
};
