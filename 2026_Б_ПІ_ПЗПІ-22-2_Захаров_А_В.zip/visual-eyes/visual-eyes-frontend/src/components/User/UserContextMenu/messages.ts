import { defineMessages } from "react-intl";

const messages = defineMessages({
  logoutOption: {
    id: "User.UserContextMenu.logoutOption",
    defaultMessage: "Logout",
  },
});

export default messages;
