import React from "react";
import Menu from "../../General/Menu";
import MenuItem from "../../General/MenuItem";
import { UserContextMenuProps } from "./types";

const UserContextMenu: React.FC<UserContextMenuProps> = ({
  boundMenuProps,
  options,
}) => {
  return (
    <Menu
      {...boundMenuProps}
      anchorOrigin={{ horizontal: "right", vertical: "top" }}
    >
      {options.map(({ onClick, text }) => (
        <MenuItem onClick={onClick} key={text}>
          {text}
        </MenuItem>
      ))}
    </Menu>
  );
};

export default UserContextMenu;
