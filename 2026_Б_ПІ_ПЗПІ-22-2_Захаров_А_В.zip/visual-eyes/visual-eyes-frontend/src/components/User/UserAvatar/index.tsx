import React from "react";
import stringToColor from "string-to-color";
import { useAuth } from "../../../redux/hooks";
import Avatar from "../../General/Avatar";
import Box from "../../General/Box";
import Typography from "../../General/Typography";
import useUserContextMenu from "../UserContextMenu/useUserContextMenu";
import UserContextMenu from "../UserContextMenu";
import style from "./style";

interface UserAvatarProps {
  isOpen: boolean;
}

const UserAvatar: React.FC<UserAvatarProps> = ({ isOpen }) => {
  const { user } = useAuth();
  const { menuProps, anchorElementProps } = useUserContextMenu();

  const firstLetter = user?.nickname[0];
  const firstCapitalLetter = firstLetter?.toUpperCase();
  const nickname = user?.nickname;

  const backgroundColor = stringToColor(nickname);

  return (
    <Box display="flex" alignItems="center">
      <Avatar sx={[style, { backgroundColor }]} {...anchorElementProps}>
        {firstCapitalLetter}
      </Avatar>
      <UserContextMenu {...menuProps} />
      {isOpen && (
        <Typography
          pl={2}
          typography="normalMediumBlack"
          overflow="hidden"
          textOverflow="ellipsis"
          whiteSpace="nowrap"
        >
          {nickname}
        </Typography>
      )}
    </Box>
  );
};

export default UserAvatar;
