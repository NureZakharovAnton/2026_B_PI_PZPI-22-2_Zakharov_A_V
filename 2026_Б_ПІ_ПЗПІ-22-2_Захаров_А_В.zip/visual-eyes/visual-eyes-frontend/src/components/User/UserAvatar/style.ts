const style = {
  width: 42,
  height: 42,
  borderWidth: 3,
  borderColor: "transparent",
  borderStyle: "solid",
  "&:hover": { borderColor: "primary.main", cursor: "pointer" },
};

export default style;
