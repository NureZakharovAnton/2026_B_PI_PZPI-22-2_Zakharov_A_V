import Alert from "@mui/material/Alert";

export * from "@mui/material/Alert";
export default Alert;
