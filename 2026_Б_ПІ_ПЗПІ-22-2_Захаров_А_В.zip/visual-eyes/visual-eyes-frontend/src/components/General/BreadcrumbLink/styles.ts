import { SxProps } from "../../../types";

const defaultLinkColor = "grey.300";
const lastLinkColor = "primary.main";
const hoverLinkColor = "primary.dark";

const defaultLink: SxProps = {
  "&:hover": { color: hoverLinkColor },
  color: defaultLinkColor,
  textDecoration: 'none',
};

const lastLink: SxProps = {
  color: lastLinkColor,
};

const styles = {
  defaultLink,
  lastLink,
};

export default styles;
