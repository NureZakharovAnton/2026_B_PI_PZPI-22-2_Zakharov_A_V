import React, { FC, ReactNode } from "react";
import NavLink from "../../Navigation/NavLink";
import Link from "../Link";
import styles from "./styles";

type BreadcrumbLinkProps = {
  breadcrumb: ReactNode;
  to: string;
  isLast: boolean;
};

const BreadcrumbLink: FC<BreadcrumbLinkProps> = ({
  breadcrumb,
  to,
  isLast,
}) => {
  return (
    <Link
      component={NavLink}
      to={to}
      sx={[styles.defaultLink, isLast && styles.lastLink]}
    >
      {breadcrumb}
    </Link>
  );
};

export default BreadcrumbLink;
