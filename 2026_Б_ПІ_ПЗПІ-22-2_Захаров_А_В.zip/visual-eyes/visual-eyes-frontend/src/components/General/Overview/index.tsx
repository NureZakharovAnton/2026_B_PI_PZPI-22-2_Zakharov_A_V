import React from "react";
import Stack from "../Stack";
import Typography from "../Typography";

interface OverviewProps {
  title: string;
  description: string;
}

//  TODO: add OverviewLayout
const Overview = ({ title, description }: OverviewProps) => {
  return (
    <Stack direction="column">
      <Typography typography="h1">{title}</Typography>
      <Typography typography="p">{description}</Typography>
    </Stack>
  );
};

export default Overview;
