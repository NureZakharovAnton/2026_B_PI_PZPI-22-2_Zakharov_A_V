import React, { FC, ReactNode, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useAuthToken } from "../../../hooks";
import NavigationLayout from "../../Navigation/NavigationLayout";
import BreadcrumbsLayout from "../BreadcrumbsLayout.tsx";

type AuthorizedLayoutProps = {
  children: ReactNode;
};

const AuthorizedLayout: FC<AuthorizedLayoutProps> = ({ children }) => {
  const { pathname } = useLocation();
  const { logoutExpired } = useAuthToken();

  useEffect(() => {
    logoutExpired();
  }, [pathname]);

  return (
    <NavigationLayout hasSpacing>
      <BreadcrumbsLayout>{children}</BreadcrumbsLayout>
    </NavigationLayout>
  );
};

export default AuthorizedLayout;
