import React, { useState } from "react";
import { PieChart as PieChartBase, Pie } from "recharts";
import ResponsiveContainer from "../ResponsiveContainer";
import renderActiveShape from "./renderActiveShape";
import { PieChartProps } from "./types";
import useStyles from "./useStyles";

const PieChart = ({ height, color, data }: PieChartProps) => {
  const styles = useStyles();

  const [activeIndex, setActiveIndex] = useState(0);

  const onPieEnter = (_: number, index: number) => {
    setActiveIndex(index);
  };

  return (
    <ResponsiveContainer height={height}>
      <PieChartBase style={styles.pieChart}>
        {
          // TODO: Pie legend https://stackoverflow.com/questions/44413185/custom-legend-labels-in-my-rechart-chart
        }
        <Pie
          activeIndex={activeIndex}
          activeShape={renderActiveShape}
          data={data}
          cx="50%"
          cy="50%"
          innerRadius={70}
          outerRadius={90}
          dataKey="value"
          onMouseEnter={onPieEnter}
          fill={color}
        />
      </PieChartBase>
    </ResponsiveContainer>
  );
};

export default PieChart;
