import { useTheme } from "../../../hooks";
import { SxConfig } from "../../../types";

const useStyles = () => {
  const theme = useTheme();

  const styles: SxConfig = {
    pieChart: {
      fontFamily: theme.typography.fontFamily,
    },
  };

  return styles;
};

export default useStyles;
