export interface PieChartDataItem {
  name: string;
  value: number;
  dataKey: string;
  fill?: string;
}

export interface PieChartProps {
  height: number;
  color: string;
  data: PieChartDataItem[];
}

export interface RenderActiveShapeArgs {
  cx: number;
  cy: number;
  midAngle: number;
  innerRadius: number;
  outerRadius: number;
  startAngle: number;
  endAngle: number;
  fill: string;
  payload: any;
  percent: number;
  value: number;
  name: string;
}
