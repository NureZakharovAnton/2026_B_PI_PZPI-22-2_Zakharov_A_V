const mockData = [
  { name: "Meat", value: 400, fill: "#135DCB", dataKey: "meat" },
  { name: "Milk", value: 400, fill: "#5CB1FF", dataKey: "milk" },
  { name: "Greens", value: 400, dataKey: "greens" },
];

export default mockData;
