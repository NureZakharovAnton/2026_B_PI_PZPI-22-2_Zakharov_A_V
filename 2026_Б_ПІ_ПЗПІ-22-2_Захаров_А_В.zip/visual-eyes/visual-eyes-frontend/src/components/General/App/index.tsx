import React from "react";
import { IntlProvider } from "react-intl";
import { ThemeProvider } from "@mui/material";
import { Provider as ReduxProvider } from "react-redux";
import { ErrorBoundary } from "react-error-boundary";
import translations from "../../../common/translations";
import theme from "../../../theme";
import { store } from "../../../redux/store";
import Root from "../Root";
import AlertProvider from "../AlertProvider";

const App = () => {
  return (
    <ErrorBoundary
      fallback={
        <>
          <div>Something went wrong 💥</div>
          <div>Reload the page, please 🥺</div>
        </>
      }
    >
      <React.StrictMode>
        <ReduxProvider store={store}>
          <IntlProvider key="en" locale="en" messages={translations.en}>
            <ThemeProvider theme={theme}>
              <AlertProvider>
                <Root />
              </AlertProvider>
            </ThemeProvider>
          </IntlProvider>
        </ReduxProvider>
      </React.StrictMode>
    </ErrorBoundary>
  );
};

export default App;
