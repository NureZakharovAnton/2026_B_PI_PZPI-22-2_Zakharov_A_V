import CardMedia from "@mui/material/CardMedia";

export default CardMedia;
export * from "@mui/material/CardMedia";
