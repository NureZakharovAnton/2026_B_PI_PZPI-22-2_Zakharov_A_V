import Snackbar from "@mui/material/Snackbar";

export * from "@mui/material/Snackbar";
export default Snackbar;
