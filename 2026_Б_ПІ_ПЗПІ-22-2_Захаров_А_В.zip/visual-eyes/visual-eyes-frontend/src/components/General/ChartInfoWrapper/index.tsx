import React, { ReactNode } from "react";
import Box from "../Box";
import styles from "./styles";
import Card from "../Card";

interface ChartInfoWrapperProps {
  children: ReactNode;
  topNode?: ReactNode;
  bottomNode?: ReactNode;
}

const ChartInfoWrapper = ({
  children,
  topNode,
  bottomNode,
}: ChartInfoWrapperProps) => {
  return (
    <Card elevation={1} sx={styles.container}>
      {topNode && <Box sx={styles.infoPanelTop}>{topNode}</Box>}
      {children}
      {bottomNode && <Box sx={styles.infoPanelBottom}>{bottomNode}</Box>}
    </Card>
  );
};

export default ChartInfoWrapper;
