import { SxConfig } from "../../../types";

const styles: SxConfig = {
  container: {
    borderColor: "grey.200",
  },
  infoPanelTop: {
    paddingTop: 2,
    paddingBottom: 2,
    paddingLeft: 2.5,
    paddingRight: 2.5,
    borderBottom: "1px solid",
    borderColor: "grey.200",
  },
  infoPanelBottom: {
    paddingTop: 2,
    paddingBottom: 2,
    paddingLeft: 2.5,
    paddingRight: 2.5,
    borderTop: "1px solid",
    borderColor: "grey.200",
  },
};

export default styles;
