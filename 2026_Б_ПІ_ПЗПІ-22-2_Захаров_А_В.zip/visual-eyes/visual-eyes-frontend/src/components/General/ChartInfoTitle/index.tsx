import React from "react";
import Typography from "../Typography";

export interface ChartInfoTitleProps {
  title: string;
}

const ChartInfoTitle = ({ title }: ChartInfoTitleProps) => {
  return <Typography typography="normalMediumBlack">{title}</Typography>;
};

export default ChartInfoTitle;
