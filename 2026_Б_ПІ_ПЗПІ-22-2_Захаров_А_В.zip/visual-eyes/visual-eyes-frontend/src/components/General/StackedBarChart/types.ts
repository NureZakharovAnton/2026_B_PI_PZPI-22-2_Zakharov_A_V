interface StackedBarDataItem {
  [key: string]: string | number;
}

export interface StackedBarChartProps {
  height: number;
  data: StackedBarDataItem[];
  color: string;
  xAxisKey: string;
  yAxisKey: string;
  legendTranslations: Record<string, string>;
}
