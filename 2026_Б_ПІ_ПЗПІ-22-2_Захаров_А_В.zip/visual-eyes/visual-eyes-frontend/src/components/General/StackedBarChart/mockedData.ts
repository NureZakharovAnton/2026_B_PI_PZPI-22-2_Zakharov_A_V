const mockedData = [
  {
    month: "January",
    price: 2400,
    amt: 2400,
  },
  {
    month: "February",
    price: 1398,
    amt: 2210,
  },
  {
    month: "March",
    price: 9800,
    amt: 2290,
  },
  {
    month: "April",
    price: 3908,
    amt: 2000,
  },
  {
    month: "May",
    price: 4800,
    amt: 2181,
  },
  {
    month: "June",
    price: 3800,
    amt: 2500,
  },
  {
    month: "July",
    price: 4300,
    amt: 2100,
  },
  {
    month: "August",
    price: 4300,
    amt: 2100,
  },
  {
    month: "September",
    price: 4300,
    amt: 2100,
  },
  {
    month: "October",
    price: 4300,
    amt: 2100,
  },
  {
    month: "November",
    price: 4300,
    amt: 2100,
  },
  {
    month: "December",
    price: 4300,
    amt: 2100,
  },
];

export default mockedData;
