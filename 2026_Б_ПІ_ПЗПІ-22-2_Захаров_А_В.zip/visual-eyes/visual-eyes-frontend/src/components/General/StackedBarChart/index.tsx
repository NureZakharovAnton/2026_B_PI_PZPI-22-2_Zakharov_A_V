import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import ResponsiveContainer from "../ResponsiveContainer";
import { StackedBarChartProps } from "./types";
import useStyles from "./useStyles";

const StackedBarChart = ({
  height,
  data,
  color,
  xAxisKey,
  yAxisKey,
  legendTranslations,
}: StackedBarChartProps) => {
  const styles = useStyles();

  return (
    <ResponsiveContainer height={height}>
      <BarChart data={data} style={styles.stackedBarChart}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={xAxisKey} />
        <YAxis dataKey={yAxisKey} tickFormatter={(value) => `${value}$`} />
        <Tooltip formatter={(value) => `${value}$`} />
        <Legend
          formatter={(key: keyof typeof legendTranslations) =>
            legendTranslations[key]
          }
        />
        <Bar dataKey={yAxisKey} stackId={yAxisKey} fill={color} />
      </BarChart>
    </ResponsiveContainer>
  );
};

export default StackedBarChart;
