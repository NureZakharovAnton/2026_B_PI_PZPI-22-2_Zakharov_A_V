import React, { ReactNode } from "react";
import ChartInfoWrapper from "../ChartInfoWrapper";
import ChartInfoTitle, { ChartInfoTitleProps } from "../ChartInfoTitle";
import ChartInfoDetails, { ChartInfoDetailsProps } from "../ChartInfoDetails";
import Box from "../Box";

interface ChartDescriptionWrapperProps {
  children: ReactNode;
  title: string;
  titleProps?: ChartInfoTitleProps;
  detailsProps?: ChartInfoDetailsProps;
}

const ChartDescriptionWrapper = ({
  children,
  title,
  titleProps,
  detailsProps,
}: ChartDescriptionWrapperProps) => {
  return (
    <ChartInfoWrapper
      topNode={<ChartInfoTitle title={title} {...titleProps} />}
      bottomNode={<ChartInfoDetails {...detailsProps} />}
    >
      <Box p={1}>{children}</Box>
    </ChartInfoWrapper>
  );
};

export default ChartDescriptionWrapper;
