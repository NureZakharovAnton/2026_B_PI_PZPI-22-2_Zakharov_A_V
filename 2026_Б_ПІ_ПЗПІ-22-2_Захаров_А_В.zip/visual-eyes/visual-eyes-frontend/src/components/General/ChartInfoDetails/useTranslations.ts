import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    title: intl.formatMessage(messages.title),
    buttonText: intl.formatMessage(messages.buttonText),
  };

  return translations;
};

export default useTranslations;
