import { defineMessages } from "react-intl";

export default defineMessages({
  title: {
    id: "General.ChartInfoDetails.title",
    defaultMessage: "View more",
  },
  buttonText: {
    id: "General.ChartInfoDetails.buttonText",
    defaultMessage: "Open",
  },
});
