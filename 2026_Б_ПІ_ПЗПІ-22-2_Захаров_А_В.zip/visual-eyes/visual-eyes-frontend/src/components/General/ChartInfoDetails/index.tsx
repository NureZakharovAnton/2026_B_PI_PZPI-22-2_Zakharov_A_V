import React from "react";
import { IconExternalLink } from "../Icons";
import Box from "../Box";
import Typography from "../Typography";
import useTranslations from "./useTranslations";

export interface ChartInfoDetailsProps {}

const ChartInfoDetails = () => {
  const translations = useTranslations();

  return (
    <Box display="flex" justifyContent="space-between">
      <Typography typography="chartViewMore">{translations.title}</Typography>
      <Box display="flex">
        <Typography typography="chartLinkText" mr={0.5}>
          {translations.buttonText}
        </Typography>
        <IconExternalLink />
      </Box>
    </Box>
  );
};

export default ChartInfoDetails;
