import Button from "@mui/lab/LoadingButton";

export default Button;
