import React, { ReactNode } from "react";
import { useAlert } from "../../../redux/hooks";
import Box from "../Box";
import Alert from "../Alert";
import Snackbar, { SnackbarCloseReason, SnackbarOrigin } from "../Snackbar";

interface AlertProviderProps {
  children: ReactNode;
}

const anchorOriginOptions: SnackbarOrigin = {
  vertical: "bottom",
  horizontal: "right",
};

const AlertProvider: React.FC<AlertProviderProps> = ({ children }) => {
  const { alert, hideAlert } = useAlert();

  const handleClose = (_: unknown, reason?: SnackbarCloseReason) => {
    if (reason !== "clickaway") {
      hideAlert();
    }
  };

  return (
    <Box>
      {children}
      <Snackbar
        open={alert.isOpen}
        onClose={handleClose}
        autoHideDuration={alert.timeout}
        anchorOrigin={anchorOriginOptions}
        key={alert.message}
      >
        <Alert severity={alert.type} variant="standard">
          {alert.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AlertProvider;
