import React from "react";
import {
  AreaChart as AreaChartBase,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import ResponsiveContainer from "../ResponsiveContainer";
import { AreaChartProps } from "./types";

const AreaChart = ({
  data,
  height,
  color,
  xAxisKey,
  yAxisKey,
}: AreaChartProps) => {
  return (
    <ResponsiveContainer height={height}>
      <AreaChartBase data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={xAxisKey} />
        <YAxis dataKey={yAxisKey} />
        <Tooltip formatter={(value) => `${value}$`} />
        <Area type="monotone" dataKey={yAxisKey} stroke={color} fill={color} />
      </AreaChartBase>
    </ResponsiveContainer>
  );
};

export default AreaChart;
