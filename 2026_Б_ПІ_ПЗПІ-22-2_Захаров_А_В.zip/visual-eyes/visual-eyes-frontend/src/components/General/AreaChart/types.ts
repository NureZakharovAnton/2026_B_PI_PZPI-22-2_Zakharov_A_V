export interface AreaChartDataItem {
  [key: string]: string | number;
}

export interface AreaChartProps {
  data: AreaChartDataItem[];
  height: number;
  color: string;
  xAxisKey: string;
  yAxisKey: string;
}
