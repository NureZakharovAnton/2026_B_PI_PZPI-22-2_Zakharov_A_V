const data = [
  {
    day: "Mon",
    price: 4000,
  },
  {
    day: "Tue",
    price: 3000,
  },
  {
    day: "Wed",
    price: 2000,
  },
  {
    day: "Thu",
    price: 2780,
  },
  {
    day: "Fri",
    price: 1890,
  },
  {
    day: "Sut",
    price: 2390,
  },
  {
    day: "Sun",
    price: 3490,
  },
];

export default data;
