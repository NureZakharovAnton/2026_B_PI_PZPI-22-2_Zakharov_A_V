import { Link, LinkProps } from "react-router-dom";
import Typography, { TypographyProps } from "../Typography";
import styles from "./styles";

interface RouterLinkProps extends LinkProps {
  typographyProps?: TypographyProps;
}

const RouterLink = ({
  style,
  children,
  typographyProps,
  ...props
}: RouterLinkProps) => {
  return (
    <Link {...props} style={{ ...styles.link, ...style }}>
      <Typography typography="link" {...typographyProps}>
        {children}
      </Typography>
    </Link>
  );
};

export default RouterLink;
