import { CssConfig } from "../../../types";

const styles: CssConfig = { link: { textDecoration: "none" } };

export default styles;
