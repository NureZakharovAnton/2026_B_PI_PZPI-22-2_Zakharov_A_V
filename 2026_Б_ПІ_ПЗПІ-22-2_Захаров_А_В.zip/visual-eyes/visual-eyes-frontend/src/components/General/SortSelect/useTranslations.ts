import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    sortByLabel: intl.formatMessage(messages.sortByLabel),
    none: intl.formatMessage(messages.none),
    asc: intl.formatMessage(messages.asc),
    desc: intl.formatMessage(messages.desc),
  };

  return translations;
};

export default useTranslations;
