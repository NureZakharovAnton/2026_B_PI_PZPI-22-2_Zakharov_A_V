import React from "react";
import FormControl from "../FormControl";
import InputLabel from "../InputLabel";
import MenuItem from "../MenuItem";
import Select, { SelectChangeEvent } from "../Select";
import checkIsSortByValue from "./checkIsSortByValue";
import useTranslations from "./useTranslations";
import { v4 as uuidv4 } from "uuid";

type SortSelectProps = {
  setValue: (value: string) => void;
  value: string;
};

const SortSelect: React.FC<SortSelectProps> = ({ setValue, value }) => {
  const translations = useTranslations();
  const uuid = uuidv4();
  const labelId = `sort-by-label-${uuid}`;

  const handleSortByChange = (e: SelectChangeEvent) => {
    const value = e.target.value;
    const isSortByValue = checkIsSortByValue(value);

    if (!isSortByValue) {
      return;
    }

    setValue(value);
  };

  return (
    <FormControl fullWidth>
      <InputLabel id={labelId}>{translations.sortByLabel}</InputLabel>
      <Select
        value={value}
        onChange={handleSortByChange}
        label={translations.sortByLabel}
        labelId={labelId}
        fullWidth
      >
        <MenuItem value="">{translations.none}</MenuItem>
        <MenuItem value="asc">{translations.asc}</MenuItem>
        <MenuItem value="desc">{translations.desc}</MenuItem>
      </Select>
    </FormControl>
  );
};

export default SortSelect;
