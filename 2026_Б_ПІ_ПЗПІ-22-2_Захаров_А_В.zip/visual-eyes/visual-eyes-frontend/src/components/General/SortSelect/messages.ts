import { defineMessages } from "react-intl";

const messages = defineMessages({
  sortByLabel: {
    defaultMessage: "Sort by",
    id: "Product.ProductSortSelect.sort",
  },
  none: {
    defaultMessage: "None",
    id: "Product.ProductSortSelect.none",
  },
  asc: {
    defaultMessage: "Ascending",
    id: "Product.ProductSortSelect.asc",
  },
  desc: {
    defaultMessage: "Descending",
    id: "Product.ProductSortSelect.desc",
  },
});

export default messages;
