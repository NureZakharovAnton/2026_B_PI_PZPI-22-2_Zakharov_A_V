import { SortBy } from "../../../redux/API";

const sortByVariants: SortBy[] = ["asc", "desc", ""];

const checkIsSortByValue = (str: string): str is SortBy => {
  const possibleSortBy = str as SortBy;
  const isSortByValue = !!sortByVariants.includes(possibleSortBy);

  return isSortByValue;
};

export default checkIsSortByValue;
