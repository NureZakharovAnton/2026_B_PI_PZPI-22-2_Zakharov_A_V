import React from "react";
import { BeatLoader } from "react-spinners";
import { useTheme } from "../../../hooks";

const Loader = () => {
  const { palette } = useTheme();

  return <BeatLoader color={palette.primary.main} />;
};

export default Loader;
