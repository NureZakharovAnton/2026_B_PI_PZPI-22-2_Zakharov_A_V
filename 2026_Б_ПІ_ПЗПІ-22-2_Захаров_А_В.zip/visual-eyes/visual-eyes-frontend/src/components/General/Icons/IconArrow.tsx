import React from "react";
import IconProps from "./IconProps";

const IconArrow = (props: IconProps) => {
  return (
    <svg
      width="14"
      height="12"
      viewBox="0 0 14 12"
      fill="transparent"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M12.8333 6H2M6.16666 1L1.75592 5.41074C1.43048 5.73618 1.43048 6.26382 1.75592 6.58926L6.16666 11"
        strokeWidth="1.67"
        strokeLinecap="round"
      />
    </svg>
  );
};

export default IconArrow;
