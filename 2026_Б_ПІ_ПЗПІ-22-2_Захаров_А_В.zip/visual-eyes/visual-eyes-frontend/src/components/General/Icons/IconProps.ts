import { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

export default IconProps;
