import React from "react";
import IconProps from "./IconProps";

interface IconLogoProps extends IconProps {
  circleColor: string;
  letterColor: string;
}

const IconLogo = ({ circleColor, letterColor, ...props }: IconLogoProps) => {
  return (
    <svg
      width="51"
      height="53"
      viewBox="0 0 51 53"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <circle
        cx="25.5"
        cy="25.5"
        r="24"
        strokeWidth="3"
        stroke={letterColor}
        fill={circleColor}
      />
      <path
        fill={letterColor}
        d="M16.9517 11.5455L25.0376 36.9631H25.348L33.4503 11.5455H41.2912L29.7585 45H20.6435L9.09446 11.5455H16.9517Z"
      />
      <circle cx="25" cy="30" r="8" fill={circleColor} />
      <path
        fill={letterColor}
        d="M29.4444 30C29.4444 32.4546 27.4546 34.4444 25 34.4444C22.5454 34.4444 20.5555 32.4546 20.5555 30C20.5555 27.5454 22.5454 25.5555 25 25.5555C27.4546 25.5555 29.4444 27.5454 29.4444 30Z"
      />
    </svg>
  );
};

export default IconLogo;
