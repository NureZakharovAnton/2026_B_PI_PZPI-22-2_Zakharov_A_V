import IconPriceRate from "./IconPriceRateDown";
import IconProps from "./IconProps";

const IconPriceRateUp = ({ style, ...props }: IconProps) => {
  return (
    <IconPriceRate style={{ transform: "scale(1, -1)", ...style }} {...props} />
  );
};

export default IconPriceRateUp;
