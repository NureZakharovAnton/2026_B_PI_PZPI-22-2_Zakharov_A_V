import React from "react";
import IconProps from "./IconProps";

const IconDashboard = (props: IconProps) => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="transparent"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M9 1L15 1C17.8003 1 19.2004 1 20.27 1.54497C21.2108 2.02433 21.9757 2.78924 22.455 3.73005C23 4.79961 23 6.19974 23 9V15C23 17.8003 23 19.2004 22.455 20.27C21.9757 21.2108 21.2108 21.9757 20.27 22.455C19.2004 23 17.8003 23 15 23H9M9 1C6.19974 1 4.79961 1 3.73005 1.54497C2.78924 2.02433 2.02433 2.78924 1.54497 3.73005C1 4.79961 1 6.19974 1 9L1 15C1 17.8003 1 19.2004 1.54497 20.27C2.02433 21.2108 2.78924 21.9757 3.73005 22.455C4.79961 23 6.19974 23 9 23M9 1L9 23M9 12L24 12"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
};

export default IconDashboard;
