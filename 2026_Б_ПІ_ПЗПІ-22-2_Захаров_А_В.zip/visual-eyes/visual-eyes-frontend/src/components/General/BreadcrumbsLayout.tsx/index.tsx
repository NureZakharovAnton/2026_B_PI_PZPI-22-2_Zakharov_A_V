import React, { ReactNode } from "react";
import NavigationBreadcrumbs from "../../Navigation/NavigationBreadcrumbs";
import Box from "../Box";

type BreadcrumbsLayoutProps = {
  children: ReactNode;
};

const BreadcrumbsLayout = ({ children }: BreadcrumbsLayoutProps) => {
  return (
    <>
      <NavigationBreadcrumbs />
      <Box mt={2}>{children}</Box>
    </>
  );
};

export default BreadcrumbsLayout;
