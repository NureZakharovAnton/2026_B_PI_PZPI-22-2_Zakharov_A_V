export type LoadingScreenHeight = "full" | "large" | "auto";
