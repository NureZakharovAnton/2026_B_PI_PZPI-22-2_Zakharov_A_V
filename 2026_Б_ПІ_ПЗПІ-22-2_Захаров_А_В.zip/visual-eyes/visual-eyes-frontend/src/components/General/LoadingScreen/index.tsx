import React from "react";
import Box from "../Box";
import Loader from "../Loader";
import { LoadingScreenHeight } from "./types";

type LoadingScreenProps = {
  height?: LoadingScreenHeight;
};

const heightMapper = {
  full: "100svh",
  large: "85svh",
  auto: "auto",
};

const LoadingScreen: React.FC<LoadingScreenProps> = ({ height = "full" }) => {
  const mappedHeight = heightMapper[height];

  return (
    <Box
      width="100%"
      height={mappedHeight}
      display="flex"
      justifyContent="center"
      alignItems="center"
    >
      <Loader />
    </Box>
  );
};

export default LoadingScreen;
