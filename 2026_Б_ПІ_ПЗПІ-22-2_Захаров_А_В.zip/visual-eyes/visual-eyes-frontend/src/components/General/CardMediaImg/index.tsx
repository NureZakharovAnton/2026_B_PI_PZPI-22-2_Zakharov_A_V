import { useState } from "react";
import { PLACEHOLDER_IMAGE_SRC } from "../../../common/constants";
import CardMedia, { CardMediaProps } from "../CardMedia";

type CardMediaImgProps = CardMediaProps<"img">;

const CardMediaImg = ({ image, ...props }: CardMediaImgProps) => {
  const initialImageSrc = image || PLACEHOLDER_IMAGE_SRC;
  const [imageSrc, setImageSrc] = useState(initialImageSrc);

  const handleImageLoadError = () => {
    setImageSrc(PLACEHOLDER_IMAGE_SRC);
  };

  return (
    <CardMedia
      {...props}
      component="img"
      onError={handleImageLoadError}
      image={imageSrc}
    />
  );
};

export default CardMediaImg;
