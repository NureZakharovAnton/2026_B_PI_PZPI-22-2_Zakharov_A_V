import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import ROUTES from "../../../common/routes";
import DashboardScreen from "../../Dashboard/DashboardScreen";
import NotificationsScreen from "../../Notification/NotificationScreen";
import ShopsScreen from "../../Shop/ShopsScreen";
import AuthorizedLayout from "../AuthorizedLayout";
import ProductsScreen from "../../Product/ProductsScreen";
import ProductDetailsScreen from "../../Product/ProductDetailsScreen";

const AuthorizedRouter = () => {
  return (
    <BrowserRouter>
      <AuthorizedLayout>
        <Routes>
          <Route path={ROUTES.DASHBOARD} element={<DashboardScreen />} />
          <Route
            path={ROUTES.NOTIFICATIONS}
            element={<NotificationsScreen />}
          />
          <Route path={ROUTES.SHOPS} element={<ShopsScreen />} />
          <Route path={ROUTES.PRODUCTS} element={<ProductsScreen />} />
          <Route
            path={ROUTES.PRODUCT_DETAILS}
            element={<ProductDetailsScreen />}
          />
          <Route path="*" element={<Navigate to={ROUTES.DASHBOARD} />} />
        </Routes>
      </AuthorizedLayout>
    </BrowserRouter>
  );
};

export default AuthorizedRouter;
