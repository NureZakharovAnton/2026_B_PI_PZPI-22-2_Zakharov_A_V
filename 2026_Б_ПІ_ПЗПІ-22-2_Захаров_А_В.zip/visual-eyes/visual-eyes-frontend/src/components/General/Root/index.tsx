import React from "react";
import { useAuth } from "../../../redux/hooks";
import AuthorizedRouter from "./AuthorizedRouter";
import GuestRouter from "./GuestRouter";

const Root = () => {
  const { isLoggedIn } = useAuth();

  if (isLoggedIn) {
    return <AuthorizedRouter />;
  }

  return <GuestRouter />;
};

export default Root;
