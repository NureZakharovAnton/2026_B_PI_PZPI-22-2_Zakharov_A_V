import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import ROUTES from "../../../common/routes";
import LoginScreen from "../../Login/LoginScreen";
import RegistrationScreen from "../../Registration/RegistrationScreen";
import ParticlesLayout from "../ParticlesLayout";

const GuestRouter = () => {
  return (
    <BrowserRouter>
      <ParticlesLayout>
        <Routes>
          <Route path={ROUTES.LOGIN} element={<LoginScreen />} />
          <Route path={ROUTES.REGISTRATION} element={<RegistrationScreen />} />

          <Route path="*" element={<Navigate to={ROUTES.LOGIN} />} />
        </Routes>
      </ParticlesLayout>
    </BrowserRouter>
  );
};

export default GuestRouter;
