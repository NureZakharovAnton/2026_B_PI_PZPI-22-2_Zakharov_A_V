import {
  ResponsiveContainer as ResponsiveContainerBase,
  ResponsiveContainerProps as ResponsiveContainerBaseProps,
} from "recharts";
import Box from "../Box";
import styles from "./styles";

interface ResponsiveContainerProps extends ResponsiveContainerBaseProps {}

const ResponsiveContainer = (props: ResponsiveContainerProps) => {
  return (
    <Box sx={styles.relativeContainer} height={props.height}>
      <Box sx={styles.absoluteContainer}>
        <ResponsiveContainerBase {...props} />
      </Box>
    </Box>
  );
};

export default ResponsiveContainer;
