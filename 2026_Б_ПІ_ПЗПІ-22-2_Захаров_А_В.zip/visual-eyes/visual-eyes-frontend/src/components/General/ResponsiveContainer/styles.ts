import { SxConfig } from "../../../types";

const styles: SxConfig = {
  relativeContainer: { width: "100%", position: "relative" },
  absoluteContainer: {
    width: "100%",
    height: "100%",
    position: "absolute",
    top: 0,
    left: 0,
  },
};

export default styles;
