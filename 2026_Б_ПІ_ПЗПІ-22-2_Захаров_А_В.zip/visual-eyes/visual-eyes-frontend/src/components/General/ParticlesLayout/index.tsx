import React, { ReactNode } from "react";
import Box from "../Box";
import ParticlesConnectedCircles from "../ParticlesConnectedCircles";

interface ParticlesLayoutProps {
  children: ReactNode;
}

const ParticlesLayout = ({ children }: ParticlesLayoutProps) => {
  return (
    <Box>
      <ParticlesConnectedCircles />
      {children}
    </Box>
  );
};

export default ParticlesLayout;
