import { CssConfig } from "../../../types";

const styles: CssConfig = {
  particles: {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    zIndex: -100,
  },
};

export default styles;
