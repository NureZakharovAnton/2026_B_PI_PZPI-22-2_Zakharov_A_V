import Box, { BoxProps } from "@mui/material/Box";

export type { BoxProps };
export default Box;
