import * as Yup from "yup";
import {
  MAX_EMAIL_LENGTH,
  MAX_PASSWORD_LENGTH,
  MIN_PASSWORD_LENGTH,
} from "../../../common/constants";

interface LoginFormSchemaTranslations {
  emailRequired: string;
  invalidEmail: string;
  maxEmailLength: string;
  passwordRequired: string;
  minPasswordLength: string;
  maxPasswordLength: string;
}

const useValidationSchema = (translations: LoginFormSchemaTranslations) => {
  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .email(translations.invalidEmail)
      .required(translations.emailRequired)
      .max(MAX_EMAIL_LENGTH, translations.maxEmailLength),
    password: Yup.string()
      .min(MIN_PASSWORD_LENGTH, translations.minPasswordLength)
      .max(MAX_PASSWORD_LENGTH, translations.maxPasswordLength)
      .required(translations.passwordRequired),
  });

  return validationSchema;
};

export default useValidationSchema;
