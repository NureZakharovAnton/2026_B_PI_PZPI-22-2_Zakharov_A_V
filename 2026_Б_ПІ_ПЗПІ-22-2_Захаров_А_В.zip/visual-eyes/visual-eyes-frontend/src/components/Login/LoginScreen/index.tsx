import React from "react";
import { useFormik } from "formik";
import ROUTES from "../../../common/routes";
import { useAlert, useAuth } from "../../../redux/hooks";
import Stack from "../../General/Stack";
import Typography from "../../General/Typography";
import Box from "../../General/Box";
import Button from "../../General/Button";
import TextField from "../../General/TextField";
import RouterLink from "../../General/RouterLink";
import useValidationSchema from "./useValidationSchema";
import useTranslations from "./useTranslations";

const initialValues = {
  email: "",
  password: "",
};

const LoginScreen = () => {
  const { login } = useAuth();
  const { showTranslatedErrorAlert, showSuccessAlert } = useAlert();

  const translations = useTranslations();
  const validationSchema = useValidationSchema(
    translations.loginFormSchemaTranslations
  );

  const showWelcomeAlert = () => showSuccessAlert(translations.welcomeText);

  const { values, errors, isSubmitting, handleChange, handleSubmit } =
    useFormik({
      initialValues,
      validationSchema,
      validateOnChange: false,
      onSubmit: async (values) => {
        try {
          await login(values);
          showWelcomeAlert();
        } catch (error) {
          showTranslatedErrorAlert(error);
        }
      },
    });

  return (
    <Box
      width="100%"
      height="100vh"
      display="flex"
      justifyContent="center"
      alignItems="center"
    >
      <Stack width={275} flexDirection="column" spacing={4}>
        <Typography typography="title">{translations.title}</Typography>
        <form onSubmit={handleSubmit}>
          <Stack spacing={4}>
            <TextField
              type="text"
              placeholder={translations.emailInputPlaceholder}
              value={values.email}
              error={!!errors.email}
              onChange={handleChange("email")}
              helperText={errors.email}
            />
            <TextField
              type="password"
              placeholder={translations.passwordInputPlaceholder}
              value={values.password}
              error={!!errors.password}
              onChange={handleChange("password")}
              helperText={errors.password}
            />
            <Button
              fullWidth
              type="submit"
              variant="contained"
              loading={isSubmitting}
            >
              <Typography typography="submitButton" p={0.5}>
                {translations.submitButtonText}
              </Typography>
            </Button>
          </Stack>
        </form>
        <RouterLink
          to={ROUTES.REGISTRATION}
          typographyProps={{ textAlign: "center" }}
        >
          {translations.registrationLink} !
        </RouterLink>
      </Stack>
    </Box>
  );
};

export default LoginScreen;
