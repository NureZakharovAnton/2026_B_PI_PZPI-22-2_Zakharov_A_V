import { defineMessages } from "react-intl";

const messages = defineMessages({
  title: {
    id: "Login.LoginScreen.title",
    defaultMessage: "Login",
  },
  submitButtonText: {
    id: "Login.LoginScreen.submitButtonText",
    defaultMessage: "Submit",
  },
  registrationLink: {
    id: "Login.LoginScreen.registrationLink",
    defaultMessage: "I don't have account yet",
  },
  welcomeText: {
    id: "Login.LoginScreen.welcomeText",
    defaultMessage: "Welcome back",
  },
});

export default messages;
