import { useIntl } from "react-intl";
import commonMessages from "../../../common/messages";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    title: intl.formatMessage(messages.title),
    emailInputPlaceholder: intl.formatMessage(commonMessages.emailPlaceholder),
    passwordInputPlaceholder: intl.formatMessage(
      commonMessages.passwordPlaceholder
    ),
    submitButtonText: intl.formatMessage(messages.submitButtonText),
    registrationLink: intl.formatMessage(messages.registrationLink),
    loginFormSchemaTranslations: {
      emailRequired: intl.formatMessage(commonMessages.emailRequired),
      invalidEmail: intl.formatMessage(commonMessages.invalidEmail),
      maxEmailLength: intl.formatMessage(commonMessages.maxEmailLength),
      passwordRequired: intl.formatMessage(commonMessages.passwordRequired),
      minPasswordLength: intl.formatMessage(commonMessages.minPasswordLength),
      maxPasswordLength: intl.formatMessage(commonMessages.maxPasswordLength),
    },
    welcomeText: `${intl.formatMessage(messages.welcomeText)} ✨`,
  };

  return translations;
};

export default useTranslations;
