import React from "react";
import Overview from "../../General/Overview";
import Grid from "../../General/Grid";
import Stack from "../../General/Stack";
import NotificationItem from "../NotificationItem";
import useTranslations from "./useTranslations";
import mockItems from "./mockItems";

const NotificationsScreen = () => {
  const translations = useTranslations();

  return (
    <Stack direction="column" spacing={5} width="100%">
      <Overview
        title={`${translations.title} 🔔`}
        description={translations.description}
      />
      <Grid container gap={4} component="main">
        {mockItems.map((item, i) => (
          <Grid item key={i}>
            <NotificationItem
              src={item.src}
              alt={item.alt}
              details={item.details}
              title={item.title}
              description={item.description}
            />
          </Grid>
        ))}
      </Grid>
    </Stack>
  );
};

export default NotificationsScreen;
