import { defineMessages } from "react-intl";

export default defineMessages({
  title: {
    id: "Notification.NotificationsScreen.title",
    defaultMessage: "View Notifications",
  },
  description: {
    id: "Notification.NotificationsScreen.description",
    defaultMessage: "Be aware of all information you have missed",
  },
});
