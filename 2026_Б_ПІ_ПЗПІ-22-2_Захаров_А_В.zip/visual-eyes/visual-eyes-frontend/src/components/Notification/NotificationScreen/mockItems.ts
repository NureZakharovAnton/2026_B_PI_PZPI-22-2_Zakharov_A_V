import { PLACEHOLDER_IMAGE_SRC } from "../../../common/constants";

const mockItems = new Array(20).fill({
  src: PLACEHOLDER_IMAGE_SRC,
  details: "MCDonalds • now",
  title: "Potato free is 20% cheaper now",
  description:
    "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here'",
});

export default mockItems;
