const getSx = () => {
  const cardSx = { display: "flex", width: "100%" };
  const cardMedia = { width: 151 };
  const contentBox = { display: "flex", flexDirection: "column" };
  const cardContentSx = { flex: "1 0 auto" };

  return { cardSx, cardMedia, contentBox, cardContentSx };
};

export default getSx;
