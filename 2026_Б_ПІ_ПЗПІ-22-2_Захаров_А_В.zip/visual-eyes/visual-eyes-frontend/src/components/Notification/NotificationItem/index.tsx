import React from "react";
import Card from "../../General/Card";
import Box from "../../General/Box";
import CardContent from "../../General/CardContent";
import Typography from "../../General/Typography";
import CardMedia from "../../General/CardMedia/index";
import getSx from "./getSx";

interface NotificationItemProps {
  src: string;
  alt: string;
  details: string;
  title: string;
  description: string;
}

const { cardSx, cardMedia, contentBox, cardContentSx } = getSx();

const NotificationItem = ({
  src,
  alt,
  details,
  title,
  description,
}: NotificationItemProps) => {
  return (
    <Card sx={cardSx}>
      <CardMedia component="img" sx={cardMedia} image={src} alt={alt} />
      <Box sx={contentBox}>
        <CardContent sx={cardContentSx}>
          <Typography
            variant="subtitle1"
            color="grey.300"
            component="div"
            fontWeight="bold"
          >
            {details}
          </Typography>
          <Typography component="div" variant="h5">
            {title}
          </Typography>
          <Typography
            variant="subtitle1"
            color="grey.300"
            component="div"
            mt={1}
          >
            {description}
          </Typography>
        </CardContent>
      </Box>
    </Card>
  );
};

export default NotificationItem;
