import React, { useState } from "react";
import { SortBy } from "../../../redux/API";
import { useAlert } from "../../../redux/hooks";
import Overview from "../../General/Overview";
import useTranslations from "./useTranslations";
import Stack from "../../General/Stack";
import Grid from "../../General/Grid";
import ShopCard from "../ShopCard";
import Box from "../../General/Box";
import Button from "../../General/Button";
import Typography from "../../General/Typography";
import TextField from "../../General/TextField";
import { useGetShopsQuery } from "../../../redux/API";
import { FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import LoadingScreen from "../../General/LoadingScreen";

const sortByVariants: SortBy[] = ["asc", "desc", ""];
const getSafeSortBy = (str: string): SortBy => {
  const possibleSortBy = str as SortBy;

  if (sortByVariants.includes(possibleSortBy)) {
    return possibleSortBy;
  }

  return "";
};

// TODO: refactor ShopsScreen
const ShopsScreen = () => {
  const translations = useTranslations();
  const { showTranslatedErrorAlert } = useAlert();

  const [searchValue, setSearchValue] = useState("");
  const [sortBy, setSortBy] = useState<SortBy>("");

  const { data: shops, isLoading, error } = useGetShopsQuery({ searchValue, sortBy });

  if (isLoading) {
    return <LoadingScreen height="large" />;
  }

  if (error) {
    showTranslatedErrorAlert(error);
    //TODO: add ErrorScreen
    return;
  }

  return (
    <Stack direction="column" spacing={5} width="100%">
      <Overview
        title={`${translations.title} 🏪`}
        description={translations.description}
      />
      <Typography fontSize={20} textAlign="center">
        Search shops 🔍
      </Typography>
      <Box display="flex" justifyContent="center">
        <Box width={500}>
          <TextField
            InputProps={{ sx: { borderRadius: 10 } }}
            value={searchValue}
            label="Title"
            onChange={(e) => setSearchValue(e.target.value)}
            fullWidth
          />
        </Box>
        <Button onClick={() => setSearchValue("")}>Clear</Button>
      </Box>

      <Box display="flex" justifyContent="center">
        <Box width={500}>
          <Typography fontSize={20} textAlign="center">
            Filter shops 🪄
          </Typography>
        </Box>
      </Box>

      <Stack display="flex" justifyContent="center" flexDirection="row" gap={3}>
        <Box width={500}>
          <FormControl fullWidth>
            <InputLabel id="sort-by-label">Sort by</InputLabel>
            <Select
              value={sortBy}
              onChange={(e) => setSortBy(getSafeSortBy(e.target.value))}
              label="Sort by"
              labelId="sort-by-label"
              fullWidth
            >
              <MenuItem value="">None</MenuItem>
              <MenuItem value="asc">ascending</MenuItem>
              <MenuItem value="desc">descending</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Stack>
      <Grid container gap={4} component="main" justifyContent="center">
        {shops?.map((item, i) => (
          <Grid item key={i}>
            <ShopCard
              src={item.imageURL}
              alt={item.title}
              title={item.title}
              description={item.description}
              href={item.siteURL}
              key={item.id}
            />
          </Grid>
        ))}
      </Grid>
    </Stack>
  );
};

export default ShopsScreen;
