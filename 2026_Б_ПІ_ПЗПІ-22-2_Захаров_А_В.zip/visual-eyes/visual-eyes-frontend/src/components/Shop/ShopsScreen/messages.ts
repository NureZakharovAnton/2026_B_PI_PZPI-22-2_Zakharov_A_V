import { defineMessages } from "react-intl";

export default defineMessages({
  title: {
    id: "Shop.ShopsScreen.title",
    defaultMessage: "View Shops",
  },
  description: {
    id: "Shop.ShopsScreen.description",
    defaultMessage: "Select all shops you are interested in",
  },
});
