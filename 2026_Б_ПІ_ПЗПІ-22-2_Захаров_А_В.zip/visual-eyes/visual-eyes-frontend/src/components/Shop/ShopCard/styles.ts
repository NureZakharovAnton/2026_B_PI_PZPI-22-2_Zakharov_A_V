const card = {
  maxWidth: 300,
  height: 400,
  display: "flex",
  flexDirection: "column",
  justifyContent: "space-between",
};

const cardContent = {
  maxHeight: 100,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "pre-wrap",
};

const cardMedia = {
  height: 180,
  width: "100%",
  minWidth: 300,
};

const title = {
  whiteSpace: "nowrap",
  overflow: "hidden",
  textOverflow: "ellipsis",
  maxHeight: 32,
};

const description = {
  WebkitLineClamp: 4,
  WebkitBoxOrient: "vertical",
  display: "-webkit-box",
  whiteSpace: "normal",
  overflow: "hidden",
  textOverflow: "ellipsis",
  maxHeight: 80,
};

const cardActions = { justifyContent: "flex-end", mb: 2, mr: 1.5 };
const viewButton = { px: 4 };

const styles = {
  card,
  cardContent,
  cardMedia,
  title,
  description,
  cardActions,
  viewButton,
};

export default styles;
