import { defineMessages } from "react-intl";

export default defineMessages({
  viewButtonLabel: {
    id: "Shop.ShopCard.viewButtonLabel",
    defaultMessage: "View",
  },
});
