import React from "react";
import Card from "../../General/Card";
import Typography from "../../General/Typography";
import CardContent from "../../General/CardContent";
import CardActions from "../../General/CardActions";
import CardMediaImg from "../../General/CardMediaImg";
import Button from "../../General/Button";
import useTranslations from "./useTranslations";
import Box from "../../General/Box";
import RouterLink from "../../General/RouterLink";
import styles from "./styles";

interface ShopCardProps {
  alt: string;
  src?: string;
  title: string;
  description?: string;
  href: string;
}

const ShopCard = ({
  alt,
  src,
  title,
  description = "",
  href,
}: ShopCardProps) => {
  const translations = useTranslations();

  return (
    <Card sx={styles.card}>
      <Box>
        <CardMediaImg sx={styles.cardMedia} image={src} alt={alt} />
        <CardContent sx={styles.cardContent}>
          <Typography sx={styles.title} gutterBottom variant="h5">
            {title}
          </Typography>
          <Typography sx={styles.description} variant="body2" color="grey.300">
            {description}
          </Typography>
        </CardContent>
      </Box>
      <CardActions sx={styles.cardActions}>
        <RouterLink to={href}>
          <Button sx={styles.viewButton} size="large" variant="contained">
            {translations.viewButtonLabel}
          </Button>
        </RouterLink>
      </CardActions>
    </Card>
  );
};

export default ShopCard;
