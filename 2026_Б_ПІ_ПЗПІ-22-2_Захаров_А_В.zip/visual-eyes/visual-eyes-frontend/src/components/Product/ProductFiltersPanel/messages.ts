import { defineMessages } from "react-intl";

const messages = defineMessages({
  searchTitle: {
    id: "ProductFiltersPanel.searchTitle",
    defaultMessage: "Search",
  },
  filterTitle: {
    id: "ProductFiltersPanel.filterTitle",
    defaultMessage: "Filter",
  },
});

export default messages;
