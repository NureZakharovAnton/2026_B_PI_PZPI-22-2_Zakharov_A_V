import React from "react";
import Box from "../../General/Box";
import Stack from "../../General/Stack";
import ProductCategoryFilter from "../ProductCategoryFilter";
import ProductPriceFilter from "../ProductPriceFilter";
import ProductShopFilter from "../ProductShopFilter";
import ProductSortSelect from "../ProductSortSelect";
import { ProductFiltersPanelProps } from "./types";
import Typography from "../../General/Typography";
import ProductSearchFilter from "../ProductSearchFilter";
import useTranslations from "./useTranslations";

const ProductFiltersPanel: React.FC<ProductFiltersPanelProps> = ({
  filters,
  setters,
}) => {
  const translations = useTranslations();

  return (
    <>
      <Typography fontSize={20} textAlign="center">
        {translations.searchTitle} 🔍
      </Typography>

      <ProductSearchFilter
        value={filters.searchValue}
        setValue={setters.setSearchValue}
        width={500}
      />

      <Box display="flex" justifyContent="center">
        <Box width={500}>
          <Typography fontSize={20} textAlign="center">
            {translations.filterTitle} 🪄
          </Typography>
        </Box>
      </Box>
      <Stack display="flex" justifyContent="center" flexDirection="row" gap={3}>
        <Box width={500}>
          <ProductSortSelect
            value={filters.sortBy}
            setValue={setters.setSortBy}
          />
        </Box>
        <Box width={500}>
          <ProductPriceFilter
            mode="from"
            value={filters.priceFrom}
            setValue={setters.setPriceFrom}
          />
        </Box>
        <Box width={500}>
          <ProductPriceFilter
            mode="to"
            value={filters.priceTo}
            setValue={setters.setPriceTo}
          />
        </Box>
        <Box width={500}>
          <ProductShopFilter setOptionIds={setters.setShopsIds} />
        </Box>
        <Box width={500}>
          <ProductCategoryFilter setOptionIds={setters.setCategoriesIds} />
        </Box>
      </Stack>
    </>
  );
};

export default ProductFiltersPanel;
