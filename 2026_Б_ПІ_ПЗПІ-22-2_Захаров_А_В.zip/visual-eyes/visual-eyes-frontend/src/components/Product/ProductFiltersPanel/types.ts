import { Id, SortBy } from "../../../redux/API";

export type ProductFilters = {
  searchValue: string;
  sortBy: SortBy;
  priceFrom: number | undefined;
  priceTo: number | undefined;
  shopsIds: Id[];
  categoriesIds: Id[];
};

export type ProductFiltersSetters = {
  setSearchValue: (value: string) => void;
  setSortBy: (value: SortBy) => void;
  setPriceFrom: (value: number | undefined) => void;
  setPriceTo: (value: number | undefined) => void;
  setShopsIds: (value: Id[]) => void;
  setCategoriesIds: (value: Id[]) => void;
};

export type ProductFiltersPanelProps = {
  filters: ProductFilters;
  setters: ProductFiltersSetters;
};
