import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    searchTitle: intl.formatMessage(messages.searchTitle),
    filterTitle: intl.formatMessage(messages.filterTitle),
  };

  return translations;
};

export default useTranslations;
