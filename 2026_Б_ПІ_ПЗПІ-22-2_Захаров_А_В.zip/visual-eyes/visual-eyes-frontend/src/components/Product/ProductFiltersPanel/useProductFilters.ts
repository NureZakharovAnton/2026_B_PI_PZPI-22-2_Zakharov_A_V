import { useState } from "react";
import { SortBy, Id } from "../../../redux/API";
import { ProductFilters, ProductFiltersSetters } from "./types";

const useProductFilters = () => {
  const [searchValue, setSearchValue] = useState("");
  const [sortBy, setSortBy] = useState<SortBy>("");
  const [priceFrom, setPriceFrom] = useState<number | undefined>();
  const [priceTo, setPriceTo] = useState<number | undefined>();
  const [shopsIds, setShopsIds] = useState<Id[]>([]);
  const [categoriesIds, setCategoriesIds] = useState<Id[]>([]);

  const filters: ProductFilters = {
    searchValue,
    sortBy,
    priceFrom,
    priceTo,
    shopsIds,
    categoriesIds,
  };

  const setters: ProductFiltersSetters = {
    setSearchValue,
    setSortBy,
    setPriceFrom,
    setPriceTo,
    setShopsIds,
    setCategoriesIds,
  };

  return {
    filters,
    setters,
  };
};

export default useProductFilters;
