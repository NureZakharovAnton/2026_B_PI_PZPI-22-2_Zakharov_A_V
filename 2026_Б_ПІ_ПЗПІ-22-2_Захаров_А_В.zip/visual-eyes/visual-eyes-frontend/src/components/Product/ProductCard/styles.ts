const card = {
  maxWidth: 300,
  height: 400,
  display: "flex",
  flexDirection: "column",
  justifyContent: "space-between",
};

const cardContent = {
  maxHeight: 100,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "pre-wrap",
};

const cardMedia = {
  height: 180,
  width: "100%",
  minWidth: 300,
  backgroundColor: "grey.200",
};

const title = {
  WebkitLineClamp: 3,
  WebkitBoxOrient: "vertical",
  display: "-webkit-box",
  whiteSpace: "normal",
  overflow: "hidden",
  textOverflow: "ellipsis",
  maxHeight: 100,
};

const cardActions = { justifyContent: "space-between", mb: 2, mx: 1.5 };
const viewButton = { px: 4 };

const styles = {
  card,
  cardContent,
  cardMedia,
  title,
  cardActions,
  viewButton,
};

export default styles;
