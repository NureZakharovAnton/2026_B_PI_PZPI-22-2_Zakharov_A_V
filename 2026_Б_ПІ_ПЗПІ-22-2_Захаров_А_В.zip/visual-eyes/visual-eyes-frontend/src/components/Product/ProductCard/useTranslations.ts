import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    viewButtonLabel: intl.formatMessage(messages.viewButtonLabel),
  };

  return translations;
};

export default useTranslations;
