import React from "react";
import { Currency } from "../../../redux/API";
import Card from "../../General/Card";
import Typography from "../../General/Typography";
import CardContent from "../../General/CardContent";
import CardActions from "../../General/CardActions";
import CardMediaImg from "../../General/CardMediaImg";
import Button from "../../General/Button";
import useTranslations from "./useTranslations";
import Box from "../../General/Box";
import RouterLink from "../../General/RouterLink";
import styles from "./styles";

type ProductCardProps = {
  alt: string;
  src?: string;
  title: string;
  price: number;
  currency: Currency;
  slug: string;
};

const ProductCard = ({
  alt,
  src,
  title,
  price,
  currency,
  slug,
}: ProductCardProps) => {
  const translations = useTranslations();

  const href = `/products/${slug}`;

  return (
    <Card sx={styles.card}>
      <Box>
        <CardMediaImg
          sx={styles.cardMedia}
          image={src}
          alt={alt}
          loading="lazy"
        />
        <CardContent sx={styles.cardContent}>
          <Typography
            sx={styles.title}
            gutterBottom
            typography="secondaryTitle"
            fontSize={20}
          >
            {title}
          </Typography>
        </CardContent>
      </Box>
      <CardActions sx={styles.cardActions}>
        <Typography typography="priceText">
          {price} {currency}
        </Typography>
        <RouterLink to={href}>
          <Button sx={styles.viewButton} size="large" variant="contained">
            {translations.viewButtonLabel}
          </Button>
        </RouterLink>
      </CardActions>
    </Card>
  );
};

export default React.memo(ProductCard);
