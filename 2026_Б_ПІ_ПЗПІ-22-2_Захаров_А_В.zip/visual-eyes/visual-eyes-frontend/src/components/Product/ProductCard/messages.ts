import { defineMessages } from "react-intl";

export default defineMessages({
  viewButtonLabel: {
    id: "Product.ProductCard.viewButtonLabel",
    defaultMessage: "View",
  },
});
