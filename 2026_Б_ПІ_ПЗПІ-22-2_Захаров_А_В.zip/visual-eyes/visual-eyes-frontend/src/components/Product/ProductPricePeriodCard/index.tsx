import React from "react";
import Card from "../../General/Card";
import CardContent from "../../General/CardContent";
import Typography from "../../General/Typography";
import useTranslations from "./useTranslations";

type ProductPricePeriodCard = {
  updatePeriodDays: number;
};

const ProductPricePeriodCard = ({
  updatePeriodDays,
}: ProductPricePeriodCard) => {
  const { formatTimePeriod, ...translations } = useTranslations();

  return (
    <Card elevation={1}>
      <CardContent>
        <Typography
          typography="infoLabel"
          display="flex"
          justifyContent="center"
        >
          {translations.priceLabel}
          <Typography mr={1} color="primary.main" fontSize="inherit" ml={1}>
            {translations.periodLabel}
          </Typography>
        </Typography>
        <Typography typography="infoValue" textAlign="center">
          {formatTimePeriod(updatePeriodDays)}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default ProductPricePeriodCard;
