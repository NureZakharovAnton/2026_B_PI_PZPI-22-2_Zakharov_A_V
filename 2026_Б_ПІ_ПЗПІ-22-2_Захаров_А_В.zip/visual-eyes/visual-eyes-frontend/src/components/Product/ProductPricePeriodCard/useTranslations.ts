import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    priceLabel: intl.formatMessage(messages.priceLabel),
    periodLabel: intl.formatMessage(messages.periodLabel),
    formatTimePeriod: (period: number) =>
      intl.formatMessage(messages.periodTime, { period }),
  };

  return translations;
};

export default useTranslations;
