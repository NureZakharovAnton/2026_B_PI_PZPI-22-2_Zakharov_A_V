import { defineMessages } from "react-intl";

const messages = defineMessages({
  priceLabel: {
    id: "Product.ProductPricePeriodCard.priceLabel",
    defaultMessage: "price",
  },
  periodLabel: {
    id: "Product.ProductPricePeriodCard.periodLabel",
    defaultMessage: "update period",
  },
  periodTime: {
    id: "Product.ProductPricePeriodCard.periodTime",
    defaultMessage: "{period} {period, plural, one {day} other {days}}",
  }
});

export default messages;
