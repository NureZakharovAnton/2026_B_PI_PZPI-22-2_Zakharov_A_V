import { defineMessages } from "react-intl";

export default defineMessages({
  title: {
    id: "Product.ProductsScreen.title",
    defaultMessage: "View Products",
  },
  description: {
    id: "Product.ProductsScreen.description",
    defaultMessage: "Investigate all products you are interested in",
  },
  searchTitle: {
    id: "Product.ProductsScreen.searchTitle",
    defaultMessage: "Search products",
  },
  filterTitle: {
    id: "Product.ProductsScreen.filterTitle",
    defaultMessage: "Filter products",
  },
});
