import React from "react";
import { useAlert } from "../../../redux/hooks";
import { useGetProductsQuery } from "../../../redux/API";
import Overview from "../../General/Overview";
import Stack from "../../General/Stack";
import Grid from "../../General/Grid";
import LoadingScreen from "../../General/LoadingScreen";
import Box from "../../General/Box";
import ProductWordReportButton from "../ProductWordReportButton";
import ProductCard from "../ProductCard";
import ProductFiltersPanel from "../ProductFiltersPanel";
import useProductFilters from "../ProductFiltersPanel/useProductFilters";
import useTranslations from "./useTranslations";

const MOCKED_CURRENCY = "₴";

const ProductsScreen = () => {
  const translations = useTranslations();
  const { showTranslatedErrorAlert } = useAlert();
  const { filters, setters } = useProductFilters();

  const {
    currentData: products = [],
    isFetching,
    isLoading,
    error,
    isError,
  } = useGetProductsQuery({ ...filters });

  if (isLoading) {
    return <LoadingScreen height="large" />;
  }

  if (isError) {
    showTranslatedErrorAlert(error);
    // TODO: return ErrorScreen
  }

  return (
    <Stack direction="column" spacing={5} width="100%">
      <Overview
        title={`${translations.title} 🛒`}
        description={translations.description}
      />

      <ProductFiltersPanel filters={filters} setters={setters} />

      <Box display="flex" justifyContent="center">
        <ProductWordReportButton products={products} />
      </Box>

      <Grid container gap={4} component="main" justifyContent="center">
        {isFetching ? (
          <LoadingScreen height="auto" />
        ) : (
          products.map((item) => (
            <Grid item key={item.imageURL}>
              <ProductCard
                src={item.imageURL}
                alt={item.title}
                title={item.title}
                price={item.price}
                currency={item.currency || MOCKED_CURRENCY}
                slug={item.slug}
              />
            </Grid>
          ))
        )}
      </Grid>
    </Stack>
  );
};

export default ProductsScreen;
