import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    title: intl.formatMessage(messages.title),
    description: intl.formatMessage(messages.description),
    searchTitle: intl.formatMessage(messages.searchTitle),
    filterTitle: intl.formatMessage(messages.filterTitle),
  };

  return translations;
};

export default useTranslations;
