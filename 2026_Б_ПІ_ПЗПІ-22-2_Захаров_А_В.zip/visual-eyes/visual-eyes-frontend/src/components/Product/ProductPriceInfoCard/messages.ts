import { defineMessages } from "react-intl";

const messages = defineMessages({
  highestStatus: {
    id: "Product.ProductPriceInfoCard.highestStatus",
    defaultMessage: "highest",
  },
  lowestStatus: {
    id: "Product.ProductPriceInfoCard.lowestStatus",
    defaultMessage: "lowest",
  },
  averageStatus: {
    id: "Product.ProductPriceInfoCard.averageStatus",
    defaultMessage: "average",
  },
  priceLabel: {
    id: "Product.ProductPriceInfoCard.priceLabel",
    defaultMessage: "price",
  },
});

export default messages;
