import React from "react";
import Card from "../../General/Card";
import CardContent from "../../General/CardContent";
import Typography from "../../General/Typography";
import { PriceInfoStatus } from "./types";
import useTranslations from "./useTranslations";
import styles from "./styles";

type ProductPriceInfoCardProps = {
  type: PriceInfoStatus;
  price: number;
};

const MOCKED_CURRENCY = "$";

const ProductPriceInfoCard = ({ type, price }: ProductPriceInfoCardProps) => {
  const { infoStatusVariants, ...translations } = useTranslations();

  const infoStatusLabel = infoStatusVariants[type];
  const infoStatusLabelStyle = styles[type];

  return (
    <Card elevation={1}>
      <CardContent>
        <Typography
          typography="infoLabel"
          display="flex"
          justifyContent="center"
        >
          <Typography fontSize={28} mr={1} sx={infoStatusLabelStyle}>
            {infoStatusLabel}
          </Typography>
          {translations.priceLabel}
        </Typography>
        <Typography typography="infoValue" textAlign="center">
          {price} {MOCKED_CURRENCY}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default ProductPriceInfoCard;
