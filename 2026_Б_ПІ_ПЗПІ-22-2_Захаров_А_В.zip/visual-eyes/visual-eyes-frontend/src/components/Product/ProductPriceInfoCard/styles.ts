const styles = {
  highest: {
    color: "error.main",
  },
  lowest: {
    color: "success.main",
  },
  average: {
    color: "primary.main",
  },
};

export default styles;
