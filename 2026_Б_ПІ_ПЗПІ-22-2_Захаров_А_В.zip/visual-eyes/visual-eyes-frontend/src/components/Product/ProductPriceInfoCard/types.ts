export type PriceInfoStatus = "highest" | "lowest" | "average";
export type InfoStatusVariants = {
  [key in PriceInfoStatus]: string;
};
