import { useIntl } from "react-intl";
import messages from "./messages";
import { InfoStatusVariants } from "./types";

const useTranslations = () => {
  const intl = useIntl();

  const infoStatusVariants: InfoStatusVariants = {
    average: intl.formatMessage(messages.averageStatus),
    highest: intl.formatMessage(messages.highestStatus),
    lowest: intl.formatMessage(messages.lowestStatus),
  };

  const translations = {
    infoStatusVariants,
    priceLabel: intl.formatMessage(messages.priceLabel),
  };

  return translations;
};

export default useTranslations;
