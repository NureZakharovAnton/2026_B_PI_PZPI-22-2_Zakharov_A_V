import React from "react";
import { useParams } from "react-router-dom";
import { useGetProductBySlugQuery } from "../../../redux/API";
import LoadingScreen from "../../General/LoadingScreen";
import Grid from "../../General/Grid";
import CardMediaImg from "../../General/CardMediaImg";
import Card from "../../General/Card";
import Typography from "../../General/Typography";
import { CardContent, useTheme } from "@mui/material";
import ProductPriceRateCard from "../ProductPriceRateCard";
import ProductPriceInfoCard from "../ProductPriceInfoCard";
import ProductPricePeriodCard from "../ProductPricePeriodCard";
import ChartDescriptionWrapper from "../../General/ChartDescriptionWrapper";
import StackedBarChart from "../../General/StackedBarChart";
import stackedBarMockedData from "../../General/StackedBarChart/mockedData";
import useTranslations from "../../Dashboard/DashboardScreen/useTranslations";

type ProductDetailsScreenParams = {
  slug: string;
};

const ProductDetailsScreen = () => {
  const { slug } = useParams<ProductDetailsScreenParams>();
  const {
    data: product,
    isFetching,
    isError,
  } = useGetProductBySlugQuery(slug || ""); // TODO: add background image

  const theme = useTheme();
  const { formatTitle, ...translations } = useTranslations();

  if (isFetching) {
    return <LoadingScreen height="large" />;
  }

  if (isError || !product) {
    return <div>Something went wrong</div>; // TODO: add ErrorScreen
  }

  return (
    <Grid container>
      <Grid item xs={6} p={1.5} pl={0}>
        <Card elevation={1}>
          <CardMediaImg
            sx={{ maxHeight: 400, backgroundColor: "grey.200" }}
            image={product.imageURL}
          />
        </Card>
      </Grid>
      <Grid
        container
        item
        xs={6}
        p={1.5}
        pr={0}
        display="flex"
        flexWrap="wrap"
        columnGap={0}
      >
        <Grid item xs={12}>
          <Card elevation={1}>
            <CardContent>
              <Typography fontSize={28} height={84}>
                {product.title}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={6} pr={1} mt={3}>
          <ProductPriceRateCard priceStatus="down" />
        </Grid>

        <Grid item xs={6} pl={1} mt={3}>
          <ProductPriceRateCard priceStatus="up" />
        </Grid>
      </Grid>
      <Grid container item xs={12} mt={3} columns={10}>
        <Grid item xs={2} pr={1}>
          <ProductPriceInfoCard type="average" price={100.0} />
        </Grid>
        <Grid item xs={2} px={1}>
          <ProductPriceInfoCard type="lowest" price={100.0} />
        </Grid>
        <Grid item xs={2} px={1}>
          <ProductPriceInfoCard type="highest" price={100.0} />
        </Grid>
        <Grid item xs={4} pl={1}>
          <ProductPricePeriodCard updatePeriodDays={1} />
        </Grid>
      </Grid>
      <Grid container item xs={12} mt={4}>
        <Grid item xs={12}>
          <ChartDescriptionWrapper title={product.title}>
            <StackedBarChart
              data={stackedBarMockedData}
              height={332}
              color={theme.palette.primary.main}
              xAxisKey="month"
              yAxisKey="price"
              legendTranslations={
                translations.averagePriceChartLegendTranslations
              }
            />
          </ChartDescriptionWrapper>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default ProductDetailsScreen;
