const styles = {
  defaultCardStyles: {
    boxShadow: 1,
  },
  priceDownCardStyles: {
    backgroundColor: "success.light",
  },
  priceUpCardStyles: {
    backgroundColor: "error.light",
  },
};

export default styles;
