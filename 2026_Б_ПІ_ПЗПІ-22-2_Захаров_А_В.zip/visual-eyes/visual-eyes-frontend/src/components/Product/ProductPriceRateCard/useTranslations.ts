import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    priceDownText: intl.formatMessage(messages.priceDownText),
    priceUpText: intl.formatMessage(messages.priceUpText),
  };

  return translations;
};

export default useTranslations;
