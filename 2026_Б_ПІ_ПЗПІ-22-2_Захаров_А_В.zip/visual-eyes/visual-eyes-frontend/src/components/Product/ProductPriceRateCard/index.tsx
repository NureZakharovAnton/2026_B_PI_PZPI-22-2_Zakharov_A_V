import React from "react";
import Grid from "../../General/Grid";
import Typography from "../../General/Typography";
import Card from "../../General/Card";
import Box from "../../General/Box";
import styles from "./styles";
import { PriceStatus } from "./types";
import usePriceStatus from "./usePriceStatus";

type ProductPriceRateCardProps = {
  // TODO: add productPrices
  priceStatus: PriceStatus;
};

const MOCKED_PRICE = "100.00";
const MOCKED_CURRENCY_SYMBOL = "$";

const ProductPriceRateCard: React.FC<ProductPriceRateCardProps> = ({
  priceStatus,
}) => {
  const status = usePriceStatus(priceStatus);

  // TODO: possibly replace icon to the next row

  return (
    <Card sx={[styles.defaultCardStyles, status.cardStyle]}>
      <Grid container>
        <Grid item xs={12} mt={6}>
          <Typography fontSize={28} textAlign="center">
            {status.text}
          </Typography>
        </Grid>
        <Grid
          item
          xs={12}
          mt={6}
          mb={6}
          alignItems="center"
          justifyContent="center"
          display="flex"
          px={10}
        >
          <Typography fontSize={40} textAlign="center" color="grey.400" mr={3}>
            {MOCKED_PRICE}
            {MOCKED_CURRENCY_SYMBOL}
          </Typography>
          <Box>{status.icon}</Box>
        </Grid>
      </Grid>
    </Card>
  );
};

export default ProductPriceRateCard;
