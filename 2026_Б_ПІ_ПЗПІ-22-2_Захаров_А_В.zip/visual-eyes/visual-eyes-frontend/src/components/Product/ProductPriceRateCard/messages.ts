import { defineMessages } from "react-intl";

const messages = defineMessages({
  priceDownText: {
    id: "Product.ProductPriceRateCard.priceDownText",
    defaultMessage: "price down",
  },
  priceUpText: {
    id: "Product.ProductPriceRateCard.priceUpText",
    defaultMessage: "price up",
  },
});

export default messages;
