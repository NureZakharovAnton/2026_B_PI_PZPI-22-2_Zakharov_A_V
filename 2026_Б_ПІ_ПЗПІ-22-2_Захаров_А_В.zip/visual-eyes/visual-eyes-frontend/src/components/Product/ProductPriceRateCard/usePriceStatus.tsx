import { useTheme } from "../../../hooks";
import { IconPriceRateDown, IconPriceRateUp } from "../../General/Icons";
import styles from "./styles";
import { PriceStatus } from "./types";
import useTranslations from "./useTranslations";

const usePriceStatus = (status: PriceStatus) => {
  const { priceDownText, priceUpText } = useTranslations();
  const theme = useTheme();

  const priceStatusMapper = {
    up: {
      text: priceUpText,
      icon: <IconPriceRateUp fill={theme.palette.error.dark} />,
      cardStyle: styles.priceUpCardStyles,
    },
    down: {
      text: priceDownText,
      icon: <IconPriceRateDown fill={theme.palette.success.dark} />,
      cardStyle: styles.priceDownCardStyles,
    },
  };

  return priceStatusMapper[status];
};

export default usePriceStatus;
