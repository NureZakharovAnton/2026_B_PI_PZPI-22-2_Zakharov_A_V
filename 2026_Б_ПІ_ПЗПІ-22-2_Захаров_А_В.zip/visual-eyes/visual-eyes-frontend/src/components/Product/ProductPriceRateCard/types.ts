export type PriceStatus = "up" | "down";
