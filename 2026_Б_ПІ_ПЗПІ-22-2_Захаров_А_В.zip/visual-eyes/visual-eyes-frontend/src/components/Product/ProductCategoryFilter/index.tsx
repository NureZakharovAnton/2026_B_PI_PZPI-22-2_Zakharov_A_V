import React, { SyntheticEvent } from "react";
import { useGetCategoriesQuery, Category, Id } from "../../../redux/API";
import Autocomplete from "../../General/Autocomplete";
import TextField from "../../General/TextField";
import getCategoryOptionLabel from "./getCategoryOptionLabel";
import useTranslations from "./useTranslations";

type ProductCategoryFilterProps = {
  setOptionIds: (value: Id[]) => void;
};

const ProductCategoryFilter: React.FC<ProductCategoryFilterProps> = ({
  setOptionIds,
}) => {
  const { currentData: categories } = useGetCategoriesQuery({});
  const categoryOptions = categories || [];

  const translations = useTranslations();

  const handleChange = (
    e: SyntheticEvent<Element, Event>,
    value: Category | null
  ) => {
    const optionsIds = value ? [{ id: value.id }] : [];
    setOptionIds(optionsIds);
  };

  return (
    <Autocomplete
      options={categoryOptions}
      getOptionLabel={getCategoryOptionLabel}
      onChange={handleChange}
      renderInput={(params) => (
        <TextField
          {...params}
          label={translations.label}
          InputProps={{ ...params.InputProps, disableUnderline: true }}
        />
      )}
    />
  );
};

export default ProductCategoryFilter;
