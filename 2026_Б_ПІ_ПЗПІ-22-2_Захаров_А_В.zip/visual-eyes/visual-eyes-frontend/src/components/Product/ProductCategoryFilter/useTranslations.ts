import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    label: intl.formatMessage(messages.label),
  };

  return translations;
};

export default useTranslations;
