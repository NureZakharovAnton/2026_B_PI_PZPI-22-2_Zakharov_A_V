import { defineMessages } from "react-intl";

const messages = defineMessages({
  label: {
    defaultMessage: "Category",
    id: "Product.ProductCategoryFilter.label",
  },
});

export default messages;
