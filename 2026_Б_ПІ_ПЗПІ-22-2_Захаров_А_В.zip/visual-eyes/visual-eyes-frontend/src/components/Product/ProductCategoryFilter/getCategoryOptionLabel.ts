import { Category } from "../../../redux/API";

const getCategoryOptionLabel = (option: Category) => option.title;

export default getCategoryOptionLabel;
