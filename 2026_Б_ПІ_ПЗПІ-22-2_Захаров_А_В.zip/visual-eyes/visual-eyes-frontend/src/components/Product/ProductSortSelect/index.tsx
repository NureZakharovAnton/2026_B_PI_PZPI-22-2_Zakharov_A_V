import React from "react";
import { SortBy } from "../../../redux/API";
import FormControl from "../../General/FormControl";
import InputLabel from "../../General/InputLabel";
import MenuItem from "../../General/MenuItem";
import Select, { SelectChangeEvent } from "../../General/Select";
import checkIsSortByValue from "../../General/SortSelect/checkIsSortByValue";
import useTranslations from "../../General/SortSelect/useTranslations";

type ProductSortSelectProps = {
  value: string;
  setValue: (value: SortBy) => void;
};

const ProductSortSelect: React.FC<ProductSortSelectProps> = ({
  value,
  setValue,
}) => {
  const translations = useTranslations();

  const handleSortByChange = (e: SelectChangeEvent) => {
    const value = e.target.value;
    const isSortByValue = checkIsSortByValue(value);

    if (!isSortByValue) {
      return;
    }

    setValue(value);
  };

  return (
    <FormControl fullWidth>
      <InputLabel id="sort-by-label">{translations.sortByLabel}</InputLabel>
      <Select
        value={value}
        onChange={handleSortByChange}
        label={translations.sortByLabel}
        labelId="sort-by-label"
        fullWidth
      >
        <MenuItem value="">{translations.none}</MenuItem>
        <MenuItem value="asc">{translations.asc}</MenuItem>
        <MenuItem value="desc">{translations.desc}</MenuItem>
      </Select>
    </FormControl>
  );
};

export default ProductSortSelect;
