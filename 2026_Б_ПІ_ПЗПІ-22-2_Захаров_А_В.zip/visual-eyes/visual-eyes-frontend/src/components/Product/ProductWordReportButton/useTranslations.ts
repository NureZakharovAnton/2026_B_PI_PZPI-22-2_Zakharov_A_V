import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    buttonText: intl.formatMessage(messages.buttonText),
  };

  return translations;
};

export default useTranslations;
