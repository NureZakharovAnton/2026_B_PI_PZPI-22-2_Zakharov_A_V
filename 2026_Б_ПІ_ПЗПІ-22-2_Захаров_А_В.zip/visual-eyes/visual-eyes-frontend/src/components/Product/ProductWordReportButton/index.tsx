import React from "react";
import { Product } from "../../../redux/API";
import useWord from "../../../hooks/useWord/useWord";
import Box from "../../General/Box";
import Button from "../../General/Button";
import useTranslations from "./useTranslations";

type ProductWordReportButtonProps = {
  products: Product[];
};

const ProductWordReportButton: React.FC<ProductWordReportButtonProps> = ({
  products,
}) => {
  const translations = useTranslations();
  const { saveProductsToDocx } = useWord();

  return (
    <Box>
      <Button
        variant="contained"
        onClick={() => saveProductsToDocx({ products })}
      >
        {translations.buttonText}
      </Button>
    </Box>
  );
};

export default ProductWordReportButton;
