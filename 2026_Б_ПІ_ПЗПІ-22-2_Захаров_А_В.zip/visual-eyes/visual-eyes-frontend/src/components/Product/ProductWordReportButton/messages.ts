import { defineMessages } from "react-intl";

const messages = defineMessages({
  buttonText: {
    id: "Product.ProductWordReportButton.buttonText",
    defaultMessage: "docx",
  },
});

export default messages;
