import { useIntl } from "react-intl";
import messages from "./messages";
import { ProductPriceFilterMode } from "./types";

type UseTranslationsArgs = {
  mode: ProductPriceFilterMode;
};

const modesMessagesMapper = {
  from: messages.from,
  to: messages.to,
};

const useTranslations = ({ mode }: UseTranslationsArgs) => {
  const intl = useIntl();

  const labelMessage = modesMessagesMapper[mode];

  const translations = {
    label: intl.formatMessage(labelMessage),
  };

  return translations;
};

export default useTranslations;
