const formatPriceFilter = (price?: number) => {
  return price || "";
};

export default formatPriceFilter;
