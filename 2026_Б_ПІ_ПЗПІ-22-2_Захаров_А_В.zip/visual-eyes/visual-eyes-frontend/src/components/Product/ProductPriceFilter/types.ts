export type ProductPriceFilterMode = "from" | "to";

export type ProductPriceFilterProps = {
  value?: number;
  setValue: (value?: number) => void;
  mode: ProductPriceFilterMode;
};
