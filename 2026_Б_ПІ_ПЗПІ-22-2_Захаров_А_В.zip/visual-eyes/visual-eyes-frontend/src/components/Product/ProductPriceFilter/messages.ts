import { defineMessages } from "react-intl";

const messages = defineMessages({
  from: {
    id: "Product.ProductPriceFilter.from",
    defaultMessage: "Price from",
  },
  to: {
    id: "Product.ProductPriceFilter.to",
    defaultMessage: "Price to",
  },
});

export default messages;
