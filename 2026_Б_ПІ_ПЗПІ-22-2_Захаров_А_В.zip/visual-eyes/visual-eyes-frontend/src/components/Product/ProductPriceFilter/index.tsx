import { ChangeEvent } from "react";
import TextField from "../../General/TextField";
import formatPriceFilter from "./formatPriceFilter";
import useTranslations from "./useTranslations";
import { ProductPriceFilterProps } from "./types";

const ProductPriceFilter: React.FC<ProductPriceFilterProps> = ({
  value,
  setValue,
  mode,
}) => {
  const translations = useTranslations({ mode });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;

    if (value.includes(" ")) {
      return;
    }

    const numericValue = +value;
    if (isFinite(numericValue)) {
      setValue(numericValue);
      return;
    }
  };

  const formattedValue = formatPriceFilter(value);

  return (
    <TextField
      value={formattedValue}
      label={translations.label}
      onChange={handleChange}
      fullWidth
    />
  );
};

export default ProductPriceFilter;
