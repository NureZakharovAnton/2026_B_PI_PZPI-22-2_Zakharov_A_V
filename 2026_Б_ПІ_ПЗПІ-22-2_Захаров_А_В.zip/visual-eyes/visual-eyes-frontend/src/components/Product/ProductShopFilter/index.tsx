import React, { SyntheticEvent } from "react";
import { useGetShopsQuery, Shop, Id } from "../../../redux/API";
import Autocomplete from "../../General/Autocomplete";
import TextField from "../../General/TextField";
import getShopOptionLabel from "./getShopOptionLabel";
import useTranslations from "./useTranslations";

type ProductShopFilterProps = {
  setOptionIds: (value: Id[]) => void;
};

const ProductShopFilter: React.FC<ProductShopFilterProps> = ({
  setOptionIds,
}) => {
  const { currentData: shops } = useGetShopsQuery({});
  const shopOptions = shops || [];

  const translations = useTranslations();

  const handleChange = (
    e: SyntheticEvent<Element, Event>,
    value: Shop | null
  ) => {
    const optionsIds = value ? [{ id: value.id }] : [];
    setOptionIds(optionsIds);
  };

  return (
    <Autocomplete
      options={shopOptions}
      getOptionLabel={getShopOptionLabel}
      onChange={handleChange}
      renderInput={(params) => (
        <TextField
          {...params}
          label={translations.label}
          InputProps={{ ...params.InputProps, disableUnderline: true }}
        />
      )}
    />
  );
};

export default ProductShopFilter;
