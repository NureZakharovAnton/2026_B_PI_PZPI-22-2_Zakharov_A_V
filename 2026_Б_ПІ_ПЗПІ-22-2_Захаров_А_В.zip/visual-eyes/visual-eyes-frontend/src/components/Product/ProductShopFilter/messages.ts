import { defineMessages } from "react-intl";

const messages = defineMessages({
  label: {
    defaultMessage: "Shop",
    id: "Product.ProductShopFilter.label",
  },
});

export default messages;
