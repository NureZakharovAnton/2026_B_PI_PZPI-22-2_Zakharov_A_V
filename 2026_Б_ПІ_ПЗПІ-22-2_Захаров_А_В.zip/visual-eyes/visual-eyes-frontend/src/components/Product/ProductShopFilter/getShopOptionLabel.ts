import { Shop } from "../../../redux/API";

const getShopOptionLabel = (option: Shop) => option.title;

export default getShopOptionLabel;
