import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    clearButtonText: intl.formatMessage(messages.clearButtonText),
    searchLabel: intl.formatMessage(messages.searchLabel),
  };

  return translations;
};

export default useTranslations;
