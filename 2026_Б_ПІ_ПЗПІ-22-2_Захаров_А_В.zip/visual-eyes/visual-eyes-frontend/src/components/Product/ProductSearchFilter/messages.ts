import { defineMessages } from "react-intl";

const messages = defineMessages({
  clearButtonText: {
    id: "Product.ProductSearchFilter.clearButtonText",
    defaultMessage: "Clear",
  },
  searchLabel: {
    id: "Product.ProductSearchFilter.searchLabel",
    defaultMessage: "Title",
  },
});

export default messages;
