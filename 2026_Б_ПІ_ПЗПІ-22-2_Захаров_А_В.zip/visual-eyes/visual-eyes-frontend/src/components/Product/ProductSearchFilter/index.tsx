import React, { ChangeEvent } from "react";
import Box from "../../General/Box";
import TextField from "../../General/TextField";
import Button from "../../General/Button";
import useTranslations from "./useTranslations";

type ProductSearchFilterProps = {
  value: string;
  setValue: (value: string) => void;
  width: number;
};

const ProductSearchFilter: React.FC<ProductSearchFilterProps> = ({
  value,
  setValue,
  width,
}) => {
  const translations = useTranslations();

  const handleSearchValueChange = (e: ChangeEvent<HTMLInputElement>) => {
    setValue(e.target.value);
  };

  const handleSearchValueClear = () => {
    setValue("");
  };

  return (
    <Box display="flex" justifyContent="center">
      <TextField
        InputProps={{ sx: { borderRadius: 10 } }}
        value={value}
        label={translations.searchLabel}
        onChange={handleSearchValueChange}
        sx={{ width }}
        fullWidth
      />
      <Button sx={{ borderRadius: 10 }} onClick={handleSearchValueClear}>
        {translations.clearButtonText}
      </Button>
    </Box>
  );
};

export default ProductSearchFilter;
