import * as Yup from "yup";
import {
  MAX_EMAIL_LENGTH,
  MAX_NICKNAME_LENGTH,
  MAX_PASSWORD_LENGTH,
  MIN_NICKNAME_LENGTH,
  MIN_PASSWORD_LENGTH,
} from "../../../common/constants";

interface RegistrationFormSchemaTranslations {
  emailRequired: string;
  invalidEmail: string;
  maxEmailLength: string;
  passwordRequired: string;
  minPasswordLength: string;
  maxPasswordLength: string;
  nicknameRequired: string;
  minNicknameLength: string;
  maxNicknameLength: string;
}

const useValidationSchema = (
  translations: RegistrationFormSchemaTranslations
) => {
  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .email(translations.invalidEmail)
      .required(translations.emailRequired)
      .max(MAX_EMAIL_LENGTH, translations.maxEmailLength),
    password: Yup.string()
      .min(MIN_PASSWORD_LENGTH, translations.minPasswordLength)
      .max(MAX_PASSWORD_LENGTH, translations.maxPasswordLength)
      .required(translations.passwordRequired),
    nickname: Yup.string()
      .min(MIN_NICKNAME_LENGTH, translations.minNicknameLength)
      .max(MAX_NICKNAME_LENGTH, translations.maxNicknameLength)
      .required(translations.nicknameRequired),
  });

  return validationSchema;
};

export default useValidationSchema;
