import React from "react";
import { useFormik } from "formik";
import { useAlert, useAuth } from "../../../redux/hooks";
import ROUTES from "../../../common/routes";
import RouterLink from "../../General/RouterLink";
import Box from "../../General/Box";
import Stack from "../../General/Stack";
import Typography from "../../General/Typography";
import TextField from "../../General/TextField";
import Button from "../../General/Button";
import useTranslations from "./useTranslations";
import useValidationSchema from "./useValidationSchema";

const initialValues = {
  email: "",
  password: "",
  nickname: "",
};

const RegistrationScreen = () => {
  const { register } = useAuth();
  const { showTranslatedErrorAlert, showSuccessAlert } = useAlert();
  const translations = useTranslations();

  const validationSchema = useValidationSchema(
    translations.registrationFormSchemaTranslations
  );

  const showWelcomeAlert = () => showSuccessAlert(translations.welcomeText);

  const { values, errors, handleChange, handleSubmit, isSubmitting } =
    useFormik({
      initialValues,
      validationSchema,
      validateOnChange: false,
      onSubmit: async (values) => {
        try {
          await register(values);
          showWelcomeAlert();
        } catch (error) {
          showTranslatedErrorAlert(error);
        }
      },
    });

  return (
    <Box
      width="100%"
      height="100vh"
      display="flex"
      justifyContent="center"
      alignItems="center"
    >
      <Stack width={275} flexDirection="column" spacing={4}>
        <Typography typography="title">{translations.title}</Typography>
        <form onSubmit={handleSubmit}>
          <Stack spacing={4}>
            <TextField
              type="text"
              placeholder={translations.nicknameInputPlaceholder}
              value={values.nickname}
              error={!!errors.nickname}
              onChange={handleChange("nickname")}
              helperText={errors.nickname}
            />
            <TextField
              type="text"
              placeholder={translations.emailInputPlaceholder}
              value={values.email}
              error={!!errors.email}
              onChange={handleChange("email")}
              helperText={errors.email}
            />
            <TextField
              type="password"
              placeholder={translations.passwordInputPlaceholder}
              value={values.password}
              error={!!errors.password}
              onChange={handleChange("password")}
              helperText={errors.password}
            />
            <Button
              fullWidth
              type="submit"
              variant="contained"
              loading={isSubmitting}
            >
              <Typography typography="submitButton" p={0.5}>
                {translations.submitButtonText}
              </Typography>
            </Button>
          </Stack>
        </form>
        <RouterLink to={ROUTES.LOGIN} typographyProps={{ textAlign: "center" }}>
          {translations.loginLink} !
        </RouterLink>
      </Stack>
    </Box>
  );
};

export default RegistrationScreen;
