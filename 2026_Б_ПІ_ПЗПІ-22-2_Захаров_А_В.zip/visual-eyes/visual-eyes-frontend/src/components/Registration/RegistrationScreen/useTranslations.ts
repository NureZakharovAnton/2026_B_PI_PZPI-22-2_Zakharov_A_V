import { useIntl } from "react-intl";
import commonMessages from "../../../common/messages";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    title: intl.formatMessage(messages.title),
    emailInputPlaceholder: intl.formatMessage(commonMessages.emailPlaceholder),
    passwordInputPlaceholder: intl.formatMessage(
      commonMessages.passwordPlaceholder
    ),
    nicknameInputPlaceholder: intl.formatMessage(
      commonMessages.nicknamePlaceholder
    ),
    submitButtonText: intl.formatMessage(messages.submitButtonText),
    loginLink: intl.formatMessage(messages.loginLink),
    registrationFormSchemaTranslations: {
      emailRequired: intl.formatMessage(commonMessages.emailRequired),
      invalidEmail: intl.formatMessage(commonMessages.invalidEmail),
      maxEmailLength: intl.formatMessage(commonMessages.maxEmailLength),
      passwordRequired: intl.formatMessage(commonMessages.passwordRequired),
      minPasswordLength: intl.formatMessage(commonMessages.minPasswordLength),
      maxPasswordLength: intl.formatMessage(commonMessages.maxPasswordLength),
      nicknameRequired: intl.formatMessage(commonMessages.nicknameRequired),
      minNicknameLength: intl.formatMessage(commonMessages.minNicknameLength),
      maxNicknameLength: intl.formatMessage(commonMessages.maxNicknameLength),
    },
    welcomeText: `${intl.formatMessage(messages.welcomeText)} 🚀`,
  };

  return translations;
};

export default useTranslations;
