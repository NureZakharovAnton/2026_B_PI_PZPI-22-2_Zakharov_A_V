import { defineMessages } from "react-intl";

const messages = defineMessages({
  title: {
    id: "Registration.RegistrationScreen.title",
    defaultMessage: "Register",
  },
  submitButtonText: {
    id: "Registration.RegistrationScreen.submitButtonText",
    defaultMessage: "Submit",
  },
  loginLink: {
    id: "Registration.RegistrationScreen.loginLink",
    defaultMessage: "I have account already",
  },
  welcomeText: {
    id: "Registration.RegistrationScreen.welcomeText",
    defaultMessage: "Welcome on board",
  },
});

export default messages;
