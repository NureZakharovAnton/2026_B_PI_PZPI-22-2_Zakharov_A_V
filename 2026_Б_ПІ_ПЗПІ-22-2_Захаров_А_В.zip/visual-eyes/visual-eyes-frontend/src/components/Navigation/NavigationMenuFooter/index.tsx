import React from "react";
import Box from "../../General/Box";
import UserAvatar from "../../User/UserAvatar";

interface NavigationMenuFooterProps {
  isOpen: boolean;
}

const NavigationMenuFooter: React.FC<NavigationMenuFooterProps> = ({
  isOpen,
}) => {
  return (
    <Box mb={2} ml={2}>
      <UserAvatar isOpen={isOpen} />
    </Box>
  );
};

export default NavigationMenuFooter;
