import React, { ComponentType } from "react";
import Button from "../../General/Button";
import IconProps from "../../General/Icons/IconProps";
import useSx from "./useSx";
import classNames from "classnames";

interface MenuItemProps {
  active: boolean;
  title: string;
  icon: ComponentType<IconProps>;
  onClick: () => void;
  open: boolean;
}

const NavigationMenuItem = ({
  active,
  title,
  icon: Icon,
  onClick,
  open,
}: MenuItemProps) => {
  const sx = useSx();

  return (
    <Button
      sx={sx}
      fullWidth={open}
      className={classNames({ active, open })}
      startIcon={<Icon className="icon" />}
      onClick={onClick}
    >
      {open && title}
    </Button>
  );
};

export default NavigationMenuItem;
