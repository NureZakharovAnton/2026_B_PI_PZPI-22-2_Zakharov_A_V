import { useTheme } from "../../../hooks";

const useSx = () => {
  const theme = useTheme();

  const sx = {
    fontWeight: "bold",
    textTransform: "none",
    color: "grey.300",
    justifyContent: "center",
    height: 46,
    width: "75%",
    minWidth: 0,

    "& .MuiButton-startIcon": {
      mr: 0,
      ml: 0,
    },

    "& .icon": {
      stroke: theme.palette.grey[300],
    },

    "&.active": {
      backgroundColor: "primary.light",
      color: "primary.main",
      "& .icon": {
        stroke: theme.palette.primary.main,
      },
    },

    "&.open": {
      width: "100%",
      justifyContent: "flex-start",
      borderLeft: "5px solid transparent",
      "& .MuiButton-startIcon": {
        mr: 1,
      },

      "&.active": {
        borderLeftColor: "primary.main",
      },
    },
  };

  return sx;
};

export default useSx;
