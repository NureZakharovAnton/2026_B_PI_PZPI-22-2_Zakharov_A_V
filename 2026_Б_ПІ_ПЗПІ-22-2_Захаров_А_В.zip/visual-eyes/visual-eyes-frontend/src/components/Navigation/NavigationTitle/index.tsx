import React from "react";
import { useTheme } from "../../../hooks";
import { IconArrow } from "../../General/Icons";
import Typography from "../../General/Typography";
import useTranslations from "./useTranslations";

const NavigationTitle = () => {
  const theme = useTheme();
  const translations = useTranslations();

  return (
    <>
      <IconArrow stroke={theme.palette.grey[300]} />
      <Typography
        fontWeight="bold"
        color="grey.300"
        overflow="hidden"
        maxHeight={24}
      >
        {translations.title}
      </Typography>
    </>
  );
};

export default NavigationTitle;
