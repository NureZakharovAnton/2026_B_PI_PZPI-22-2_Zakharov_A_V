import { defineMessages } from "react-intl";

export default defineMessages({
  title: {
    id: "Navigation.NavigationTitle.title",
    defaultMessage: "Navigation Menu",
  },
});
