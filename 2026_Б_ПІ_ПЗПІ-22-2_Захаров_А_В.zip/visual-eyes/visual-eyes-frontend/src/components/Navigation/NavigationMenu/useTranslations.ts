import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    dashboard: intl.formatMessage(messages.dashboard),
    notifications: intl.formatMessage(messages.notifications),
    shops: intl.formatMessage(messages.shops),
    products: intl.formatMessage(messages.products),
  };

  return translations;
};

export default useTranslations;
