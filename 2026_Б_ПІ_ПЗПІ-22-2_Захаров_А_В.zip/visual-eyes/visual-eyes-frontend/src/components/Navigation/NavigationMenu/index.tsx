import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Box from "../../General/Box";
import Stack from "../../General/Stack";
import NavigationMenuFooter from "../NavigationMenuFooter";
import NavigationMenuItem from "../NavigationMenuItem";
import NavigationMenuHeader from "../NavigationMenuHeader";
import useNavigationItems from "./useNavigationItems";
import getSx from "./getSx";

const NavigationMenu = () => {
  const navigate = useNavigate();
  const navigationItems = useNavigationItems();
  const location = useLocation();

  const [navigationOpened, setNavigationOpened] = useState(false);

  const handleToggleMenu = () => {
    setNavigationOpened((prev) => !prev);
  };

  const sx = getSx(navigationOpened);

  return (
    <Box sx={sx}>
      <Stack direction="column" height="100%" alignItems="left">
        <Stack
          direction="column"
          alignItems="center"
          height="100%"
          width="100%"
        >
          <NavigationMenuHeader
            open={navigationOpened}
            onClickHeader={handleToggleMenu}
          />
          {navigationItems.map((item) => (
            <NavigationMenuItem
              key={item.link}
              active={item.link === location.pathname}
              icon={item.icon}
              title={item.title}
              onClick={() => {
                // TODO: spell to <Link> from router-dom
                navigate(item.link);
              }}
              open={navigationOpened}
            />
          ))}
        </Stack>
        <NavigationMenuFooter isOpen={navigationOpened} />
      </Stack>
    </Box>
  );
};

export default NavigationMenu;
