import { defineMessages } from "react-intl";

export default defineMessages({
  dashboard: {
    id: "Navigation.NavigationMenu.dashboard",
    defaultMessage: "Dashboard",
  },
  notifications: {
    id: "Navigation.NavigationMenu.notifications",
    defaultMessage: "Notifications",
  },
  shops: {
    id: "Navigation.NavigationMenu.shops",
    defaultMessage: "Shops",
  },
  products: {
    id: "Navigation.NavigationMenu.products",
    defaultMessage: "Products",
  },
});
