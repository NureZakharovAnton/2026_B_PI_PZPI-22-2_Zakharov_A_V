import { useMemo } from "react";
import ROUTES from "../../../common/routes";
import {
  IconBell,
  IconCart,
  IconDashboard,
  IconShop,
} from "../../General/Icons";
import useTranslations from "./useTranslations";

const useNavigationItems = () => {
  const translations = useTranslations();

  const navigationItems = useMemo(
    () => [
      {
        icon: IconDashboard,
        title: translations.dashboard,
        link: ROUTES.DASHBOARD,
      },
      {
        icon: IconBell,
        title: translations.notifications,
        link: ROUTES.NOTIFICATIONS,
      },
      {
        icon: IconShop,
        title: translations.shops,
        link: ROUTES.SHOPS,
      },
      { icon: IconCart, title: translations.products, link: ROUTES.PRODUCTS },
    ],
    [translations]
  );

  return navigationItems;
};

export default useNavigationItems;
