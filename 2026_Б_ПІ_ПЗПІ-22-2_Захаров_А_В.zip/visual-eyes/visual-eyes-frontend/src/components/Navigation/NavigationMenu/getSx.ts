import { SxProps } from "../../../types";

const getSx = (open: boolean) => {
  const sx: SxProps = {
    width: open ? 300 : 80,
    height: "100vh",
    boxShadow: 1,
    transition: "width 0.5s",
  };

  return sx;
};

export default getSx;
