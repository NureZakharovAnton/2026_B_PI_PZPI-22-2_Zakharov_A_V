import React, { ReactNode } from "react";
import NavigationMenu from "../NavigationMenu";
import Box from "../../General/Box";
import getSx from "./styles";

interface NavigationLayoutProps {
  children: ReactNode;
  hasSpacing?: boolean;
}

const NavigationLayout = ({
  children,
  hasSpacing = false,
}: NavigationLayoutProps) => {
  const { layoutContainerSx, contentContainerSx, childrenContainerSx } = getSx({
    hasSpacing,
  });

  return (
    <Box sx={layoutContainerSx} className="navigation-layout">
      <NavigationMenu />
      <Box sx={contentContainerSx}>
        <Box sx={childrenContainerSx}>{children}</Box>
      </Box>
    </Box>
  );
};

export default NavigationLayout;
