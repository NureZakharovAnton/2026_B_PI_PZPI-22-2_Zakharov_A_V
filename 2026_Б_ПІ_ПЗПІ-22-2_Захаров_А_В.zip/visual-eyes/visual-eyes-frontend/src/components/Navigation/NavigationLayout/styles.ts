interface GetSxArgs {
  hasSpacing: boolean;
}

const getSx = ({ hasSpacing }: GetSxArgs) => {
  const layoutContainerSx = { display: "flex" };
  const contentContainerSx = { height: "100vh", overflowY: "auto", width: '100%' };
  const childrenContainerSx = { p: hasSpacing ? 4 : 0, };

  return { layoutContainerSx, contentContainerSx, childrenContainerSx };
};

export default getSx;
