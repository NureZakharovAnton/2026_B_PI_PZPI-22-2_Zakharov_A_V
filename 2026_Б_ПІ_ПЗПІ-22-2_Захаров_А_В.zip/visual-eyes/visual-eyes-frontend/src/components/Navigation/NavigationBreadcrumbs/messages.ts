import { defineMessages } from "react-intl";

export default defineMessages({
  dashboardLabel: {
    id: "General.BreadcrumbsLayout.dashboardLabel",
    defaultMessage: "Dashboard",
  },
  notificationsLabel: {
    id: "General.BreadcrumbsLayout.notificationsLabel",
    defaultMessage: "Notifications",
  },
  shopsLabel: {
    id: "General.BreadcrumbsLayout.shopsLabel",
    defaultMessage: "Shops",
  },
  productsLabel: {
    id: "General.BreadcrumbsLayout.productsLabel",
    defaultMessage: "Products",
  },
});
