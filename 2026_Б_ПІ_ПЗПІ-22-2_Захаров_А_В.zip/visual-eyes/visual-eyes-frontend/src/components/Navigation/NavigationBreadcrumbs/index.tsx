import BreadcrumbLink from "../../General/BreadcrumbLink";
import Breadcrumbs from "../../General/Breadcrumbs";
import useBreadcrumbs from "./useBreadcrumbs";

const NavigationBreadcrumbs = () => {
  const breadcrumbs = useBreadcrumbs();

  return (
    <Breadcrumbs>
      {breadcrumbs.map(({ breadcrumb, key, match }, i, arr) => (
        <BreadcrumbLink
          key={key}
          breadcrumb={breadcrumb}
          to={match.pathname}
          isLast={i === arr.length - 1}
        />
      ))}
    </Breadcrumbs>
  );
};

export default NavigationBreadcrumbs;
