import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    dashboardLabel: intl.formatMessage(messages.dashboardLabel),
    notificationsLabel: intl.formatMessage(messages.notificationsLabel),
    shopsLabel: intl.formatMessage(messages.shopsLabel),
    productsLabel: intl.formatMessage(messages.productsLabel),
  };

  return translations;
};

export default useTranslations;
