import useBreadcrumbsBase from "use-react-router-breadcrumbs";
import useBreadcrumbsRoutes from "./useBreadcrumbsRoutes";

const useBreadcrumbs = () => {
  const breadcrumbsRoutes = useBreadcrumbsRoutes();
  const breadcrumbs = useBreadcrumbsBase(breadcrumbsRoutes);

  return breadcrumbs;
};

export default useBreadcrumbs;
