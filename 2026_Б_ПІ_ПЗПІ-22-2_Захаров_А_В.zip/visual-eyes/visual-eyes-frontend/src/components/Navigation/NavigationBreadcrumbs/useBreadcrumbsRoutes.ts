import ROUTES from "../../../common/routes";
import useTranslations from "./useTranslations";

const useBreadcrumbsRoutes = () => {
  const translations = useTranslations();

  const breadcrumbsRoutes = [
    {
      path: ROUTES.ROOT,
      breadcrumb: null,
    },
    {
      path: ROUTES.DASHBOARD,
      breadcrumb: translations.dashboardLabel,
    },
    {
      path: ROUTES.NOTIFICATIONS,
      breadcrumb: translations.notificationsLabel,
    },
    {
      path: ROUTES.SHOPS,
      breadcrumb: translations.shopsLabel,
    },
    {
      path: ROUTES.PRODUCTS,
      breadcrumb: translations.productsLabel,
    },
  ];

  return breadcrumbsRoutes;
};

export default useBreadcrumbsRoutes;
