import React from "react";
import ROUTES from "../../../common/routes";
import { useTheme } from "../../../hooks";
import Box, { BoxProps } from "../../General/Box";
import RouterLink from "../../General/RouterLink";
import { IconLogo } from "../../General/Icons";

type NavigationLogoProps = BoxProps;

const NavigationLogo = (props: NavigationLogoProps) => {
  const theme = useTheme();

  return (
    <Box {...props}>
      <RouterLink to={ROUTES.DASHBOARD}>
        <IconLogo
          circleColor={theme.palette.common.white}
          letterColor={theme.palette.primary.main}
        />
      </RouterLink>
    </Box>
  );
};

export default NavigationLogo;
