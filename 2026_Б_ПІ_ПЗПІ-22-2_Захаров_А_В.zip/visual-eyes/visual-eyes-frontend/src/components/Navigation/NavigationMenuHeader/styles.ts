const sx = {
  cursor: "pointer",
  pt: 3,
  pb: 4,
  "&.open": {
    overflow: 'hidden',
  },
};

export default sx;
