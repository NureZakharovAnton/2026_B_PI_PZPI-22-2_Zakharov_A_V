import React from "react";
import { useTheme } from "../../../hooks";
import classNames from "../../../common/classNames";
import Stack from "../../General/Stack";
import { IconSearch } from "../../General/Icons";
import NavigationTitle from "../NavigationTitle";
import NavigationLogo from "../NavigationLogo";
import sx from "./styles";

interface NavigationMenuHeaderProps {
  open: boolean;
  onClickHeader: () => void;
}

const NavigationMenuHeader = ({
  open,
  onClickHeader,
}: NavigationMenuHeaderProps) => {
  const theme = useTheme();

  return (
    <>
      {!open && <NavigationLogo mt={2} />}
      <Stack
        sx={sx}
        spacing={2}
        direction="row"
        alignItems="center"
        className={classNames({ open })}
        onClick={onClickHeader}
      >
        {!open && <IconSearch fill={theme.palette.grey[300]} />}
        {open && <NavigationTitle />}
      </Stack>
    </>
  );
};

export default NavigationMenuHeader;
