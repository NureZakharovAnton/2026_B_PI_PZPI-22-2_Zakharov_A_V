import { defineMessages } from "react-intl";

export default defineMessages({
  title: {
    id: "Dashboard.DashboardScreen.title",
    defaultMessage: "Welcome, {nickname}",
  },
  description: {
    id: "Dashboard.DashboardScreen.description",
    defaultMessage: "We prepared some interesting data for you",
  },
  averagePriceChartTitle: {
    id: "Dashboard.DashboardScreen.averagePriceChartTitle",
    defaultMessage: "Average Shops Price",
  },
  categoriesChartTitle: {
    id: "Dashboard.DashboardScreen.categoriesChartTitle",
    defaultMessage: "Top Categories",
  },
  priceDynamicChartTitle: {
    id: "Dashboard.DashboardScreen.priceDynamicChartTitle",
    defaultMessage: "Cheese Price Dynamic",
  },
  averagePriceLegendText: {
    id: "Dashboard.DashboardScreen.averagePriceLegendText",
    defaultMessage: "Average Price",
  },
  shopsHeading: {
    id: "Dashboard.DashboardScreen.shopsHeading",
    defaultMessage: "Shops",
  },
  productsHeading: {
    id: "Dashboard.DashboardScreen.productsHeading",
    defaultMessage: "Products",
  },
});
