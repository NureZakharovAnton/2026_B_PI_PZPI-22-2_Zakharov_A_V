import React from "react";
import { useTheme } from "../../../hooks";
import { useAuth } from "../../../redux/hooks";
import ROUTES from "../../../common/routes";
import { DEFAULT_USER_NICKNAME } from "../../../common/constants";
import Overview from "../../General/Overview";
import Typography from "../../General/Typography";
import Stack from "../../General/Stack";
import Grid from "../../General/Grid";
import ChartDescriptionWrapper from "../../General/ChartDescriptionWrapper";
import StackedBarChart from "../../General/StackedBarChart";
import pieChartMockedData from "../../General/PieChart/mockData";
import areaChartMockedData from "../../General/AreaChart/mockedData";
import stackedBarMockedData from "../../General/StackedBarChart/mockedData";
import PieChart from "../../General/PieChart";
import AreaChart from "../../General/AreaChart";
import Navigate from "../../Navigation/Navigate";
import useTranslations from "./useTranslations";

const DashboardScreen = () => {
  const { user, isLoggedIn } = useAuth();
  const { formatTitle, ...translations } = useTranslations();
  const theme = useTheme();

  const nickname = user?.nickname || DEFAULT_USER_NICKNAME;
  const title = `${formatTitle(nickname)} 👋`;

  if (!isLoggedIn) {
    return <Navigate to={ROUTES.LOGIN} />;
  }

  return (
    <Stack direction="column" spacing={5} width="100%">
      <Overview title={title} description={`${translations.description}`!} />
      <Typography typography="h2" variant="h2" pl={10}>
        {translations.shopsHeading} 🛒
      </Typography>
      <Grid container mt={0}>
        <Grid item xs={12}>
          <ChartDescriptionWrapper title={translations.averagePriceChartTitle}>
            <StackedBarChart
              data={stackedBarMockedData}
              height={332}
              color={theme.palette.primary.main}
              xAxisKey="month"
              yAxisKey="price"
              legendTranslations={
                translations.averagePriceChartLegendTranslations
              }
            />
          </ChartDescriptionWrapper>
        </Grid>
      </Grid>

      <Typography typography="h2" variant="h2" pl={10}>
        {translations.productsHeading} 🍕
      </Typography>
      <Grid container justifyContent="space-between">
        <Grid item xs={3.5}>
          <ChartDescriptionWrapper title={translations.categoriesChartTitle}>
            <PieChart
              data={pieChartMockedData}
              height={300}
              color={theme.palette.primary.main}
            />
          </ChartDescriptionWrapper>
        </Grid>
        <Grid item xs={8.3}>
          <ChartDescriptionWrapper title={translations.priceDynamicChartTitle}>
            <AreaChart
              data={areaChartMockedData}
              height={300}
              color={theme.palette.primary.main}
              xAxisKey="day"
              yAxisKey="price"
            />
          </ChartDescriptionWrapper>
        </Grid>
      </Grid>
    </Stack>
  );
};

export default DashboardScreen;
