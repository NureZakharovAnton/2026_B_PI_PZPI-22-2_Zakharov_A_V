import { useIntl } from "react-intl";
import messages from "./messages";

const useTranslations = () => {
  const intl = useIntl();

  const translations = {
    formatTitle: (nickname: string) =>
      intl.formatMessage(messages.title, { nickname }),
    description: intl.formatMessage(messages.description),
    averagePriceChartTitle: intl.formatMessage(messages.averagePriceChartTitle),
    categoriesChartTitle: intl.formatMessage(messages.categoriesChartTitle),
    priceDynamicChartTitle: intl.formatMessage(messages.priceDynamicChartTitle),
    averagePriceChartLegendTranslations: {
      price: intl.formatMessage(messages.averagePriceLegendText),
    },
    shopsHeading: intl.formatMessage(messages.shopsHeading),
    productsHeading: intl.formatMessage(messages.productsHeading),
  };

  return translations;
};

export default useTranslations;
