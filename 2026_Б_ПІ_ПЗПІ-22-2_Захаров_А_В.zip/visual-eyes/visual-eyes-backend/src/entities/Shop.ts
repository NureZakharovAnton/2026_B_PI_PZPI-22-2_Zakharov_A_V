import {
  BeforeInsert,
  BeforeUpdate,
  Column,
  Entity,
  ManyToMany,
} from "typeorm";
import { Length, validate } from "class-validator";
import { throwIfShopHas } from "../utils";
import Model from "./Model";
import Product from "./Product";

@Entity("shops")
class Shop extends Model {
  @Column()
  @Length(1, 100)
  public title: string;

  @Column()
  @Length(1, 1000)
  public siteURL: string;

  @Column({ nullable: true })
  @Length(1, 100)
  public imageURL: string;

  @Column({ nullable: true })
  @Length(1, 2000)
  public description: string;

  @ManyToMany(() => Product, (product) => product.shops)
  products: Product[];

  @BeforeInsert()
  @BeforeUpdate()
  async validate() {
    const errors = await validate(this);
    throwIfShopHas(errors);
  }
}

export default Shop;
