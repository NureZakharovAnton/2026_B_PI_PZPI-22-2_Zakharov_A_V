import { AfterLoad, BeforeInsert, BeforeUpdate, Column, Entity } from "typeorm";
import { IsEmail, Length, validate } from "class-validator";
import crypto from "crypto";
import { throwIfUserHas } from "../utils";
import Model from "./Model";

@Entity("users")
class User extends Model {
  @Column({ unique: true })
  @Length(2, 100)
  public nickname: string;

  @Column()
  @IsEmail()
  public email: string;

  @Column({ select: false })
  @Length(8, 100)
  public password: string;

  private temporaryPassword: string;

  @BeforeInsert()
  @BeforeUpdate()
  async validate() {
    const errors = await validate(this);
    throwIfUserHas(errors);
  }

  @AfterLoad()
  private loadTemporaryPassword() {
    this.temporaryPassword = this.password;
  }

  @BeforeInsert()
  private encryptPasswordOnInsert() {
    this.encryptUserPassword();
  }

  @BeforeUpdate()
  private encryptedPasswordOnUpdate() {
    this.encryptPasswordIfChanged();
  }

  private encryptPasswordIfChanged() {
    if (this.checkIsPasswordChanged()) {
      this.encryptUserPassword();
    }
  }

  private checkIsPasswordChanged() {
    return this.temporaryPassword !== this.password;
  }

  public encryptUserPassword() {
    this.password = User.encryptPassword(this.password);
  }

  public static encryptPassword(password: string) {
    const md5 = crypto.createHash("md5");
    return md5.update(password).digest("hex");
  }
}

export default User;
