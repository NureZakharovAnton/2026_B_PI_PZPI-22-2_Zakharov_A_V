import {
  BeforeInsert,
  BeforeUpdate,
  Column,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
} from "typeorm";
import { Length, Min, validate } from "class-validator";
import { slugify, throwIfProductHas } from "../utils";
import {
  MAX_DESCRIPTION_LENGTH,
  MAX_TITLE_LENGTH,
  MAX_URL_LENGTH,
  MIN_PRICE,
  MIN_STRING_LENGTH,
  PRICE_PRECISION,
  PRICE_SCALE,
  PRICE_TYPE,
} from "../configs";
import Model from "./Model";
import Category from "./Category";
import Shop from "./Shop";

@Entity("products")
class Product extends Model {
  @Column()
  @Length(MIN_STRING_LENGTH, MAX_TITLE_LENGTH)
  public title: string;

  @Column({ nullable: true })
  @Length(MIN_STRING_LENGTH, MAX_URL_LENGTH)
  public imageURL: string;

  @Column({ nullable: true, length: MAX_DESCRIPTION_LENGTH })
  public description: string;

  @Column({ scale: PRICE_SCALE, precision: PRICE_PRECISION, type: PRICE_TYPE })
  @Min(MIN_PRICE)
  public price: number;

  @Column({ length: MIN_STRING_LENGTH, unique: true })
  public slug: string;

  @ManyToOne(() => Category, (category) => category.products)
  @JoinColumn({ name: "category_id" })
  category: Category;

  @Column({ name: "category_id" })
  categoryId: string;

  @ManyToMany(() => Shop, (shop) => shop.products, { cascade: true })
  @JoinTable({
    name: "shop_products",
    joinColumn: { name: "product_id" },
    inverseJoinColumn: { name: "shop_id" },
  })
  shops: Shop[];

  @BeforeInsert()
  @BeforeUpdate()
  async validate() {
    const errors = await validate(this);
    throwIfProductHas(errors);
  }

  @BeforeInsert()
  @BeforeUpdate()
  setSlug() {
    this.slug = slugify(this.title);
  }
}

export default Product;
