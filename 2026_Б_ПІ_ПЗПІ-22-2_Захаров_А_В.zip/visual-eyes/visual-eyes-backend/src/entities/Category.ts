import { BeforeInsert, BeforeUpdate, Column, Entity, OneToMany } from "typeorm";
import { Length, validate } from "class-validator";
import {
  MAX_DESCRIPTION_LENGTH,
  MAX_TITLE_LENGTH,
  MAX_URL_LENGTH,
  MIN_STRING_LENGTH,
} from "../configs";
import Model from "./Model";
import Product from "./Product";

@Entity("categories")
class Category extends Model {
  @Column()
  @Length(MIN_STRING_LENGTH, MAX_TITLE_LENGTH)
  public title: string;

  @Column()
  @Length(MIN_STRING_LENGTH, MAX_URL_LENGTH)
  public imageURL: string;

  @Column()
  @Length(MIN_STRING_LENGTH, MAX_DESCRIPTION_LENGTH)
  public description: string;

  @OneToMany(() => Product, (product) => product.category)
  public products: Product[];

  @BeforeInsert()
  @BeforeUpdate()
  async validate() {
    const errors = await validate(this);
    console.log(errors);
    // TODO: throwIfCategoryHas(errors);
  }
}

export default Category;
