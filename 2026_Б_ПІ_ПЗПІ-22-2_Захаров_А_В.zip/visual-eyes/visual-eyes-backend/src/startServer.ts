import app from "./app";

const port = process.env.APP_PORT;

const startServer = () => {
  app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
};

export default startServer;
