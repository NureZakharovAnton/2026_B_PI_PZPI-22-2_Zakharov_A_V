class ApiError {
  private _code: number;
  private _name: string;

  constructor(code: number, name: string) {
    this._code = code;
    this._name = name;
  }

  get code(): number {
    return this._code;
  }

  get name(): string {
    return this._name;
  }
}

export default ApiError;
