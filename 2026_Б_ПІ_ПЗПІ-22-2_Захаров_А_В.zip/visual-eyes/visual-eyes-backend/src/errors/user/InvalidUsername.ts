import ApiError from "../ApiError";

class InvalidUsername extends ApiError {
  constructor() {
    super(400, "Invalid username");
  }
}

export default InvalidUsername;
