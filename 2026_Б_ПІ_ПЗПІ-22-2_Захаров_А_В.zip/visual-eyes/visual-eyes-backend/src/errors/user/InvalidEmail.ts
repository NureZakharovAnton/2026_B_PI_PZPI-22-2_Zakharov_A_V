import ApiError from "../ApiError";

class InvalidEmail extends ApiError {
  constructor() {
    super(400, "Invalid email");
  }
}

export default InvalidEmail;
