import ApiError from "../ApiError";

class UnauthorizedUser extends ApiError {
  constructor() {
    super(401, "Unauthorized user");
  }
}

export default UnauthorizedUser;
