import ApiError from "../ApiError";

class InvalidPassword extends ApiError {
  constructor() {
    super(400, "Invalid password");
  }
}

export default InvalidPassword;
