import InternalServer from "./server/InternalServer";
import QueryFailed from "./server/QueryFailed";
import InvalidEmail from "./user/InvalidEmail";
import InvalidPassword from "./user/InvalidPassword";
import InvalidUsername from "./user/InvalidUsername";
import AlreadyExists from "./server/AlreadyExists";
import NotFound from "./server/NotFound";
import UnauthorizedUser from "./user/UnauthorizedUser";
import InvalidTitle from "./shop/InvalidTitle";
import InvalidSiteURL from "./shop/InvalidSiteURL";
import InvalidImageURL from "./shop/InvalidImageURL";
import InvalidDescription from "./shop/InvalidDescription";
import InvalidPrice from "./shop/InvalidPrice";

const Errors = {
  InvalidUsername,
  InvalidEmail,
  InvalidPassword,
  NotFound,
  AlreadyExists,
  InternalServer,
  QueryFailed,
  UnauthorizedUser,
  InvalidTitle,
  InvalidSiteURL,
  InvalidImageURL,
  InvalidDescription,
  InvalidPrice,
};

export default Errors;
