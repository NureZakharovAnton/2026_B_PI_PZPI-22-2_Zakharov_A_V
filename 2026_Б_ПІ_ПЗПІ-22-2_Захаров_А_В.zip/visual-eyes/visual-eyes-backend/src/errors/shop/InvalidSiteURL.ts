import ApiError from "../ApiError";

class InvalidSiteURL extends ApiError {
  constructor() {
    super(400, "Invalid site URL");
  }
}

export default InvalidSiteURL;
