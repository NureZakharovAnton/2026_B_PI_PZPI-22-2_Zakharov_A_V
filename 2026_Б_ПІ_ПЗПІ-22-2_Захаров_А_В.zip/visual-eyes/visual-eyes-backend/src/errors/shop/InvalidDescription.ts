import ApiError from "../ApiError";

class InvalidDescription extends ApiError {
  constructor() {
    super(400, "Invalid description");
  }
}

export default InvalidDescription;
