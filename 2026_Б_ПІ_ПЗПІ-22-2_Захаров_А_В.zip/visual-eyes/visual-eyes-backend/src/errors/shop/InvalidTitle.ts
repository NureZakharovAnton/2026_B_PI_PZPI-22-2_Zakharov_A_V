import ApiError from "../ApiError";

class InvalidTitle extends ApiError {
  constructor() {
    super(400, "Invalid title");
  }
}

export default InvalidTitle;
