import ApiError from "../ApiError";

class InvalidImageURL extends ApiError {
  constructor() {
    super(400, "Invalid image URL");
  }
}

export default InvalidImageURL;
