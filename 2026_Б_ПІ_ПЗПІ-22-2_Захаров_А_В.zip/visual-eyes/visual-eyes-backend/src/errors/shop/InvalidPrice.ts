import ApiError from "../ApiError";

class InvalidPrice extends ApiError {
  constructor() {
    super(400, "Invalid Price");
  }
}

export default InvalidPrice;
