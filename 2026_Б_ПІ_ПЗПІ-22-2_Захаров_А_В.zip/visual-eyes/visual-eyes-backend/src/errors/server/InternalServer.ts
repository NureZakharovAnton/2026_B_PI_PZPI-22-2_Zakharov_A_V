import ApiError from "../ApiError";

class InvalidEmail extends ApiError {
  constructor() {
    super(500, "Internal server error");
  }
}

export default InvalidEmail;
