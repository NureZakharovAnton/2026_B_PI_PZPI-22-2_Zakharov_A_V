import ApiError from "../ApiError";

class AlreadyExists extends ApiError {
  constructor() {
    super(409, "Already exists");
  }
}

export default AlreadyExists;
