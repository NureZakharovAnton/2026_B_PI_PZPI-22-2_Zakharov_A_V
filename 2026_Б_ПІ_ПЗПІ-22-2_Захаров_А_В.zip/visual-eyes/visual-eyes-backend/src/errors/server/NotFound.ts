import ApiError from "../ApiError";

class NotFound extends ApiError {
  constructor() {
    super(404, "Not found");
  }
}

export default NotFound;
