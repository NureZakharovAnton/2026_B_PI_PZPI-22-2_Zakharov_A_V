import ApiError from "../ApiError";

class QueryFailed extends ApiError {
  constructor() {
    super(500, "Query failed");
  }
}

export default QueryFailed;
