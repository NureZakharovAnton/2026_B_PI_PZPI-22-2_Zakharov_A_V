import jwt from "jsonwebtoken";
import Errors from "../errors";

const jwtAuthenticator = (req, res, next) => {
  const token = req.cookies.token;

  jwt.verify(token, process.env.JWT_TOKEN_SECRET, (err, user) => {
    if (err) {
      throw new Errors.UnauthorizedUser();
    }

    req.user = user;

    next();
  });
};

export default jwtAuthenticator;
