import { NextFunction, Response, Request } from "express";
import { QueryFailedError } from "typeorm";
import Errors from "../errors";
import ApiError from "../errors/ApiError";
import copyUsingGetters from "../utils/copyUsingGetters";

const errorHandler = (
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  console.error(err);

  let apiError = err instanceof ApiError ? err : new Errors.InternalServer();

  if (err instanceof QueryFailedError) {
    apiError = new Errors.QueryFailed();
  }

  const serializedError = copyUsingGetters(apiError);
  res.status(serializedError.code).json(serializedError);
};

export default errorHandler;
