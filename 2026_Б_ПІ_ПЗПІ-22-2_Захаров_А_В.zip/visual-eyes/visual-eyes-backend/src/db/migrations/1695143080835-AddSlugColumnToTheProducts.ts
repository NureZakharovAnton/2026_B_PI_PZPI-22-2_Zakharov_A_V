import { MigrationInterface, QueryRunner, TableColumn } from "typeorm";
import { MAX_TITLE_LENGTH } from "../../configs";
import { slugify } from "../../utils";

export class AddSlugColumnToTheProducts1695143080835
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const slugProps = {
      name: "slug",
      type: "varchar",
      length: MAX_TITLE_LENGTH.toString(),
    };

    const nullableSlugColumn = new TableColumn({
      ...slugProps,
      isNullable: true,
    });

    await queryRunner.addColumn("products", nullableSlugColumn);

    const rows = (await queryRunner.query(
      `SELECT id, title FROM products`
    )) as { id: string; title: string }[];

    for (const row of rows) {
      await queryRunner.query(`UPDATE products SET slug = $1 WHERE id = $2`, [
        slugify(row.title),
        row.id,
      ]);
    }

    const nonNullableSlugColumn = new TableColumn({
      ...slugProps,
      isNullable: false,
    });

    await queryRunner.changeColumn("products", "slug", nonNullableSlugColumn);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn("products", "slug");
  }
}
