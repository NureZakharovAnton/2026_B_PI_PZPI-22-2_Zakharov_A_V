import { MigrationInterface, QueryRunner, Table } from "typeorm";

export class AddShopTable1691857135704 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const shopsTable = new Table({
      name: "shops",
      columns: [
        {
          name: "id",
          type: "uuid",
          isPrimary: true,
          isGenerated: true,
          generationStrategy: "uuid",
        },
        {
          name: "title",
          type: "varchar",
          length: "100",
          isNullable: false,
        },
        {
          name: "siteURL",
          type: "varchar",
          length: "1000",
          isNullable: false,
        },
        {
          name: "imageURL",
          type: "varchar",
          length: "1000",
          isNullable: true,
        },
        {
          name: "description",
          type: "varchar",
          length: "2000",
          isNullable: true,
        },
        {
          name: "created_at",
          type: "timestamp",
          default: "now()",
        },
        {
          name: "updated_at",
          type: "timestamp",
          default: "now()",
        },
      ],
    });

    await queryRunner.createTable(shopsTable);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS shops;`);
  }
}
