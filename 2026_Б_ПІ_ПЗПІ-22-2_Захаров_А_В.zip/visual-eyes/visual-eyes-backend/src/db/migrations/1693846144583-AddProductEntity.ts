import { MigrationInterface, QueryRunner, Table } from "typeorm";
import {
  MAX_DESCRIPTION_LENGTH,
  MAX_TITLE_LENGTH,
  MAX_URL_LENGTH,
  PRICE_PRECISION,
  PRICE_SCALE,
  PRICE_TYPE,
} from "../../configs";

export class AddProductEntity1693846144583 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const productsTable = new Table({
      name: "products",
      columns: [
        {
          name: "id",
          type: "uuid",
          isPrimary: true,
          isGenerated: true,
          generationStrategy: "uuid",
        },
        {
          name: "title",
          type: "varchar",
          length: MAX_TITLE_LENGTH.toString(),
          isNullable: false,
        },
        {
          name: "imageURL",
          type: "varchar",
          length: MAX_URL_LENGTH.toString(),
          isNullable: true,
        },
        {
          name: "description",
          type: "varchar",
          length: MAX_DESCRIPTION_LENGTH.toString(),
          isNullable: true,
        },
        {
          name: "price",
          type: PRICE_TYPE,
          isNullable: false,
          precision: PRICE_PRECISION,
          scale: PRICE_SCALE,
        },
        {
          name: "created_at",
          type: "timestamp",
          default: "now()",
        },
        {
          name: "updated_at",
          type: "timestamp",
          default: "now()",
        },
      ],
    });

    await queryRunner.createTable(productsTable);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS products;`);
  }
}
