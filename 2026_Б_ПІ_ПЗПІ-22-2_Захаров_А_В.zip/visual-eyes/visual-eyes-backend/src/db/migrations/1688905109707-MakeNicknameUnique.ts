import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeNicknameUnique1688905109707 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE users ADD CONSTRAINT unique_column_name UNIQUE (nickname)`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE users DROP CONSTRAINT unique_column_name`
    );
  }
}
