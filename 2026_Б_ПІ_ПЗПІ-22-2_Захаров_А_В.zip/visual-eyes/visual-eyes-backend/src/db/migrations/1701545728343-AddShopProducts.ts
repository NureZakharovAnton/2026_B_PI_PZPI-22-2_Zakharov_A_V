import { MigrationInterface, QueryRunner, Table } from "typeorm";

export class AddShopProducts1701545728343 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const shopProductsTable = new Table({
      name: "shop_products",
      columns: [
        {
          name: "id",
          type: "uuid",
          isPrimary: true,
          isGenerated: true,
          generationStrategy: "uuid",
        },
        {
          name: "shop_id",
          type: "uuid",
          isNullable: false,
        },
        {
          name: "product_id",
          type: "uuid",
          isNullable: false,
        },
        {
          name: "created_at",
          type: "timestamp",
          default: "CURRENT_TIMESTAMP",
        },
        {
          name: "updated_at",
          type: "timestamp",
          default: "CURRENT_TIMESTAMP",
        },
      ],
      foreignKeys: [
        {
          columnNames: ["shop_id"],
          referencedTableName: "shops",
          referencedColumnNames: ["id"],
          onDelete: "CASCADE",
        },
        {
          columnNames: ["product_id"],
          referencedTableName: "products",
          referencedColumnNames: ["id"],
          onDelete: "CASCADE",
        },
      ],
    });

    await queryRunner.createTable(shopProductsTable);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable("shop_products");
  }
}
