import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableColumn,
  TableForeignKey,
} from "typeorm";
import {
  MAX_DESCRIPTION_LENGTH,
  MAX_TITLE_LENGTH,
  MAX_URL_LENGTH,
} from "../../configs";

export class AddCategoryEntity1701362323653 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const categoriesTable = new Table({
      name: "categories",
      columns: [
        {
          name: "id",
          type: "uuid",
          isPrimary: true,
          isGenerated: true,
          generationStrategy: "uuid",
        },
        {
          name: "title",
          type: "varchar",
          length: MAX_TITLE_LENGTH.toString(),
          isNullable: false,
        },
        {
          name: "imageURL",
          type: "varchar",
          length: MAX_URL_LENGTH.toString(),
          isNullable: true,
        },
        {
          name: "description",
          type: "varchar",
          length: MAX_DESCRIPTION_LENGTH.toString(),
          isNullable: true,
        },
        {
          name: "created_at",
          type: "timestamp",
          default: "now()",
        },
        {
          name: "updated_at",
          type: "timestamp",
          default: "now()",
        },
      ],
    });

    await queryRunner.createTable(categoriesTable);

    const categoryIdColumn = new TableColumn({
      name: "category_id",
      type: "uuid",
      isNullable: true,
    });

    await queryRunner.addColumn("products", categoryIdColumn);

    const categoryIdForeignKey = new TableForeignKey({
      referencedTableName: "categories",
      referencedColumnNames: ["id"],
      columnNames: ["category_id"],
      onDelete: "SET NULL",
    });

    await queryRunner.createForeignKey("products", categoryIdForeignKey);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const productsTable = await queryRunner.getTable("products");
    const foreignKey = productsTable.foreignKeys.find(
      (fk) => fk.columnNames.indexOf("category_id") !== -1
    );

    await queryRunner.dropForeignKey("products", foreignKey);
    await queryRunner.dropColumn("products", "category_id");

    await queryRunner.dropTable("categories");
  }
}
