import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeEmailUnique1689442810244 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE users ADD CONSTRAINT unique_column_email UNIQUE (email)`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE users DROP CONSTRAINT unique_column_email`
    );
  }
}
