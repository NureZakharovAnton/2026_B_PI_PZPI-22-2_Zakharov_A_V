import { DataSource } from "typeorm";
import "../configs/dotenvConfig";

const { DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, DB_PORT } = process.env;

const db = new DataSource({
  type: "postgres",
  host: DB_HOST,
  username: DB_USER,
  password: DB_PASSWORD,
  port: +DB_PORT,
  database: DB_NAME,
  entities: [`${__dirname}/../entities/*.{ts,js}`],
  migrations: [`${__dirname}/../db/migrations/*.{ts,js}`],
});

db.initialize()
  .then(() => {
    console.log(`Database is running on ${DB_HOST}:${DB_PORT}`);
  })
  .catch((err) => {
    console.log("Error during launching the database", err);
  });

export default db;
