import db from "../db";
import { User } from "../entities";
import Errors from "../errors";

class UserController {
  static async usersList(req, res) {
    const userRepo = db.getRepository(User);
    const users = await userRepo.find();

    res.json(users);
  }

  static async userDetail(req, res) {
    const userRepo = db.getRepository(User);
    const user = await userRepo.findOneBy({ id: req.params.id });

    if (!user) {
      throw new Errors.NotFound();
    }

    res.json(user);
  }

  static async userCreate(req, res) {
    const requestBody: User = req.body;
    const userRepo = db.getRepository(User);

    const user = await userRepo.create(requestBody);

    const result = await userRepo.save(user);
    delete result.password;

    res.send(result);
  }

  static async userUpdate(req, res) {
    const userRepo = db.getRepository(User);

    const user = await userRepo.findOneBy({ id: req.params.id });

    if (!user) {
      throw new Errors.NotFound();
    }

    userRepo.merge(user, req.body);
    const results = await userRepo.save(user);

    return res.send(results);
  }

  static async userDelete(req, res) {
    const userRepo = db.getRepository(User);
    const isExist = await userRepo.exist({ where: { id: req.params.id } });

    if (!isExist) {
      throw new Errors.NotFound();
    }

    const result = await userRepo.delete(req.params.id);
    return res.send(result);
  }
}

export default UserController;
