import jwt from "jsonwebtoken";
import { User } from "../entities";
import db from "../db";
import Errors from "../errors";
import { signConfig } from "../configs";

class AuthController {
  static async register(req, res) {
    const body: User = req.body;
    const userRepo = db.getRepository(User);

    const isUserExist = await userRepo.exist({
      where: [{ email: body.email }, { nickname: body.nickname }],
    });

    if (isUserExist) {
      throw new Errors.AlreadyExists();
    }

    const createdUser = userRepo.create(body);
    const savedUser = await userRepo.save(createdUser);

    const token = jwt.sign(
      { id: savedUser.id },
      process.env.JWT_TOKEN_SECRET,
      signConfig
    );

    delete savedUser.password;

    res.json({ user: savedUser, token });
  }

  static async login(req, res) {
    const userRepo = db.getRepository(User);

    const encryptedPassword = User.encryptPassword(req.body.password);
    const user = await userRepo.findOne({
      where: { email: req.body.email, password: encryptedPassword },
    });

    if (!user) {
      throw new Errors.NotFound();
    }

    const token = jwt.sign(
      { id: user.id },
      process.env.JWT_TOKEN_SECRET,
      signConfig
    );

    res.json({ user, token });
  }
}

export default AuthController;
