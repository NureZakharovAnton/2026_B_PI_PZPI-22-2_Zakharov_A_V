import { FindManyOptions, Like } from "typeorm";
import db from "../db";
import { Shop } from "../entities";
import Errors from "../errors";

class ShopController {
  static async shopsList(req, res) {
    const repo = db.getRepository(Shop);

    const title = req.query.searchValue || "";
    const sortBy = req.query.sortBy || "";

    const filters: FindManyOptions<Shop> = { where: {} };

    if (title) {
      filters.where["title"] = Like(`${title}%`);
    }

    if (sortBy) {
      filters.order = { title: sortBy };
    }

    const shops = await repo.find(filters);

    res.json(shops);
  }

  static async shopDetails(req, res) {
    const repo = db.getRepository(Shop);
    const shop = await repo.findOneBy({ id: req.params.id });

    if (!shop) {
      throw new Errors.NotFound();
    }

    res.json(shop);
  }

  static async shopCreate(req, res) {
    const requestBody: Shop = req.body;
    const repo = db.getRepository(Shop);

    const shop = await repo.create(requestBody);

    const result = await repo.save(shop);

    res.send(result);
  }

  static async shopUpdate(req, res) {
    const repo = db.getRepository(Shop);

    const shop = await repo.findOneBy({ id: req.params.id });

    const requestBody: Shop = req.body;
    const editedShop = repo.create(requestBody);

    if (!shop) {
      repo.save(editedShop);
      return res.send(editedShop);
    }

    repo.merge(shop, req.body);
    const results = await repo.save(shop);

    return res.send(results);
  }

  static async shopDelete(req, res) {
    const repo = db.getRepository(Shop);
    const isExist = await repo.exist({ where: { id: req.params.id } });

    if (!isExist) {
      throw new Errors.NotFound();
    }

    const result = await repo.delete(req.params.id);
    return res.send(result);
  }
}

export default ShopController;
