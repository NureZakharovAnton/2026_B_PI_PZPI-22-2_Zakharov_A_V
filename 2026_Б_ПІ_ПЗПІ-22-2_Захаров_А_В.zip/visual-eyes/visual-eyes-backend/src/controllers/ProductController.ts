import { Between, FindManyOptions, LessThan, Like, MoreThan } from "typeorm";
import db from "../db";
import { Product } from "../entities";
import Errors from "../errors";

class ProductController {
  static async productsList(req, res) {
    const repo = db.getRepository(Product);

    const title = req.query.searchValue || "";
    const sortBy = req.query.sortBy || "";
    const priceFrom = req.query.priceFrom || undefined;
    const priceTo = req.query.priceTo || undefined;

    const shopsParsed =
      req.query.shops && JSON.parse(decodeURIComponent(req.query.shops));
    const shopsFilter = shopsParsed?.length && shopsParsed;

    const categoriesParsed =
      req.query.categories &&
      JSON.parse(decodeURIComponent(req.query.categories));
    const categoriesFilter = categoriesParsed?.length && categoriesParsed[0];

    const filters: FindManyOptions<Product> = { where: {} };

    if (title) {
      filters.where["title"] = Like(`${title}%`);
    }

    if (priceFrom) {
      filters.where["price"] = MoreThan(priceFrom);
    }

    if (priceTo) {
      filters.where["price"] = LessThan(priceTo);
    }

    if (priceFrom && priceTo) {
      filters.where["price"] = Between(priceFrom, priceTo);
    }

    if (shopsFilter) {
      filters.where["shops"] = shopsFilter;
    }

    if (categoriesFilter) {
      filters.where["category"] = categoriesFilter;
    }

    if (sortBy) {
      filters.order = { title: sortBy };
    }

    const products = await repo.find(filters);
    res.status(200).json(products); // TODO: statuses
  }

  static async productDetails(req, res) {
    const repo = db.getRepository(Product);
    const product = await repo.findOneBy({ slug: req.params.slug });

    if (!product) {
      throw new Errors.NotFound();
    }

    res.json(product);
  }

  static async productCreate(req, res) {
    const requestBody: Product = req.body;
    const repo = db.getRepository(Product);

    const product = repo.create(requestBody);
    const result = await repo.save(product);

    res.send(result);
  }

  static async productUpdate(req, res) {
    const repo = db.getRepository(Product);

    const product = await repo.findOneBy({ id: req.params.id });

    const requestBody: Product = req.body;
    const editedProduct = repo.create(requestBody);

    if (!product) {
      repo.save(editedProduct);
      return res.send(editedProduct);
    }

    repo.merge(product, editedProduct);
    const result = await repo.save(product);

    return res.send(result);
  }

  static async productDelete(req, res) {
    const repo = db.getRepository(Product);
    const isExist = await repo.exist({ where: { id: req.params.id } });

    if (!isExist) {
      throw new Errors.NotFound();
    }

    const result = await repo.delete(req.params.id);
    return res.send(result);
  }
}

export default ProductController;
