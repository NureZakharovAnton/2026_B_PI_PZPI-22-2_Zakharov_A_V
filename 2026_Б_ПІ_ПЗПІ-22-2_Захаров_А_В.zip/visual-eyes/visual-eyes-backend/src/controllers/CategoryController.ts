import { FindManyOptions, Like } from "typeorm";
import Category from "../entities/Category";
import db from "../db";
import Errors from "../errors";

class CategoryController {
  static async categoriesListByFilter(req, res) {
    const repo = db.getRepository(Category);

    const title = req.query.searchValue || "";
    const sortBy = req.query.sortBy || "";

    const filters: FindManyOptions<Category> = { where: {} };

    if (title) {
      filters.where["title"] = Like(`${title}%`);
    }

    if (sortBy) {
      filters.order = { title: sortBy };
    }

    const categories = await repo.find(filters);
    res.status(200).json(categories); // TODO: statuses
  }

  static async categoryDetails(req, res) {
    const repo = db.getRepository(Category);
    const category = await repo.findOneBy({ id: req.params.id });

    if (!category) {
      throw new Errors.NotFound();
    }

    res.json(category);
  }

  static async categoryCreate(req, res) {
    const requestBody: Category = req.body;
    const repo = db.getRepository(Category);

    const category = repo.create(requestBody);
    const result = await repo.save(category);

    res.status(200).json(result);
  }

  static async categoryUpdate(req, res) {
    const repo = db.getRepository(Category);

    const category = await repo.findOneBy({ id: req.params.id });

    const requestBody: Category = req.body;
    const editedCategory = repo.create(requestBody);

    console.log(editedCategory);

    if (!category) {
      // throw new Errors.NotFound();
      repo.save(editedCategory);  // TODO: remove saving
      return res.json(editedCategory);
    }

    repo.merge(category, editedCategory);
    const result = await repo.save(category);

    return res.status(200).json(result);
  }

  static async categoryDelete(req, res) {
    const repo = db.getRepository(Category);
    const isExist = await repo.exist({ where: { id: req.params.id } });

    if (!isExist) {
      throw new Errors.NotFound();
    }

    const result = await repo.delete(req.params.id);
    return res.status(200).json(result);
  }
}

export default CategoryController;
