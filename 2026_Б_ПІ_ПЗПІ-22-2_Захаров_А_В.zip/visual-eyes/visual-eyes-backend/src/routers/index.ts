export { default as usersRouter } from "./usersRouter";
export { default as authRouter } from "./authRouter";
export { default as shopsRouter } from "./shopsRouter";
export { default as productsRouter } from "./productsRouter";
export { default as categoriesRouter } from "./categoriesRouter";
