import express from "express";
import { ShopController } from "../controllers";
import { tryCatch } from "../utils";

const shopsRouter = express.Router();

shopsRouter.get("/", tryCatch(ShopController.shopsList));
shopsRouter.get("/:id", tryCatch(ShopController.shopDetails));
shopsRouter.post("/", tryCatch(ShopController.shopCreate));
shopsRouter.put("/:id", tryCatch(ShopController.shopUpdate));
shopsRouter.delete("/:id", tryCatch(ShopController.shopDelete));

export default shopsRouter;
