import express from "express";
import { AuthController } from "../controllers";
import { tryCatch } from "../utils";

const authRouter = express.Router();

authRouter.post("/register", tryCatch(AuthController.register));
authRouter.post("/login", tryCatch(AuthController.login));

export default authRouter;
