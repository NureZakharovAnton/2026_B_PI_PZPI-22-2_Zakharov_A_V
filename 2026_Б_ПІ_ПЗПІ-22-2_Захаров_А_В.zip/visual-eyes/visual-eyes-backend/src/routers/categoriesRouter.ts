import express from "express";
import { CategoryController } from "../controllers";
import { tryCatch } from "../utils";

const categoriesRouter = express.Router();

categoriesRouter.get("/", tryCatch(CategoryController.categoriesListByFilter));
categoriesRouter.get("/:id", tryCatch(CategoryController.categoryDetails));
categoriesRouter.post("/", tryCatch(CategoryController.categoryCreate));
categoriesRouter.put("/:id", tryCatch(CategoryController.categoryUpdate));
categoriesRouter.delete("/:id", tryCatch(CategoryController.categoryDelete));

export default categoriesRouter;
