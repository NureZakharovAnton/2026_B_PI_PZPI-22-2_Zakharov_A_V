import express from "express";
import { ProductController } from "../controllers";
import { tryCatch } from "../utils";

const productsRouter = express.Router();

productsRouter.get("/", tryCatch(ProductController.productsList));
productsRouter.get("/:slug", tryCatch(ProductController.productDetails));
productsRouter.post("/", tryCatch(ProductController.productCreate));
productsRouter.put("/:id", tryCatch(ProductController.productUpdate));
productsRouter.delete("/:id", tryCatch(ProductController.productDelete));

export default productsRouter;
