import express from "express";
import { UserController } from "../controllers";
import { tryCatch } from "../utils";

const userRouter = express.Router();

userRouter.get("/", tryCatch(UserController.usersList));
userRouter.get("/:id", tryCatch(UserController.userDetail));
userRouter.post("/", tryCatch(UserController.userCreate));
userRouter.put("/:id", tryCatch(UserController.userUpdate));
userRouter.delete("/:id", tryCatch(UserController.userDelete));

export default userRouter;
