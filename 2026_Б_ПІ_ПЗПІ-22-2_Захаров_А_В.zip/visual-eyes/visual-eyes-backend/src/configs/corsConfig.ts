import { CorsOptions } from "cors";

export const ALLOWED_ORIGINS = ["http://localhost:5173", "http://localhost:4173"];

export const corsConfig: CorsOptions = {
  origin: ALLOWED_ORIGINS,
  credentials: true,
};
