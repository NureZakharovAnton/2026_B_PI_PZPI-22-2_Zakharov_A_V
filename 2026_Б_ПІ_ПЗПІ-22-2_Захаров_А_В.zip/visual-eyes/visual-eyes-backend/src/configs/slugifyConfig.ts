export const slugifyConfig = {
  lower: true,
};
