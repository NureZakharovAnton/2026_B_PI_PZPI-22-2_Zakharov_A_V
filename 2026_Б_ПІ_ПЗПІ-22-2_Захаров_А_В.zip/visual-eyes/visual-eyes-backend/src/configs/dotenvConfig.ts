import dotenv from "dotenv";

const envPathMapper = {
  development: ".env.development",
  production: ".env.production",
  test: ".env.test",
};

const envPath = envPathMapper[process.env.NODE_ENV || "development"];
const dotenvConfig = dotenv.config({ path: envPath });

export default dotenvConfig;
