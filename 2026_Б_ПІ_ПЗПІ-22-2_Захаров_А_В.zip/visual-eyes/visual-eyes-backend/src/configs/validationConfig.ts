export const MIN_STRING_LENGTH = 1;
export const MAX_TITLE_LENGTH = 100;
export const MAX_DESCRIPTION_LENGTH = 1000;
export const MAX_URL_LENGTH = 10000;
export const MIN_PRICE = 0;
export const PRICE_SCALE = 2;
export const PRICE_PRECISION = 10;
export const PRICE_TYPE = "numeric";
