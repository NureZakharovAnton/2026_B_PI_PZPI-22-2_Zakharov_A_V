import { SignOptions } from "jsonwebtoken";

export const EXPIRES_IN = "30d";

export const signConfig: SignOptions = {
  expiresIn: EXPIRES_IN,
};
