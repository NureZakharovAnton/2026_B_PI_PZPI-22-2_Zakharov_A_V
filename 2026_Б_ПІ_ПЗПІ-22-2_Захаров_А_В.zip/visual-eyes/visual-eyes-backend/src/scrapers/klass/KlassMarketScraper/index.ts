import MarketScraper from "../../MarketScraper";
import SalesPageScraper from "../SalesPageScraper";

class KlassMarketScraper extends MarketScraper {
  public static async scrapSalesPageToDB() {
    const salesPageScraper = new SalesPageScraper();
    await salesPageScraper.scrap();
  }
}

export default KlassMarketScraper;
