import { ElementHandle } from "puppeteer";
import db from "../../../db";
import { Product } from "../../../entities";
import PageScraper from "../../PageScraper";

// TODO: fix 'this' issue
const shopId: string = "19d55541-5330-4df6-8743-1dd222802a11";

class SalesPageScraper extends PageScraper {
  public async scrap() {
    await this.initializePage();

    await this.navigateToScrapedPage();
    await this.scrapAllItemsWithPagination();

    await this.closeBrowser();
  }

  private async navigateToScrapedPage() {
    await this.page.goto(
      "https://klassmarket.ua/ru/aktsii/katalog-aktsionnykh-tovarov",
      { waitUntil: "networkidle2" }
    );
  }

  private async scrapAllItemsWithPagination() {
    let nextPageLink = await this.getNextPageLink();
    let currentPageLink = this.getCurrentPageURL();
    let hasItemsToScrap = true;

    while (hasItemsToScrap) {
      const itemHandles = await this.getItemHandles();
      const itemSavePromises = itemHandles.map(this.scrapAndSaveItem);

      await Promise.all(itemSavePromises);

      if (!nextPageLink) break;
      await this.page.goto(nextPageLink, { waitUntil: "networkidle2" });

      currentPageLink = nextPageLink;
      hasItemsToScrap = !!currentPageLink;

      nextPageLink = await this.getNextPageLink();
    }
  }

  private async getNextPageLink() {
    let nextPageLinkHandle = await this.page.$(".pagination__item--next > a");
    let nextPageLink = await nextPageLinkHandle?.evaluate((el) =>
      el.getAttribute("href")
    );

    return nextPageLink;
  }

  private async getItemHandles() {
    const itemHandles = await this.page.$$(".product-sale");

    return itemHandles;
  }

  private async scrapAndSaveItem(itemHandle: ElementHandle<Element>) {
    const titleHandle = await itemHandle.$(".product-ten__name");
    const title = await titleHandle.evaluate(
      (titleElement) => titleElement.textContent
    );

    const priceHandle = await itemHandle.$(".product-price-old__current");
    const price = await priceHandle.evaluate(
      (priceElement) => +priceElement.textContent
    );

    const imageHandle = await itemHandle.$(".product-ten__image > img");
    const imageURL = await imageHandle.evaluate((imageElement) =>
      imageElement.getAttribute("src")
    );

    const productRepo = db.getRepository(Product);

    const product = productRepo.create({
      title,
      price,
      imageURL,
      description: null,
      shops: [{ id: shopId }],
    });

    const isExist = await productRepo.exist({
      where: { title, price, imageURL }, // TODO: scrap if no info once per day
    });
    if (isExist) return;

    await productRepo.save(product);
  }
}

export default SalesPageScraper;
