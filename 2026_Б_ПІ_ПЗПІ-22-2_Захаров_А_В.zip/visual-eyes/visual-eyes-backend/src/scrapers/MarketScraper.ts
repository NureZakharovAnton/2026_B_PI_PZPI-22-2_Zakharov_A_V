class MarketScraper {

}

export default MarketScraper;
