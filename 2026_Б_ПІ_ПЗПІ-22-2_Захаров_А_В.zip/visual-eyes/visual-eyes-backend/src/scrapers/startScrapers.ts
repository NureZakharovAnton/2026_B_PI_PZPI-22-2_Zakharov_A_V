import KlassMarketScraper from "./klass/KlassMarketScraper";

const DAY_MILLIS = 1000 * 60 * 60 * 24;

const startScrapers = () => {
  setInterval(() => {
    try {
      KlassMarketScraper.scrapSalesPageToDB();
    } catch (error) {
      console.log("Error while scraping data!");
      console.log(error);
    }
  }, DAY_MILLIS);
};

export default startScrapers;
