import { Browser, Page } from "puppeteer";
import launchBrowser from "./launchBrowser";

abstract class PageScraper {
  private browser: Browser;
  protected page: Page;

  abstract scrap(): Promise<void>;

  protected async initializePage() {
    this.browser = await launchBrowser();
    this.page = await this.browser.newPage();
  }

  protected async closeBrowser() {
    this.browser.close();
  }

  protected getCurrentPageURL() {
    return this.page.url();
  }
}

export default PageScraper;
