import puppeteer from "puppeteer";

const browser = puppeteer.launch({ headless: 'new' });

const launchBrowser = async () => {
  return await browser;
};

export default launchBrowser;
