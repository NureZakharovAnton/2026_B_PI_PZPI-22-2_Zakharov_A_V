import { ValidationError } from "class-validator";
import Errors from "../errors";

const propertiesErrorsMapper = {
  title: Errors.InvalidTitle,
  siteURL: Errors.InvalidSiteURL,
  imageURL: Errors.InvalidImageURL,
  description: Errors.InvalidDescription,
};

const throwIfShopHas = (errors: ValidationError[]) => {
  if (errors.length === 0) return;

  const { property } = errors[0];

  const responseError = propertiesErrorsMapper[property];
  throw new responseError();
};

export default throwIfShopHas;
