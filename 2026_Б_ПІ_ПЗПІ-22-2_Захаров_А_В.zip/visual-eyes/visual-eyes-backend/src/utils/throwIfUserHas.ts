import { ValidationError } from "class-validator";
import Errors from "../errors";

const propertiesErrorsMapper = {
  nickname: Errors.InvalidUsername,
  email: Errors.InvalidEmail,
  password: Errors.InvalidPassword,
};

const throwIfUserHas = (errors: ValidationError[]) => {
  if (errors.length === 0) return;

  const { property } = errors[0];

  const responseError = propertiesErrorsMapper[property];
  throw new responseError();
};

export default throwIfUserHas;
