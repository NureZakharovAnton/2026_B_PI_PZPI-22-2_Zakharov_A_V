const copyPrivatesUsingGetters = (obj: Record<string, any>): typeof obj => {
  const copy = {};

  for (const key in obj) {
    if (key.startsWith("_")) {
      const hasGetter = obj[key.slice(1)];

      if (hasGetter) {
        copy[key.slice(1)] = obj[key];
      }
    } else {
      copy[key] = obj[key];
    }
  }

  return copy;
};

export default copyPrivatesUsingGetters;
