import slugifyBase from "slugify";
import { slugifyConfig } from "../configs";

const slugify = (title: string) => {
  return slugifyBase(title, slugifyConfig);
};

export default slugify;
