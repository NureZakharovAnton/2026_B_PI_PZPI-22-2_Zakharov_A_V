import startScrapers from "./scrapers/startScrapers";
import startServer from "./startServer";

startServer();
startScrapers();
