import express from "express";
import "reflect-metadata";
import cors from "cors";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import "./configs/dotenvConfig";
import {
  authRouter,
  categoriesRouter,
  usersRouter,
  shopsRouter,
  productsRouter,
} from "./routers";
import { errorHandler, jwtAuthenticator } from "./middleware";
import { corsConfig } from "./configs";

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors(corsConfig));
app.use(cookieParser());
app.use(morgan("dev")); // TODO: setup morgan

app.use("/api/v1/auth", authRouter);
app.use("/", jwtAuthenticator);

app.use("/api/v1/users", usersRouter);
app.use("/api/v1/shops", shopsRouter);
app.use("/api/v1/products", productsRouter);
app.use("/api/v1/categories", categoriesRouter);

app.use(errorHandler);

export default app;
