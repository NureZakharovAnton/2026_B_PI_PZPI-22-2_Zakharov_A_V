import { describe, test, expect } from "@jest/globals";
import { ValidationError } from "class-validator";
import throwIfUserHas from "../../../src/utils/throwIfUserHas";
import Errors from "../../../src/errors";

const createValidationError = (property: string): ValidationError => {
  const error = new ValidationError();
  error.property = property;
  return error;
};

describe("throwIfUserHas", () => {
  test("should not throw when errors array is empty", () => {
    expect(() => throwIfUserHas([])).not.toThrow();
  });

  const errorCases = [
    { property: "nickname", ErrorClass: Errors.InvalidUsername },
    { property: "email", ErrorClass: Errors.InvalidEmail },
    { property: "password", ErrorClass: Errors.InvalidPassword },
  ];

  test.each(errorCases)(
    "should throw $ErrorClass.name for invalid $property",
    ({ property, ErrorClass }) => {
      const errors = [createValidationError(property)];

      expect(() => throwIfUserHas(errors)).toThrow(ErrorClass);
    }
  );
});
