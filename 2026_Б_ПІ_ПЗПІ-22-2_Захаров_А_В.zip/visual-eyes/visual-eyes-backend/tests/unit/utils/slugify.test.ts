import { describe, test, expect } from "@jest/globals";
import slugify from "../../../src/utils/slugify";

describe("slugify", () => {
  const testCases = [
    { input: "Hello World", expected: "hello-world" },
    { input: "Test Product 123", expected: "test-product-123" },
    { input: "Test@#$%123", expected: "test@dollarpercent123" },
    { input: "Multiple   Spaces", expected: "multiple-spaces" },
    { input: "UPPERCASE TITLE", expected: "uppercase-title" },
  ];

  test.each(testCases)(
    'should convert "$input" to "$expected"',
    ({ input, expected }) => {
      expect(slugify(input)).toBe(expected);
    }
  );
});
