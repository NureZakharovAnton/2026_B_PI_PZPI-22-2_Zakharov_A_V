import { describe, test, expect } from "@jest/globals";
import copyUsingGetters from "../../../src/utils/copyUsingGetters";
import ApiError from "../../../src/errors/ApiError";

describe("copyUsingGetters", () => {
  test("should copy plain object properties", () => {
    const source = { name: "test", value: 42 };

    const result = copyUsingGetters(source);

    expect(result).toEqual({ name: "test", value: 42 });
  });

  test("should expose private ApiError fields via getters mapping", () => {
    const error = new ApiError(404, "Not found");

    const result = copyUsingGetters(error);

    expect(result).toEqual(
      expect.objectContaining({
        code: 404,
        name: "Not found",
      })
    );
  });

  const testCases = [
    {
      source: { _code: 400, code: 400, _name: "Bad Request", name: "Bad Request" },
      expected: { code: 400, name: "Bad Request" },
    },
    {
      source: { _id: "1", id: "1", title: "Product" },
      expected: { id: "1", title: "Product" },
    },
  ];

  test.each(testCases)("should map underscore-prefixed keys correctly", ({
    source,
    expected,
  }) => {
    expect(copyUsingGetters(source)).toEqual(expected);
  });
});
