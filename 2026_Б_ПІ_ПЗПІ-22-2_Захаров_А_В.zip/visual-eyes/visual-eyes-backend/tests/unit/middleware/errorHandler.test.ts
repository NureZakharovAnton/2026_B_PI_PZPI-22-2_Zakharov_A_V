import { describe, test, expect, beforeEach, afterEach, jest } from "@jest/globals";
import { Request, Response, NextFunction } from "express";
import { QueryFailedError } from "typeorm";
import errorHandler from "../../../src/middleware/errorHandler";
import Errors from "../../../src/errors";
import {
  createMockRequest,
  createMockResponse,
  createMockNext,
  MockResponse,
} from "../../helpers/mocks/requestResponse";

describe("errorHandler", () => {
  let mockReq: Request;
  let mockRes: MockResponse;
  let mockNext: NextFunction;

  beforeEach(() => {
    jest.spyOn(console, "error").mockImplementation(() => {});

    mockReq = createMockRequest() as Request;
    mockRes = createMockResponse();
    mockNext = createMockNext();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  test("should serialize ApiError with correct status code", () => {
    const error = new Errors.NotFound() as unknown as Error;

    errorHandler(error, mockReq, mockRes as unknown as Response, mockNext);

    expect(mockRes.status).toHaveBeenCalledWith(404);
    expect(mockRes.json).toHaveBeenCalledWith(
      expect.objectContaining({
        code: 404,
        name: "Not found",
      })
    );
  });

  test("should map QueryFailedError to QueryFailed response", () => {
    const queryError = new QueryFailedError(
      "SELECT 1",
      [],
      new Error("db error")
    );

    errorHandler(
      queryError,
      mockReq,
      mockRes as unknown as Response,
      mockNext
    );

    expect(mockRes.status).toHaveBeenCalledWith(500);
    expect(mockRes.json).toHaveBeenCalledWith(
      expect.objectContaining({
        code: 500,
        name: "Query failed",
      })
    );
  });

  test("should map unknown errors to InternalServer response", () => {
    const error = new Error("unexpected");

    errorHandler(error, mockReq, mockRes as unknown as Response, mockNext);

    expect(mockRes.status).toHaveBeenCalledWith(500);
    expect(mockRes.json).toHaveBeenCalledWith(
      expect.objectContaining({
        code: 500,
        name: "Internal server error",
      })
    );
  });
});
