import { describe, test, expect, beforeEach, jest } from "@jest/globals";
import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import jwtAuthenticator from "../../../src/middleware/jwtAuthenticator";
import Errors from "../../../src/errors";
import {
  createMockRequest,
  createMockResponse,
  createMockNext,
  MockResponse,
} from "../../helpers/mocks/requestResponse";

jest.mock("jsonwebtoken", () => ({
  verify: jest.fn(),
}));

type VerifyCallback = (
  error: Error | null,
  decoded?: { id: string } | null
) => void;

describe("jwtAuthenticator", () => {
  let mockReq: Request;
  let mockRes: MockResponse;
  let mockNext: NextFunction;

  beforeEach(() => {
    jest.clearAllMocks();

    mockReq = createMockRequest() as Request;
    mockRes = createMockResponse();
    mockNext = createMockNext();
  });

  test("should attach user to request and call next for valid token", () => {
    const user = { id: "user-1" };
    mockReq.cookies = { token: "valid-token" };

    (jwt.verify as jest.Mock).mockImplementation(
      (_token: string, _secret: string, callback: VerifyCallback) => {
        callback(null, user);
      }
    );

    jwtAuthenticator(mockReq, mockRes as unknown as Response, mockNext);

    expect(jwt.verify).toHaveBeenCalledWith(
      "valid-token",
      process.env.JWT_TOKEN_SECRET,
      expect.any(Function)
    );
    expect((mockReq as Request & { user: { id: string } }).user).toEqual(user);
    expect(mockNext).toHaveBeenCalled();
  });

  test("should throw UnauthorizedUser for invalid token", () => {
    mockReq.cookies = { token: "invalid-token" };

    (jwt.verify as jest.Mock).mockImplementation(
      (_token: string, _secret: string, callback: VerifyCallback) => {
        callback(new Error("invalid token"), null);
      }
    );

    expect(() =>
      jwtAuthenticator(mockReq, mockRes as unknown as Response, mockNext)
    ).toThrow(Errors.UnauthorizedUser);
    expect(mockNext).not.toHaveBeenCalled();
  });

  test("should throw UnauthorizedUser when token is missing", () => {
    (jwt.verify as jest.Mock).mockImplementation(
      (_token: string, _secret: string, callback: VerifyCallback) => {
        callback(new Error("jwt must be provided"), null);
      }
    );

    expect(() =>
      jwtAuthenticator(mockReq, mockRes as unknown as Response, mockNext)
    ).toThrow(Errors.UnauthorizedUser);
  });
});
