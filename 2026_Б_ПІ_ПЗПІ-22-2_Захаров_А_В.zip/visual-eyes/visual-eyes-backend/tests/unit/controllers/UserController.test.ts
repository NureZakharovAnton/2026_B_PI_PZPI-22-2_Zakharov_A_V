import { describe, test, expect, beforeEach, jest } from "@jest/globals";
import UserController from "../../../src/controllers/UserController";
import db from "../../../src/db";
import Errors from "../../../src/errors";
import {
  createMockRepository,
  MockRepository,
} from "../../helpers/mocks/repository";
import {
  createMockRequest,
  createMockResponse,
} from "../../helpers/mocks/requestResponse";
import { createUserFixture } from "../../helpers/fixtures/users";

jest.mock("../../../src/db", () => ({
  __esModule: true,
  default: {
    getRepository: jest.fn(),
  },
}));

describe("UserController", () => {
  let mockUserRepo: MockRepository;
  let mockReq: ReturnType<typeof createMockRequest>;
  let mockRes: ReturnType<typeof createMockResponse>;

  beforeEach(() => {
    jest.clearAllMocks();

    mockUserRepo = createMockRepository();
    (db.getRepository as jest.Mock).mockReturnValue(mockUserRepo);

    mockReq = createMockRequest();
    mockRes = createMockResponse();
  });

  describe("usersList", () => {
    test("should return list of users", async () => {
      const users = [createUserFixture()];
      mockUserRepo.find.mockResolvedValue(users);

      await UserController.usersList(mockReq, mockRes);

      expect(mockUserRepo.find).toHaveBeenCalled();
      expect(mockRes.json).toHaveBeenCalledWith(users);
    });
  });

  describe("userDetail", () => {
    test("should return user by id", async () => {
      const user = createUserFixture();
      mockReq.params = { id: user.id as string };
      mockUserRepo.findOneBy.mockResolvedValue(user);

      await UserController.userDetail(mockReq, mockRes);

      expect(mockUserRepo.findOneBy).toHaveBeenCalledWith({ id: user.id });
      expect(mockRes.json).toHaveBeenCalledWith(user);
    });

    test("should throw NotFound when user does not exist", async () => {
      mockReq.params = { id: "non-existent" };
      mockUserRepo.findOneBy.mockResolvedValue(null);

      await expect(
        UserController.userDetail(mockReq, mockRes)
      ).rejects.toBeInstanceOf(Errors.NotFound);
    });
  });

  describe("userCreate", () => {
    test("should create user and remove password from response", async () => {
      const requestBody = createUserFixture();
      const createdUser = { ...requestBody };
      const savedUser = { ...requestBody, password: "hashed-password" };

      mockReq.body = requestBody;
      mockUserRepo.create.mockReturnValue(createdUser);
      mockUserRepo.save.mockResolvedValue(savedUser);

      await UserController.userCreate(mockReq, mockRes);

      expect(mockUserRepo.create).toHaveBeenCalledWith(requestBody);
      expect(mockUserRepo.save).toHaveBeenCalledWith(createdUser);
      expect(mockRes.send).toHaveBeenCalledWith(
        expect.not.objectContaining({ password: expect.anything() })
      );
    });
  });

  describe("userUpdate", () => {
    test("should update existing user", async () => {
      const user = createUserFixture();
      const updateBody = { nickname: "updated" };
      const updatedUser = { ...user, ...updateBody };

      mockReq.params = { id: user.id as string };
      mockReq.body = updateBody;
      mockUserRepo.findOneBy.mockResolvedValue(user);
      mockUserRepo.save.mockResolvedValue(updatedUser);

      await UserController.userUpdate(mockReq, mockRes);

      expect(mockUserRepo.merge).toHaveBeenCalledWith(user, updateBody);
      expect(mockUserRepo.save).toHaveBeenCalledWith(user);
      expect(mockRes.send).toHaveBeenCalledWith(updatedUser);
    });

    test("should throw NotFound when user does not exist", async () => {
      mockReq.params = { id: "non-existent" };
      mockUserRepo.findOneBy.mockResolvedValue(null);

      await expect(
        UserController.userUpdate(mockReq, mockRes)
      ).rejects.toBeInstanceOf(Errors.NotFound);
    });
  });

  describe("userDelete", () => {
    test("should delete existing user", async () => {
      const userId = "user-1";
      const deleteResult = { affected: 1 };

      mockReq.params = { id: userId };
      mockUserRepo.exist.mockResolvedValue(true);
      mockUserRepo.delete.mockResolvedValue(deleteResult);

      await UserController.userDelete(mockReq, mockRes);

      expect(mockUserRepo.exist).toHaveBeenCalledWith({ where: { id: userId } });
      expect(mockUserRepo.delete).toHaveBeenCalledWith(userId);
      expect(mockRes.send).toHaveBeenCalledWith(deleteResult);
    });

    test("should throw NotFound when user does not exist", async () => {
      mockReq.params = { id: "non-existent" };
      mockUserRepo.exist.mockResolvedValue(false);

      await expect(
        UserController.userDelete(mockReq, mockRes)
      ).rejects.toBeInstanceOf(Errors.NotFound);
    });
  });
});
