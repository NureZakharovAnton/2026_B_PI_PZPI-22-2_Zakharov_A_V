import { describe, test, expect, beforeEach, jest } from "@jest/globals";
import jwt from "jsonwebtoken";
import AuthController from "../../../src/controllers/AuthController";
import db from "../../../src/db";
import Errors from "../../../src/errors";
import { User } from "../../../src/entities";
import {
  createMockRepository,
  MockRepository,
} from "../../helpers/mocks/repository";
import {
  createMockRequest,
  createMockResponse,
} from "../../helpers/mocks/requestResponse";
import { createUserFixture } from "../../helpers/fixtures/users";

jest.mock("../../../src/db", () => ({
  __esModule: true,
  default: {
    getRepository: jest.fn(),
  },
}));

jest.mock("jsonwebtoken", () => ({
  sign: jest.fn(),
}));

describe("AuthController", () => {
  let mockUserRepo: MockRepository;
  let mockReq: ReturnType<typeof createMockRequest>;
  let mockRes: ReturnType<typeof createMockResponse>;

  beforeEach(() => {
    jest.clearAllMocks();

    mockUserRepo = createMockRepository();
    (db.getRepository as jest.Mock).mockReturnValue(mockUserRepo);

    mockReq = createMockRequest();
    mockRes = createMockResponse();
  });

  describe("register", () => {
    test("should register new user and return token", async () => {
      const body = createUserFixture();
      const savedUser = { ...body, password: "hashed-password" };
      const token = "jwt-token";

      mockReq.body = body;
      mockUserRepo.exist.mockResolvedValue(false);
      mockUserRepo.create.mockReturnValue(body);
      mockUserRepo.save.mockResolvedValue(savedUser);
      (jwt.sign as jest.Mock).mockReturnValue(token);

      await AuthController.register(mockReq, mockRes);

      expect(mockUserRepo.exist).toHaveBeenCalledWith({
        where: [{ email: body.email }, { nickname: body.nickname }],
      });
      expect(jwt.sign).toHaveBeenCalledWith(
        { id: savedUser.id },
        process.env.JWT_TOKEN_SECRET,
        expect.any(Object)
      );
      expect(mockRes.json).toHaveBeenCalledWith({
        user: expect.not.objectContaining({ password: expect.anything() }),
        token,
      });
    });

    test("should throw AlreadyExists when user already exists", async () => {
      mockReq.body = createUserFixture();
      mockUserRepo.exist.mockResolvedValue(true);

      await expect(
        AuthController.register(mockReq, mockRes)
      ).rejects.toBeInstanceOf(Errors.AlreadyExists);
    });
  });

  describe("login", () => {
    test("should login user with valid credentials", async () => {
      const body = {
        email: "test@example.com",
        password: "qweqweqwe123",
      };
      const user = createUserFixture(body);
      const token = "jwt-token";
      const encryptedPassword = User.encryptPassword(body.password);

      mockReq.body = body;
      mockUserRepo.findOne.mockResolvedValue(user);
      (jwt.sign as jest.Mock).mockReturnValue(token);

      await AuthController.login(mockReq, mockRes);

      expect(mockUserRepo.findOne).toHaveBeenCalledWith({
        where: { email: body.email, password: encryptedPassword },
      });
      expect(mockRes.json).toHaveBeenCalledWith({ user, token });
    });

    test("should throw NotFound when credentials are invalid", async () => {
      mockReq.body = {
        email: "test@example.com",
        password: "wrong-password",
      };
      mockUserRepo.findOne.mockResolvedValue(null);

      await expect(
        AuthController.login(mockReq, mockRes)
      ).rejects.toBeInstanceOf(Errors.NotFound);
    });
  });
});
