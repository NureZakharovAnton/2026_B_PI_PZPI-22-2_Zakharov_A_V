import { describe, test, expect } from "@jest/globals";
import User from "../../../src/entities/User";

describe("User entity methods", () => {
  describe("encryptPassword", () => {
    test("should return md5 hash for password", () => {
      const password = "qweqweqwe123";
      const hash = User.encryptPassword(password);

      expect(hash).toMatch(/^[a-f0-9]{32}$/);
      expect(hash).toBe("440655d6d98f244c507d27576a9209c5");
    });

    test.each([
      { password: "password123", expected: "482c811da5d5b4bc6d497ffa98491e38" },
      { password: "qweqweqwe123", expected: "440655d6d98f244c507d27576a9209c5" },
    ])(
      "should consistently hash password $password",
      ({ password, expected }) => {
        expect(User.encryptPassword(password)).toBe(expected);
      }
    );

    test("should produce different hashes for different passwords", () => {
      const hash1 = User.encryptPassword("password-one");
      const hash2 = User.encryptPassword("password-two");

      expect(hash1).not.toBe(hash2);
    });

    test("should produce same hash for same password input", () => {
      const password = "same-password";

      expect(User.encryptPassword(password)).toBe(
        User.encryptPassword(password)
      );
    });
  });
});
