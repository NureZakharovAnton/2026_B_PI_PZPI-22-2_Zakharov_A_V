import {
  describe,
  test,
  expect,
  beforeAll,
  afterAll,
  afterEach,
} from "@jest/globals";
import supertest from "supertest";
import { randomUUID } from "crypto";
import app from "../../src/app";
import db from "../../src/db";
import { User } from "../../src/entities";

interface RegisterResponse {
  token: string;
  User: User;
}

const createTestUser = async (): Promise<RegisterResponse> => {
  const response = await supertest(app).post("/api/v1/auth/register").send({
    nickname: "jwtUser",
    email: "jwtUser@gmail.com",
    password: "qweqweqwe123",
  });

  return response.body;
};

describe("Testing user router", () => {
  const supertestApp = supertest(app);

  // TODO: create new db

  beforeAll(async () => {
    await db.initialize();
    await db.runMigrations();
  });

  afterAll(async () => {
    await db.destroy();
  });

  afterEach(async () => {
    const entities = db.entityMetadatas;

    const cleanupPromises = entities.map(async (entity) => {
      const repository = db.getRepository(entity.name);
      return await repository.clear();
    });

    await Promise.all(cleanupPromises);
  });

  test("GET api/v1/users - list of user", async () => {
    const { token } = await createTestUser();

    const response = await supertestApp
      .get("/api/v1/users")
      .set("Cookie", [`token=${token}`]);

    expect(response.statusCode).toBe(200);
  });

  test("POST api/v1/users - create user", async () => {
    const { token } = await createTestUser();

    const response = await supertestApp
      .post("/api/v1/users")
      .set("Cookie", [`token=${token}`])
      .send({
        nickname: "test",
        email: "test@gmail.com",
        password: "qweqweqwe123",
      });

    expect(response.statusCode).toBe(200);
  });

  test("POST api/v1/users - invalid email", async () => {
    const { token } = await createTestUser();

    const response = await supertestApp
      .post("/api/v1/users")
      .set("Cookie", [`token=${token}`])
      .send({
        nickname: "test",
        email: "test",
        password: "qweqweqwe123",
      });

    expect(response.statusCode).toBe(400);
  });

  test("POST api/v1/users - invalid password", async () => {
    const { token } = await createTestUser();

    const response = await supertestApp
      .post("/api/v1/users")
      .set("Cookie", [`token=${token}`])
      .send({
        nickname: "test",
        email: "test@gmail.com",
        password: "qwe",
      });

    expect(response.statusCode).toBe(400);
  });

  test("POST api/v1/users - invalid nickname", async () => {
    const { token } = await createTestUser();

    const response = await supertestApp
      .post("/api/v1/users")
      .set("Cookie", [`token=${token}`])
      .send({
        nickname: "",
        email: "test@gmail.com",
        password: "qweqweqwe123",
      });

    expect(response.statusCode).toBe(400);
  });

  test("GET api/v1/users/:id - single user", async () => {
    const { token } = await createTestUser();

    const responsePost = await supertestApp
      .post("/api/v1/users")
      .set("Cookie", [`token=${token}`])
      .send({
        nickname: "test",
        email: "test@gmail.com",
        password: "qweqweqwe123",
      });

    const { id } = responsePost.body;

    const responseGet = await supertestApp
      .get(`/api/v1/users/${id}`)
      .set("Cookie", [`token=${token}`]);
    expect(responseGet.statusCode).toBe(200);
  });

  test("GET api/v1/users/:id - single user not found", async () => {
    const { token } = await createTestUser();

    const id = randomUUID();
    const responseGet = await supertestApp
      .get(`/api/v1/users/${id}`)
      .set("Cookie", [`token=${token}`]);

    expect(responseGet.statusCode).toBe(404);
  });

  test("PUT api/v1/users/:id - update user", async () => {
    const { token } = await createTestUser();

    const responsePost = await supertestApp
      .post("/api/v1/users")
      .set("Cookie", [`token=${token}`])
      .send({
        nickname: "test",
        email: "test@gmail.com",
        password: "qweqweqwe123",
      });

    const { id } = responsePost.body;

    const responsePut = await supertestApp
      .put(`/api/v1/users/${id}`)
      .set("Cookie", [`token=${token}`])
      .send({
        nickname: "test2",
        password: "qweqweqwe123",
      });

    expect(responsePut.statusCode).toBe(200);
  });

  test("PUT api/v1/users/:id - update user not found", async () => {
    const { token } = await createTestUser();

    const id = randomUUID();
    const responsePut = await supertestApp
      .put(`/api/v1/users/${id}`)
      .set("Cookie", [`token=${token}`])
      .send({
        nickname: "test2",
        password: "qweqweqwe123",
      });

    expect(responsePut.statusCode).toBe(404);
  });

  test("DELETE api/v1/users/:id - delete user", async () => {
    const { token } = await createTestUser();

    const responsePost = await supertestApp
      .post("/api/v1/users")
      .set("Cookie", [`token=${token}`])
      .send({
        nickname: "test",
        email: "test@gmail.com",
        password: "qweqweqwe123",
      });

    const { id } = responsePost.body;

    const responseDelete = await supertestApp
      .delete(`/api/v1/users/${id}`)
      .set("Cookie", [`token=${token}`]);
    expect(responseDelete.statusCode).toBe(200);
  });

  test("DELETE api/v1/users/:id - delete user not found", async () => {
    const { token } = await createTestUser();

    const id = randomUUID();
    const responseDelete = await supertestApp
      .delete(`/api/v1/users/${id}`)
      .set("Cookie", [`token=${token}`]);
    expect(responseDelete.statusCode).toBe(404);
  });
});
