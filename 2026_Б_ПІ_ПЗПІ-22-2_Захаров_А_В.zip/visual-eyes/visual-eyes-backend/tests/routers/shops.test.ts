import {
  describe,
  test,
  expect,
  beforeAll,
  afterAll,
  afterEach,
} from "@jest/globals";
import supertest from "supertest";
import { randomUUID } from "crypto";
import app from "../../src/app";
import db from "../../src/db";
import { User } from "../../src/entities";

interface RegisterResponse {
  token: string;
  User: User;
}

const createTestUser = async (): Promise<RegisterResponse> => {
  const response = await supertest(app).post("/api/v1/auth/register").send({
    nickname: "jwtUser",
    email: "jwtUser@gmail.com",
    password: "qweqweqwe123",
  });

  return response.body;
};

describe("Testing shop router", () => {
  const supertestApp = supertest(app);

  beforeAll(async () => {
    await db.initialize();
    await db.runMigrations();
  });

  afterAll(async () => {
    await db.destroy();
  });

  afterEach(async () => {
    const entities = db.entityMetadatas;

    const cleanupPromises = entities.map(async (entity) => {
      const repository = db.getRepository(entity.name);
      return await repository.clear();
    });

    await Promise.all(cleanupPromises);
  });

  test("GET api/v1/shops - list of shops", async () => {
    const { token } = await createTestUser();

    const response = await supertestApp
      .get("/api/v1/shops")
      .set("Cookie", [`token=${token}`]);

    expect(response.statusCode).toBe(200);
  });

  test("POST api/v1/shops - create shop", async () => {
    const { token } = await createTestUser();

    const response = await supertestApp
      .post("/api/v1/shops")
      .set("Cookie", [`token=${token}`])
      .send({
        title: "test",
        siteURL: "https://test.com",
        imageURL: "https://test.com",
        description: "test",
      });

    expect(response.statusCode).toBe(200);
  });

  test("GET api/v1/shops/:id - single shop", async () => {
    const { token } = await createTestUser();

    const responsePost = await supertestApp
      .post("/api/v1/shops")
      .set("Cookie", [`token=${token}`])
      .send({
        title: "test",
        siteURL: "https://test.com",
        imageURL: "https://test.com",
        description: "test",
      });

    const { id } = responsePost.body;

    const responseGet = await supertestApp
      .get(`/api/v1/shops/${id}`)
      .set("Cookie", [`token=${token}`]);
    expect(responseGet.statusCode).toBe(200);
  });

  test("GET api/v1/shops/:id - single shop not found", async () => {
    const { token } = await createTestUser();

    const id = randomUUID();
    const responseGet = await supertestApp
      .get(`/api/v1/shops/${id}`)
      .set("Cookie", [`token=${token}`]);

    expect(responseGet.statusCode).toBe(404);
  });

  test("PUT api/v1/shops/:id - update shop", async () => {
    const { token } = await createTestUser();

    const responsePost = await supertestApp
      .post("/api/v1/shops")
      .set("Cookie", [`token=${token}`])
      .send({
        title: "test",
        siteURL: "https://test.com",
        imageURL: "https://test.com",
        description: "test",
      });

    const { id } = responsePost.body;

    const responsePut = await supertestApp
      .put(`/api/v1/shops/${id}`)
      .set("Cookie", [`token=${token}`])
      .send({
        title: "test2",
      });

    expect(responsePut.statusCode).toBe(200);
  });

  test("PUT api/v1/shops/:id - update shop not found", async () => {
    const { token } = await createTestUser();

    const id = randomUUID();
    const responsePut = await supertestApp
      .put(`/api/v1/shops/${id}`)
      .set("Cookie", [`token=${token}`])
      .send({
        title: "test",
        siteURL: "https://test.com",
        imageURL: "https://test.com",
        description: "test",
      });

    expect(responsePut.statusCode).toBe(404);
  });

  test("DELETE api/v1/shops/:id - delete shop", async () => {
    const { token } = await createTestUser();

    const responsePost = await supertestApp
      .post("/api/v1/shops")
      .set("Cookie", [`token=${token}`])
      .send({
        title: "test",
        siteURL: "https://test.com",
        imageURL: "https://test.com",
        description: "test",
      });

    const { id } = responsePost.body;

    const responseDelete = await supertestApp
      .delete(`/api/v1/shops/${id}`)
      .set("Cookie", [`token=${token}`]);
    expect(responseDelete.statusCode).toBe(200);
  });

  test("DELETE api/v1/shops/:id - delete shop not found", async () => {
    const { token } = await createTestUser();

    const id = randomUUID();
    const responseDelete = await supertestApp
      .delete(`/api/v1/shops/${id}`)
      .set("Cookie", [`token=${token}`]);
    expect(responseDelete.statusCode).toBe(404);
  });
});
