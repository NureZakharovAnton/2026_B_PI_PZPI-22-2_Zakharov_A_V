import {
  describe,
  test,
  expect,
  beforeAll,
  afterAll,
  afterEach,
} from "@jest/globals";
import supertest from "supertest";
import app from "../../src/app";
import db from "../../src/db";

describe("Testing user router", () => {
  const supertestApp = supertest(app);

  // TODO: create new db

  beforeAll(async () => {
    await db.initialize();
    await db.runMigrations();
  });

  afterAll(async () => {
    await db.destroy();
  });

  afterEach(async () => {
    const entities = db.entityMetadatas;

    const cleanupPromises = entities.map(async (entity) => {
      const repository = db.getRepository(entity.name);
      return repository.clear();
    });

    await Promise.all(cleanupPromises);
  });

  test("POST api/v1/auth/register - register new user", async () => {
    const response = await supertestApp.post("/api/v1/auth/register").send({
      nickname: "test",
      email: "test@gmail.com",
      password: "qweqweqwe123",
    });

    expect(response.statusCode).toBe(200);
  });

  test("POST api/v1/auth/login - login as existing user", async () => {
    const email = "test@gmail.com";
    const password = "qweqweqwe123";

    await supertestApp.post("/api/v1/auth/register").send({
      nickname: "test",
      email,
      password,
    });

    const response = await supertestApp.post("/api/v1/auth/login").send({
      email,
      password,
    });

    expect(response.statusCode).toBe(200);
  });
});
