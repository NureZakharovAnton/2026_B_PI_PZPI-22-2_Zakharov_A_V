import { jest } from "@jest/globals";
import { Request, Response } from "express";

export const createMockRequest = (
  overrides: Partial<Request> = {}
): Partial<Request> => ({
  params: {},
  body: {},
  cookies: {},
  ...overrides,
});

export type MockResponse = {
  json: jest.Mock;
  send: jest.Mock;
  status: jest.Mock;
};

export const createMockResponse = (): MockResponse => {
  const res = {
    json: jest.fn(),
    send: jest.fn(),
    status: jest.fn(),
  };

  res.json.mockReturnValue(res);
  res.send.mockReturnValue(res);
  res.status.mockReturnValue(res);

  return res;
};

export const createMockNext = () => jest.fn();
