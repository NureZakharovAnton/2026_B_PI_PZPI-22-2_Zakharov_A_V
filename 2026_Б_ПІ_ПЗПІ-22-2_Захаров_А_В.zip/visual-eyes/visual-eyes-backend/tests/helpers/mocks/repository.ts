import { jest } from "@jest/globals";

export const createMockRepository = () => ({
  find: jest.fn<() => Promise<unknown>>(),
  findOne: jest.fn<() => Promise<unknown>>(),
  findOneBy: jest.fn<() => Promise<unknown>>(),
  create: jest.fn<(entity: unknown) => unknown>(),
  save: jest.fn<(entity: unknown) => Promise<unknown>>(),
  merge: jest.fn<(entity: unknown, data: unknown) => unknown>(),
  delete: jest.fn<(id: unknown) => Promise<unknown>>(),
  exist: jest.fn<() => Promise<boolean>>(),
});

export type MockRepository = ReturnType<typeof createMockRepository>;
