import { User } from "../../../src/entities";

export const createUserFixture = (
  overrides: Partial<User> = {}
): Partial<User> => ({
  id: "user-1",
  nickname: "testuser",
  email: "test@example.com",
  password: "qweqweqwe123",
  ...overrides,
});
